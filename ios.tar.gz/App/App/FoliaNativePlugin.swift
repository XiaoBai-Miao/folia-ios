import Foundation
import Capacitor

/// FoliaNative iOS 桥插件（与 Android FoliaNativePlugin 协议一致）：
/// - `httpRequest`：原生 HTTP 请求（供 netease/qq/kugou 等平台 provider 绕过 CORS）
/// - cookies 系列：读写原生 Cookie 存储（供登录/会话使用）
/// Web 层通过 Capacitor.Plugins.FoliaNative 调用，nativeBridge/api/*.js 的加密逻辑在 Web 层完成。
@objc(FoliaNativePlugin)
public class FoliaNativePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "FoliaNativePlugin"
    public let jsName = "FoliaNative"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "httpRequest", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cookiesGetAll", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cookiesGet", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cookiesSet", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cookiesRemove", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "cookiesRemoveBatch", returnType: CAPPluginReturnPromise),
    ]

    // MARK: - httpRequest

    @objc func httpRequest(_ call: CAPPluginCall) {
        guard let urlString = call.getString("url"), !urlString.isEmpty,
              let url = URL(string: urlString) else {
            call.reject("Missing request url")
            return
        }
        let method = (call.getString("method") ?? "GET").uppercased()
        let bodyText = call.getString("bodyText") ?? ""
        let bodyBase64 = call.getString("bodyBase64") ?? ""
        let redirect = call.getString("redirect") ?? "follow"
        let sendCookies = call.getBool("sendCookies", true) ?? true
        let timeoutMs = call.getDouble("timeoutMs") ?? 0

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = timeoutMs > 0 ? timeoutMs / 1000.0 : 45.0

        var hasCookieHeader = false
        if let headers = call.getObject("headers") as? [String: Any] {
            for (key, value) in headers {
                request.setValue(String(describing: value), forHTTPHeaderField: key)
                if key.lowercased() == "cookie" {
                    hasCookieHeader = true
                }
            }
        }

        // Body：base64 优先，其次 text；content-type 由调用方经 headers 传入。
        if !bodyBase64.isEmpty, let data = Data(base64Encoded: bodyBase64) {
            request.httpBody = data
        } else if !bodyText.isEmpty {
            request.httpBody = bodyText.data(using: .utf8)
        }

        // Cookie：除非调用方显式要求不带，或已注入 Cookie 头。
        if sendCookies && !hasCookieHeader {
            let cookies = HTTPCookieStorage.shared.cookies(for: url) ?? []
            if !cookies.isEmpty {
                let cookieString = cookies.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")
                request.setValue(cookieString, forHTTPHeaderField: "Cookie")
            }
        }

        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = sendCookies
        config.httpCookieAcceptPolicy = .always
        if redirect == "manual" {
            config.httpShouldFollowRedirects = false
        }
        let session = URLSession(configuration: config)

        let task = session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if let error = error {
                    call.reject(error.localizedDescription, nil, error)
                    return
                }
                guard let httpResponse = response as? HTTPURLResponse, let data = data else {
                    call.reject("No response")
                    return
                }
                // 保存 Set-Cookie
                if let headerFields = httpResponse.allHeaderFields as? [String: String] {
                    let cookies = HTTPCookie.cookies(withResponseHeaderFields: headerFields, for: url)
                    for cookie in cookies {
                        HTTPCookieStorage.shared.setCookie(cookie)
                    }
                }
                var headerArray: [[String: String]] = []
                for (name, value) in httpResponse.allHeaderFields {
                    headerArray.append(["name": "\(name)", "value": "\(value)"])
                }
                call.resolve([
                    "status": httpResponse.statusCode,
                    "headers": headerArray,
                    "bodyBase64": data.base64EncodedString(),
                ])
            }
        }
        task.resume()
    }

    // MARK: - cookies

    @objc func cookiesGetAll(_ call: CAPPluginCall) {
        let cookies = HTTPCookieStorage.shared.cookies ?? []
        call.resolve(["cookies": cookies.map(self.cookieDict)])
    }

    @objc func cookiesGet(_ call: CAPPluginCall) {
        let details = call.getObject("details") as? [String: Any] ?? [:]
        guard let urlString = details["url"] as? String, let url = URL(string: urlString) else {
            call.resolve(["cookie": NSNull()])
            return
        }
        let name = details["name"] as? String
        let cookie = (HTTPCookieStorage.shared.cookies(for: url) ?? [])
            .first(where: { name == nil || $0.name == name })
        call.resolve(["cookie": cookie.map(self.cookieDict) ?? NSNull()])
    }

    @objc func cookiesSet(_ call: CAPPluginCall) {
        let details = call.getObject("details") as? [String: Any] ?? [:]
        guard let urlString = details["url"] as? String, let url = URL(string: urlString) else {
            call.resolve()
            return
        }
        let name = details["name"] as? String ?? ""
        let value = details["value"] as? String ?? ""
        var properties: [HTTPCookiePropertyKey: Any] = [
            .name: name,
            .value: value,
            .path: details["path"] as? String ?? "/",
            .originURL: url,
        ]
        if let domain = details["domain"] as? String, !domain.isEmpty {
            properties[.domain] = domain
        } else if let host = url.host {
            properties[.domain] = host
        }
        if let expires = details["expirationDate"] as? Double {
            properties[.expiresDate] = Date(timeIntervalSince1970: expires)
        }
        if let secure = details["secure"] as? Bool {
            properties[.isSecure] = secure
        }
        if let cookie = HTTPCookie(properties: properties) {
            HTTPCookieStorage.shared.setCookie(cookie)
        }
        call.resolve()
    }

    @objc func cookiesRemove(_ call: CAPPluginCall) {
        let details = call.getObject("details") as? [String: Any] ?? [:]
        guard let urlString = details["url"] as? String, let url = URL(string: urlString) else {
            call.resolve(["ok": false])
            return
        }
        let name = details["name"] as? String ?? ""
        (HTTPCookieStorage.shared.cookies(for: url) ?? [])
            .filter { $0.name == name }
            .forEach { HTTPCookieStorage.shared.deleteCookie($0) }
        call.resolve(["ok": true])
    }

    @objc func cookiesRemoveBatch(_ call: CAPPluginCall) {
        let options = call.getObject("options") as? [String: Any] ?? [:]
        if let entries = options["entries"] as? [[String: Any]] {
            for entry in entries {
                if let urlString = entry["url"] as? String, let url = URL(string: urlString) {
                    let name = entry["name"] as? String ?? ""
                    (HTTPCookieStorage.shared.cookies(for: url) ?? [])
                        .filter { $0.name == name }
                        .forEach { HTTPCookieStorage.shared.deleteCookie($0) }
                }
            }
        }
        call.resolve()
    }

    private func cookieDict(_ cookie: HTTPCookie) -> [String: Any] {
        [
            "name": cookie.name,
            "value": cookie.value,
            "domain": cookie.domain,
            "path": cookie.path,
            "secure": cookie.isSecure,
        ]
    }
}