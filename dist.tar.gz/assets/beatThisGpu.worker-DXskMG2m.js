const e=`
fn erf_f32(v: f32) -> f32 {
  let a = abs(v);
  let x = 1.0 / (1.0 + 0.3275911 * a);
  let y = 1.0 - ((((1.061405429 * x - 1.453152027) * x + 1.421413741) * x - 0.284496736) * x + 0.254829592) * x * exp(-a * a);
  return select(-y, y, v >= 0.0);
}
fn gelu(v: f32) -> f32 { return 0.5 * v * (1.0 + erf_f32(v * 0.7071067811865476)); }
`,t=`
struct P { frames: u32, bins: u32 }
@group(0) @binding(0) var<storage, read> mel: array<f32>;      // [T, bins]
@group(0) @binding(1) var<storage, read> scale: array<f32>;
@group(0) @binding(2) var<storage, read> shift: array<f32>;
@group(0) @binding(3) var<storage, read_write> out: array<f32>; // [bins, T]
@group(0) @binding(4) var<uniform> p: P;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let i = id.x;
  if (i >= p.frames * p.bins) { return; }
  let f = i / p.frames;
  let t = i % p.frames;
  out[i] = mel[t * p.bins + f] * scale[f] + shift[f];
}
`,n=`
${e}
struct P { fout: u32, frames: u32, cin: u32, cout: u32, kf: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read> w: array<f32>;   // [kf, 3, cin, cout] = [K, cout]
@group(0) @binding(2) var<storage, read> b: array<f32>;
@group(0) @binding(3) var<storage, read_write> y: array<f32>;
@group(0) @binding(4) var<uniform> p: P;
var<workgroup> as_: array<f32, 1024>; // [64 rows][16 k]
var<workgroup> bs_: array<f32, 1024>; // [16 k][64 cols]

fn gather(row: u32, k: u32) -> f32 {
  let ci = k % p.cin;
  let tap = k / p.cin;
  let dt = tap % 3u;
  let df = tap / 3u;
  let t = row % p.frames;
  let fo = row / p.frames;
  let ti = i32(t) + i32(dt) - 1;
  if (ti < 0 || ti >= i32(p.frames)) { return 0.0; }
  return x[((fo * p.kf + df) * p.frames + u32(ti)) * p.cin + ci];
}

@compute @workgroup_size(16, 16)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_id) l: vec3u, @builtin(local_invocation_index) li: u32) {
  let m = p.fout * p.frames;
  let kTotal = p.kf * 3u * p.cin;
  let row0 = wg.y * 64u;
  let col0 = wg.x * 64u;
  var acc: array<array<f32, 4>, 4>;
  for (var k0 = 0u; k0 < kTotal; k0 += 16u) {
    for (var i = 0u; i < 4u; i++) {
      let idx = li + i * 256u;
      let ar = row0 + idx / 16u;
      let ak = k0 + idx % 16u;
      var av = 0.0;
      if (ar < m && ak < kTotal) { av = gather(ar, ak); }
      as_[idx] = av;
      let bk = k0 + idx / 64u;
      let bc = col0 + idx % 64u;
      var bv = 0.0;
      if (bk < kTotal && bc < p.cout) { bv = w[bk * p.cout + bc]; }
      bs_[idx] = bv;
    }
    workgroupBarrier();
    for (var kk = 0u; kk < 16u; kk++) {
      var a: array<f32, 4>;
      var bb: array<f32, 4>;
      for (var i = 0u; i < 4u; i++) { a[i] = as_[(l.y * 4u + i) * 16u + kk]; }
      for (var j = 0u; j < 4u; j++) { bb[j] = bs_[kk * 64u + l.x * 4u + j]; }
      for (var i = 0u; i < 4u; i++) {
        for (var j = 0u; j < 4u; j++) { acc[i][j] += a[i] * bb[j]; }
      }
    }
    workgroupBarrier();
  }
  for (var i = 0u; i < 4u; i++) {
    let r = row0 + l.y * 4u + i;
    if (r >= m) { continue; }
    for (var j = 0u; j < 4u; j++) {
      let c = col0 + l.x * 4u + j;
      if (c >= p.cout) { continue; }
      y[r * p.cout + c] = gelu(acc[i][j] + b[c]);
    }
  }
}
`,r=(t,n=`f32`)=>{let r=n!==`f32`;return`
${r?`enable f16;`:``}
${e}
struct P { m: u32, n: u32, k: u32, flags: u32, posDiv: u32, posMod: u32, dmodel: u32, wStride: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
${t}
@group(0) @binding(2) var<storage, read> bias: array<f32>;
@group(0) @binding(3) var<storage, read_write> y: array<f32>;
@group(0) @binding(4) var<storage, read> table: array<f32>; // [pos][16][cos, sin]
@group(0) @binding(5) var<uniform> p: P;
${r?`var<workgroup> as_: array<vec4h, 256>; // [16 k][16 row quads]
var<workgroup> bs_: array<vec4h, 256>; // [16 k][16 col quads]
var<workgroup> sums_: array<vec4f, 256>; // per-loader row sums of squares
const A_SCALE = 64.0;`:`var<workgroup> as_: array<vec4f, 256>; // [16 k][16 row quads]; afterwards the per-loader row sums of squares
var<workgroup> bs_: array<vec4f, 256>; // [16 k][16 col quads]`}
@compute @workgroup_size(16, 16)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_id) l: vec3u, @builtin(local_invocation_index) li: u32) {
  let row0 = wg.y * 64u;
  let col0 = wg.x * 64u;
  var acc: array<vec4f, 4>; // acc[j] = rows 4*l.y..+3 of column 4*l.x + j
  // Loader roles: A - invocation li reads k = li % 16 of row quad li / 16; B - k = li / 16, col quad li % 16.
  let aK = li % 16u;
  let aQuad = li / 16u;
  let bK = li / 16u;
  let bQuad = li % 16u;
  var squares = vec4f(0.0);
  for (var k0 = 0u; k0 < p.k; k0 += 16u) {
    var av = vec4f(0.0);
    let ak = k0 + aK;
    if (ak < p.k) {
      for (var r = 0u; r < 4u; r++) {
        let row = row0 + aQuad * 4u + r;
        if (row < p.m) { av[r] = x[row * p.k + ak]; }
      }
    }
    squares = fma(av, av, squares);
    as_[aK * 16u + aQuad] = ${r?`vec4h(select(av, av / A_SCALE, (p.flags & 4u) != 0u))`:`av`};
    var bv = ${r?`vec4h`:`vec4f`}(0.0);
    let bk = k0 + bK;
    let bc = col0 + bQuad * 4u;
    if (bk < p.k && bc < p.n) { bv = weightQuad((bk * p.wStride + bc) / 4u); }
    bs_[bK * 16u + bQuad] = bv;
    workgroupBarrier();
${r?`${n===`math`?`    var part: array<vec4h, 4>;
`:``}    for (var kk = 0u; kk < 16u; kk++) {
      let a = as_[kk * 16u + l.y];
      let b = bs_[kk * 16u + l.x];
${n===`math`?`      part[0] = fma(a, vec4h(b.x), part[0]);
      part[1] = fma(a, vec4h(b.y), part[1]);
      part[2] = fma(a, vec4h(b.z), part[2]);
      part[3] = fma(a, vec4h(b.w), part[3]);
    }
    for (var j = 0u; j < 4u; j++) { acc[j] += vec4f(part[j]); }`:`      let af = vec4f(a);
      let bf = vec4f(b);
      acc[0] = fma(af, vec4f(bf.x), acc[0]);
      acc[1] = fma(af, vec4f(bf.y), acc[1]);
      acc[2] = fma(af, vec4f(bf.z), acc[2]);
      acc[3] = fma(af, vec4f(bf.w), acc[3]);
    }`}`:`    for (var kk = 0u; kk < 16u; kk++) {
      let a = as_[kk * 16u + l.y];
      let b = bs_[kk * 16u + l.x];
      acc[0] = fma(a, vec4f(b.x), acc[0]);
      acc[1] = fma(a, vec4f(b.y), acc[1]);
      acc[2] = fma(a, vec4f(b.z), acc[2]);
      acc[3] = fma(a, vec4f(b.w), acc[3]);
    }`}
    workgroupBarrier();
  }
  // The 16 loaders of row quad q are invocations 16q..16q+15; their partial sums meet in ${r?`sums_`:`as_`}.
  ${r?`sums_`:`as_`}[li] = squares;
  workgroupBarrier();
  var rowScale = vec4f(1.0);
  if ((p.flags & 4u) != 0u) {
    var total = vec4f(0.0);
    for (var t = 0u; t < 16u; t++) { total += ${r?`sums_`:`as_`}[l.y * 16u + t]; }
    rowScale = ${r?`A_SCALE`:`1.0`} / max(sqrt(total), vec4f(1e-12));
  }
  for (var i = 0u; i < 4u; i++) {
    let r = row0 + l.y * 4u + i;
    if (r >= p.m) { continue; }
    var v: array<f32, 4>;
    for (var j = 0u; j < 4u; j++) {
      let c = min(col0 + l.x * 4u + j, p.n - 1u);
      v[j] = acc[j][i] * rowScale[i] + bias[c];
    }
    let c0 = col0 + l.x * 4u;
    if ((p.flags & 8u) != 0u && c0 < 2u * p.dmodel) {
      let pos = (r / p.posDiv) % p.posMod;
      for (var pair = 0u; pair < 2u; pair++) {
        let t = (pos * 16u + ((c0 + 2u * pair) % 32u) / 2u) * 2u;
        let cs = table[t];
        let sn = table[t + 1u];
        let x0 = v[2u * pair];
        let x1 = v[2u * pair + 1u];
        v[2u * pair] = x0 * cs - x1 * sn;
        v[2u * pair + 1u] = x1 * cs + x0 * sn;
      }
    }
    for (var j = 0u; j < 4u; j++) {
      let c = c0 + j;
      if (c >= p.n) { continue; }
      var res = v[j];
      let o = r * p.n + c;
      if ((p.flags & 1u) != 0u) { res = gelu(res); }
      if ((p.flags & 2u) != 0u) { res += y[o]; }
      y[o] = res;
    }
  }
}
`},i=r(`
@group(0) @binding(1) var<storage, read> w: array<vec4f>;
fn weightQuad(i: u32) -> vec4f { return w[i]; }`),a=r(`
@group(0) @binding(1) var<storage, read> w: array<vec2u>; // four fp16 columns per element
fn weightQuad(i: u32) -> vec4f { let q = w[i]; return vec4f(unpack2x16float(q.x), unpack2x16float(q.y)); }`),o=`
@group(0) @binding(1) var<storage, read> w: array<vec4h>;
fn weightQuad(i: u32) -> vec4h { return w[i]; }`,s=r(o,`storage`),c=r(o,`math`),l=e=>`
${e?`enable f16;`:``}
struct P { n: u32, heads: u32, width: u32, dmodel: u32, seqStride: u32, batchStride: u32 }
@group(0) @binding(0) var<storage, read> qkv: array<f32>;
@group(0) @binding(1) var<storage, read_write> o: array<f32>; // [rows, dmodel]
@group(0) @binding(2) var<uniform> p: P;
const TILE = 32u;
var<workgroup> ks: array<${e!=null&&e.k?`vec4h`:`vec4f`}, 256>; // [TILE keys][8 x vec4]
var<workgroup> vs: array<${e?`vec4h`:`vec4f`}, 256>;
@compute @workgroup_size(64)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_id) l: vec3u) {
  let b = wg.z;
  let h = wg.y;
  let qi = wg.x * 64u + l.x;
  let valid = qi < p.n;
  let qrow = b * p.batchStride + min(qi, p.n - 1u) * p.seqStride;
  var q: array<vec4f, 8>;
  var acc: array<vec4f, 8>;
  let qBase = qrow * p.width + h * 32u;
  for (var d = 0u; d < 8u; d++) {
    q[d] = vec4f(qkv[qBase + 4u * d], qkv[qBase + 4u * d + 1u], qkv[qBase + 4u * d + 2u], qkv[qBase + 4u * d + 3u]) * 0.17677669529663687;
    acc[d] = vec4f(0.0);
  }
  var m = -3.0e38;
  var sum = 0.0;
  for (var k0 = 0u; k0 < p.n; k0 += TILE) {
    // 32 keys x 8 vec4 = 256 vec4 each for K and V, four per invocation.
    for (var i = 0u; i < 4u; i++) {
      let idx = l.x + i * 64u;
      let kj = k0 + idx / 8u;
      var kv = vec4f(0.0);
      var vv = vec4f(0.0);
      if (kj < p.n) {
        let base = (b * p.batchStride + kj * p.seqStride) * p.width + h * 32u + (idx % 8u) * 4u;
        let kb = base + p.dmodel;
        let vb = base + 2u * p.dmodel;
        kv = vec4f(qkv[kb], qkv[kb + 1u], qkv[kb + 2u], qkv[kb + 3u]);
        vv = vec4f(qkv[vb], qkv[vb + 1u], qkv[vb + 2u], qkv[vb + 3u]);
      }
      ks[idx] = ${e!=null&&e.k?`vec4h(kv)`:`kv`};
      vs[idx] = ${e?`vec4h(vv)`:`vv`};
    }
    workgroupBarrier();
    // Constant trip counts so the compiler unrolls and keeps s[] in registers; keys past the end
    // of the sequence get a score of -3e38, whose exp is exactly 0.
    var s: array<f32, 32>;
    var tileMax = -3.0e38;
    for (var j = 0u; j < TILE; j++) {
      var dotv = vec4f(0.0);
      for (var d = 0u; d < 8u; d++) { dotv = fma(q[d], ${e!=null&&e.k?`vec4f(ks[j * 8u + d])`:`ks[j * 8u + d]`}, dotv); }
      s[j] = select(-3.0e38, dotv.x + dotv.y + dotv.z + dotv.w, k0 + j < p.n);
      tileMax = max(tileMax, s[j]);
    }
    let mNew = max(m, tileMax);
    let r = exp(m - mNew);
    sum *= r;
    for (var d = 0u; d < 8u; d++) { acc[d] *= r; }
    m = mNew;
${e!=null&&e.pv?`    var part: array<vec4h, 8>;
    for (var j = 0u; j < TILE; j++) {
      let e = exp(s[j] - m);
      sum += e;
      let eh = vec4h(f16(e));
      for (var d = 0u; d < 8u; d++) { part[d] = fma(eh, vs[j * 8u + d], part[d]); }
    }
    for (var d = 0u; d < 8u; d++) { acc[d] += vec4f(part[d]); }`:`    for (var j = 0u; j < TILE; j++) {
      let e = exp(s[j] - m);
      sum += e;
      for (var d = 0u; d < 8u; d++) { acc[d] = fma(vec4f(e), ${e?`vec4f(vs[j * 8u + d])`:`vs[j * 8u + d]`}, acc[d]); }
    }`}
    workgroupBarrier();
  }
  if (!valid) { return; }
  let gate = 1.0 / (1.0 + exp(-qkv[qrow * p.width + 3u * p.dmodel + h]));
  let scale = gate / sum;
  let oBase = qrow * p.dmodel + h * 32u;
  for (var d = 0u; d < 8u; d++) {
    let v = acc[d] * scale;
    o[oBase + 4u * d] = v.x;
    o[oBase + 4u * d + 1u] = v.y;
    o[oBase + 4u * d + 2u] = v.z;
    o[oBase + 4u * d + 3u] = v.w;
  }
}
`,u=l(null),d=l({k:!0,pv:!1}),f=l({k:!0,pv:!0}),p=`
struct P { freqs: u32, frames: u32, channels: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read_write> y: array<f32>;
@group(0) @binding(2) var<uniform> p: P;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let i = id.x;
  if (i >= p.freqs * p.frames * p.channels) { return; }
  let c = i % p.channels;
  let t = (i / p.channels) % p.frames;
  let f = i / (p.channels * p.frames);
  y[(t * p.freqs + f) * p.channels + c] = x[i];
}
`,m=`
struct P { frames: u32 }
@group(0) @binding(0) var<storage, read> l: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;
@group(0) @binding(2) var<uniform> p: P;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let t = id.x;
  if (t >= p.frames) { return; }
  out[t] = l[t * 2u] + l[t * 2u + 1u];
  out[p.frames + t] = l[t * 2u + 1u];
}
`;function h(e){"@babel/helpers - typeof";return h=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},h(e)}function g(e,t){if(h(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t||`default`);if(h(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function _(e){var t=g(e,`string`);return h(t)==`symbol`?t:t+``}function v(e,t,n){return(t=_(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function y(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function b(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?y(Object(n),!0).forEach(function(t){v(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):y(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}const x=1500,S=e=>e.reduce((e,t)=>e*t,1),C=/* @__PURE__ */ new Map([[t,`stem_bn`],[n,`conv`],[i,`matmul`],[a,`matmul`],[s,`matmul`],[c,`matmul`],[u,`attention`],[d,`attention`],[f,`attention`],[p,`flatten`],[m,`sum_head`]]);var w=class e{constructor(e,t,n,r,i){this.device=e,this.build=t,this.melBuffer=n,this.outBuffer=r,this.owned=i,this.fineStages=/* @__PURE__ */ new Set,this.autoRuns=0,this.graphs=/* @__PURE__ */ new Map}get bytes(){let e=this.owned.reduce((e,t)=>e+t.size,0);for(let t of this.graphs.values())e+=t.owned.reduce((e,t)=>e+t.size,0);return e}graph(e){let t=this.graphs.get(e);if(!t){for(let[e,t]of this.graphs)e!==1500&&(t.owned.forEach(e=>e.destroy()),this.graphs.delete(e));t=this.build(e),this.graphs.set(e,t)}return t.steps}static async create(r,o,l,h={}){if(h.f16&&!r.features.has(`shader-f16`))throw Error(`beat_this f16: device lacks shader-f16`);let g=x,_=[],v=(e,t=0)=>{let n=r.createBuffer({size:Math.max(16,e*4),usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST|t});return _.push(n),n},y=v(Math.ceil(o.byteLength/4));r.queue.writeBuffer(y,0,o.buffer,o.byteOffset,o.byteLength);let b=e=>{let t=l.tensors[e];if(!t)throw Error(`beat_this weights: missing tensor ${e}`);return t},w=e=>{let{byte_offset:t,shape:n,dtype:r,stride:i}=b(e),a=i?n[0]*i:S(n);return{buffer:y,offset:t,size:a*(r===`f16`?2:4)}},T=e=>l.tensors[e].shape,E=l.hyper_parameters.transformer_dim,D=l.hyper_parameters.stem_dim,O=l.hyper_parameters.ff_mult,k=32*g,A=e=>3*e+e/32,j=v(g*128),M=v(g*128),N=[v(k*D),v(k*D)],P=v(Math.max(k*A(D),g*A(E))),ee=v(k*D),te=v(Math.max(k*D*O,g*E*O)),ne=v(g*4*D*8),re=v(g*2),ie=v(g*2),ae=v(4096),F=o.byteOffset+b(`rope.freqs`).byte_offset,I=new Float32Array(o.buffer.slice(F,F+64)),oe=new Float32Array(g*16*2);for(let e=0;e<g;e+=1)for(let t=0;t<16;t+=1){let n=Math.fround(Math.fround(e)*I[t]);oe[(e*16+t)*2]=Math.cos(n),oe[(e*16+t)*2+1]=Math.sin(n)}let se=v(oe.length);r.queue.writeBuffer(se,0,oe);let ce=/* @__PURE__ */ new Map,le=e=>{let t=ce.get(e);return t||(t=r.createComputePipeline({layout:`auto`,compute:{module:r.createShaderModule({code:e}),entryPoint:`main`}}),ce.set(e,t)),t},ue=new e(r,e=>{let o=[],g=e=>{let t=new Uint32Array(Math.ceil(e.length/4)*4);t.set(e);let n=r.createBuffer({size:t.byteLength,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return r.queue.writeBuffer(n,0,t),o.push(n),n},_=[],v=`stem`,y=(e,t,n,i,a=``)=>{let o=le(e),s=[...t,{buffer:g(n)}].map((e,t)=>({binding:t,resource:e})),c=`${v} ${C.get(e)}${a?` ${a}`:``}`;_.push({kind:`dispatch`,label:c,pipeline:o,group:r.createBindGroup({layout:o.getBindGroupLayout(0),entries:s}),count:i})},x=e=>[Math.ceil(e/64),1,1],S=(e,t,n)=>_.push({kind:`stage`,name:e,buffer:t,floats:n}),O=(e,t,n,r,o,l,u={posDiv:1,posMod:1,dmodel:0})=>{let[d,f]=T(t),{dtype:p,stride:m}=b(t);if(!m)throw Error(`beat_this weights: ${t} has no row stride (re-export the weights)`);let g=h.f16===`math`?c:s;y(p===`f16`?h.f16?g:a:i,[{buffer:e},w(t),n?w(n):{buffer:ae},{buffer:r},{buffer:se}],[o,f,d,l,u.posDiv,u.posMod,u.dmodel,m],[Math.ceil(f/64),Math.ceil(o/64),1],t.split(`.`).slice(-2).join(`.`))},k=(e,t,n,r,i)=>{let a=r/32,o=3*r+a;v=t,O(e,`${t}.attn.qkvg.w`,`${t}.attn.qkvg.b`,P,n,12,{posDiv:i.posDiv,posMod:i.n,dmodel:r}),y(h.f16?h.f16===`math`?f:d:u,[{buffer:P},{buffer:ee}],[i.n,a,o,r,i.seqStride,i.batchStride],[Math.ceil(i.n/64),a,i.batches]),O(ee,`${t}.attn.out.w`,null,e,n,2),O(e,`${t}.ff.w1`,`${t}.ff.b1`,te,n,5),O(te,`${t}.ff.w2`,`${t}.ff.b2`,e,n,2)};y(t,[{buffer:j},w(`stem.bn.scale`),w(`stem.bn.shift`),{buffer:M}],[e,128],x(e*128));let A=32,F=D;y(n,[{buffer:M},w(`stem.conv.w`),w(`stem.conv.b`),{buffer:N[0]}],[A,e,1,F,4],[Math.ceil(F/64),Math.ceil(A*e/64),1]);let I=0;S(`stem`,N[I],A*e*F);for(let t=0;t<3;t+=1){let r=A*e;k(N[I],`block${t}.freq`,r,F,{n:A,seqStride:e,batchStride:1,batches:e,posDiv:e}),S(`block${t}_freq`,N[I],r*F),k(N[I],`block${t}.time`,r,F,{n:e,seqStride:1,batchStride:e,batches:A,posDiv:1}),S(`block${t}_time`,N[I],r*F);let i=1-I;v=`block${t}`,y(n,[{buffer:N[I]},w(`block${t}.conv.w`),w(`block${t}.conv.b`),{buffer:N[i]}],[A/2,e,F,F*2,2],[Math.ceil(F*2/64),Math.ceil(A/2*e/64),1]),I=i,A/=2,F*=2,S(`block${t}_conv`,N[I],A*e*F)}v=`frontend`,y(p,[{buffer:N[I]},{buffer:ne}],[A,e,F],x(A*e*F)),I=1-I,O(ne,`frontend.linear.w`,`frontend.linear.b`,N[I],e,0),S(`frontend`,N[I],e*E);for(let t=0;t<l.hyper_parameters.n_layers;t+=1)k(N[I],`layer${t}`,e,E,{n:e,seqStride:1,batchStride:e,batches:1,posDiv:1}),S(`layer${t}`,N[I],e*E);return v=`head`,O(N[I],`head.w`,`head.b`,re,e,4),y(m,[{buffer:re},{buffer:ie}],[e],x(e)),S(`logits`,ie,e*2),{steps:_,owned:o}},j,ie,_);return ue.graph(g),await r.queue.onSubmittedWorkDone(),ue}async run(e,t={}){var n,r,i;let a=e.length/128;if(!Number.isInteger(a)||a<1||a>1500)throw Error(`beat_this chunk must be 1..${x} frames x 128, got ${e.length} values`);let o=this.graph(a),{device:s}=this;s.queue.writeBuffer(this.melBuffer,0,e.buffer,e.byteOffset,e.byteLength);let c=s.createCommandEncoder(),l=[],u=t.profile&&s.features.has(`timestamp-query`)?o.filter(e=>e.kind===`dispatch`):[],d=u.length?s.createQuerySet({type:`timestamp`,count:u.length*2}):null,f=0,p=null,m=0,h=0,g=(n=t.slice)==null?`none`:n,_=g===`auto`?1:Math.max(1,(r=t.inFlight)==null?1:r),v=[],y=async(e=!1)=>{p==null||p.end(),p=null;let t=performance.now();for(s.queue.submit([c.finish()]),v.push(s.queue.onSubmittedWorkDone());v.length>(e?0:_-1);)await v.shift();let n=performance.now()-t;return m+=n,h+=1,c=s.createCommandEncoder(),n},S=(i=t.budgetMs)==null?8:i;g===`auto`&&++this.autoRuns%50==0&&this.fineStages.clear();let C=0,w=performance.now();for(let e of o){if((g===`dispatch`||g===`auto`&&this.fineStages.has(C))&&p){var T;await y(),await((T=t.between)==null?void 0:T.call(t))}if(e.kind===`dispatch`){d&&(p==null||p.end(),p=c.beginComputePass({timestampWrites:{querySet:d,beginningOfPassWriteIndex:f,endOfPassWriteIndex:f+1}}),f+=2),p!=null||(p=c.beginComputePass()),p.setPipeline(e.pipeline),p.setBindGroup(0,e.group),p.dispatchWorkgroups(...e.count);continue}if((g===`stage`||g===`auto`&&!this.fineStages.has(C))&&e.name!==`logits`){var E;let e=await y();g===`auto`&&e>S&&this.fineStages.add(C),await((E=t.between)==null?void 0:E.call(t))}if(C+=1,!t.stages&&e.name!==`logits`)continue;p==null||p.end(),p=null;let n=s.createBuffer({size:e.floats*4,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});c.copyBufferToBuffer(e.buffer,0,n,0,e.floats*4),l.push({name:e.name,buffer:n})}p==null||p.end();let D=null;if(d){let e=s.createBuffer({size:f*8,usage:GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC});D=s.createBuffer({size:f*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),c.resolveQuerySet(d,0,f,e,0),c.copyBufferToBuffer(e,0,D,0,f*8)}await y(!0);let O=performance.now()-w,k={};for(let{name:e,buffer:t}of l)await t.mapAsync(GPUMapMode.READ),k[e]=new Float32Array(t.getMappedRange().slice(0)),t.destroy();let A;if(D){await D.mapAsync(GPUMapMode.READ);let e=new BigInt64Array(D.getMappedRange());A=u.map((t,n)=>({label:t.kind===`dispatch`?t.label:``,ms:Number(e[n*2+1]-e[n*2])/1e6})),D.destroy(),d==null||d.destroy()}let j=k.logits;return b(b({beat:j.subarray(0,a),downbeat:j.subarray(a,2*a),gpuMs:m,wallMs:O,slices:h},t.stages?{stages:k}:{}),A?{profile:A}:{})}destroy(){this.owned.forEach(e=>e.destroy()),this.graphs.forEach(e=>e.owned.forEach(e=>e.destroy()))}};const T=1024,E=/* @__PURE__ */ new WeakMap,D=async(e,t,n)=>{if(n<1||t.length<n*128)throw Error(`percussive: ${t.length} floats for ${n} frames`);let r=E.get(e);r||(r=await e.createComputePipelineAsync({layout:`auto`,compute:{module:e.createShaderModule({code:`
struct Params { frames: u32, first: u32, count: u32 }
@group(0) @binding(0) var<storage, read> mel: array<f32>;
@group(0) @binding(1) var<storage, read_write> energy: array<f32>;
@group(0) @binding(2) var<uniform> p: Params;

const BANDS: i32 = 128;
const HALF: i32 = 8;
const TAPS: i32 = 17;

fn magnitude(frame: i32, band: i32) -> f32 {
  if (frame < 0 || frame >= i32(p.frames) || band < 0 || band >= BANDS) { return 0.0; }
  let v = mel[u32(frame * BANDS + band)];
  // expm1 without its cancellation near 0.
  if (v < 1e-3) { return max(0.0, v + 0.5 * v * v); }
  return exp(v) - 1.0;
}

fn median(values: ptr<function, array<f32, 17>>) -> f32 {
  for (var i = 1; i < TAPS; i++) {
    let value = (*values)[i];
    var j = i - 1;
    while (j >= 0 && (*values)[j] > value) {
      (*values)[j + 1] = (*values)[j];
      j--;
    }
    (*values)[j + 1] = value;
  }
  return (*values)[HALF];
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
  if (id.x >= p.count) { return; }
  let at = p.first + id.x;
  let frame = i32(at);
  var percussive = 0.0;
  var total = 0.0;
  var taps: array<f32, 17>;
  for (var band = 0; band < BANDS; band++) {
    for (var k = 0; k < TAPS; k++) { taps[k] = magnitude(frame + k - HALF, band); }
    let harmonic = median(&taps);
    for (var k = 0; k < TAPS; k++) { taps[k] = magnitude(frame, band + k - HALF); }
    let hit = median(&taps);
    let value = magnitude(frame, band);
    let e = value * value;
    let hh = harmonic * harmonic;
    let pp = hit * hit;
    if (hh + pp > 0.0) { percussive += e * pp / (hh + pp); }
    total += e;
  }
  energy[2u * at] = percussive;
  energy[2u * at + 1u] = total;
}
`}),entryPoint:`main`}}),E.set(e,r));let i=e.createBuffer({size:n*128*4,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),a=e.createBuffer({size:n*2*4,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),o=Math.ceil(n/T),s=e.createBuffer({size:o*256,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),c=e.createBuffer({size:n*2*4,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});try{e.queue.writeBuffer(i,0,t.buffer,t.byteOffset,n*128*4);for(let t=0;t<o;t+=1){let l=t*T,u=Math.min(T,n-l);e.queue.writeBuffer(s,t*256,new Uint32Array([n,l,u,0]));let d=e.createBindGroup({layout:r.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:i}},{binding:1,resource:{buffer:a}},{binding:2,resource:{buffer:s,offset:t*256,size:16}}]}),f=e.createCommandEncoder(),p=f.beginComputePass();p.setPipeline(r),p.setBindGroup(0,d),p.dispatchWorkgroups(Math.ceil(u/64)),p.end(),t===o-1&&f.copyBufferToBuffer(a,0,c,0,n*2*4),e.queue.submit([f.finish()]),await e.queue.onSubmittedWorkDone()}await c.mapAsync(GPUMapMode.READ);let l=new Float32Array(c.getMappedRange().slice(0));c.unmap();let u=new Float32Array(n),d=new Float32Array(n);for(let e=0;e<n;e+=1)u[e]=l[2*e],d[e]=l[2*e+1];return{percussive:u,total:d}}finally{i.destroy(),a.destroy(),s.destroy(),c.destroy()}},O=`
fn erf_f32(v: f32) -> f32 {
  let a = abs(v);
  let x = 1.0 / (1.0 + 0.3275911 * a);
  let y = 1.0 - ((((1.061405429 * x - 1.453152027) * x + 1.421413741) * x - 0.284496736) * x + 0.254829592) * x * exp(-a * a);
  return select(-y, y, v >= 0.0);
}
fn gelu(v: f32) -> f32 { return 0.5 * v * (1.0 + erf_f32(v * 0.7071067811865476)); }
`,k=e=>e?`
@group(0) @binding(1) var<storage, read> w: array<u32>;
fn wload(e: u32) -> f32 {
  let pair = unpack2x16float(w[e >> 1u]);
  return select(pair.x, pair.y, (e & 1u) == 1u);
}`:`
@group(0) @binding(1) var<storage, read> w: array<f32>;
fn wload(e: u32) -> f32 { return w[e]; }`,A=e=>`
var<workgroup> as_: array<${e===`f16`?`vec4h`:`vec4f`}, 256>;
var<workgroup> bs_: array<${e===`f16`?`vec4h`:`vec4f`}, 256>;`,j=(e,t)=>`${e===`f16`?`vec4h`:`vec4f`}(${t})`,M=e=>e===`f16`?`
    var part: array<vec4h, 4>;
    for (var kk = 0u; kk < 16u; kk++) {
      let a = as_[kk * 16u + l.y];
      let bb = bs_[kk * 16u + l.x];
      for (var i = 0u; i < 4u; i++) { part[i] = fma(vec4h(a[i]), bb, part[i]); }
    }
    for (var i = 0u; i < 4u; i++) { acc[i] += vec4f(part[i]); }`:`
    for (var kk = 0u; kk < 16u; kk++) {
      let a = as_[kk * 16u + l.y];
      let bb = bs_[kk * 16u + l.x];
      for (var i = 0u; i < 4u; i++) { acc[i] = fma(vec4f(a[i]), bb, acc[i]); }
    }`,N=e=>e===`f16`?`enable f16;`:``,P=(e,t)=>`
${A(t)}
@compute @workgroup_size(16, 16)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_id) l: vec3u, @builtin(local_invocation_index) li: u32) {
  let n = ${e};
  let row0 = wg.y * 64u;
  let col0 = wg.x * 64u;
  var acc: array<vec4f, 4>;
  for (var k0 = 0u; k0 < p.k; k0 += 16u) {
    // Invocation li: rows 4 (li / 16).. at k li % 16 of A, columns 4 (li % 16).. at k li / 16 of B.
    let ak = k0 + li % 16u;
    var av = vec4f(0.0);
    let bk = k0 + li / 16u;
    var bv = vec4f(0.0);
    for (var c = 0u; c < 4u; c++) {
      let ar = row0 + (li / 16u) * 4u + c;
      if (ar < p.m && ak < p.k) { av[c] = wload(ar * p.k + ak); }
      let bc = col0 + (li % 16u) * 4u + c;
      if (bk < p.k && bc < n) { bv[c] = gather(bk, bc); }
    }
    as_[(li % 16u) * 16u + li / 16u] = ${j(t,`av`)};
    bs_[li] = ${j(t,`bv`)};
    workgroupBarrier();${M(t)}
    workgroupBarrier();
  }
  for (var i = 0u; i < 4u; i++) {
    let r = row0 + l.y * 4u + i;
    if (r >= p.m) { continue; }
    for (var j = 0u; j < 4u; j++) {
      let c = col0 + l.x * 4u + j;
      if (c >= n) { continue; }
      store(r, c, acc[i][j]);
    }
  }
}
`,ee=(e,t=`f32`)=>`
${N(t)}
${O}
struct P { m: u32, k: u32, cin: u32, kh: u32, kw: u32, sh: u32, sw: u32, ph: u32, pw: u32, dh: u32, dw: u32, hin: u32, win: u32, hout: u32, wout: u32, flags: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
${k(e)}
@group(0) @binding(2) var<storage, read> b: array<f32>;
@group(0) @binding(3) var<storage, read> side: array<f32>;
@group(0) @binding(4) var<storage, read_write> y: array<f32>;
@group(0) @binding(5) var<uniform> p: P;

fn gather(k: u32, n: u32) -> f32 {
  let taps = p.kh * p.kw;
  let ci = k / taps;
  let r = k - ci * taps;
  let a = r / p.kw;
  let c = r - a * p.kw;
  let ho = n / p.wout;
  let wo = n - ho * p.wout;
  let hi = i32(ho * p.sh + a * p.dh) - i32(p.ph);
  let wi = i32(wo * p.sw + c * p.dw) - i32(p.pw);
  if (hi < 0 || hi >= i32(p.hin) || wi < 0 || wi >= i32(p.win)) { return 0.0; }
  return x[(ci * p.hin + u32(hi)) * p.win + u32(wi)];
}

fn store(r: u32, c: u32, sum: f32) {
  var v = sum + b[r];
  if ((p.flags & 1u) != 0u) { v = gelu(v); }
  let o = r * p.hout * p.wout + c;
  if ((p.flags & 2u) != 0u) { y[o] = y[o] + side[r] * v; } else { y[o] = v; }
}
${P(`p.hout * p.wout`,t)}
`,te=(e,t=`f32`)=>`
${N(t)}
${O}
struct P { m: u32, k: u32, cin: u32, hin: u32, win: u32, axis: u32, flags: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
${k(e)}
@group(0) @binding(2) var<storage, read> b: array<f32>;
@group(0) @binding(3) var<storage, read_write> y: array<f32>;
@group(0) @binding(4) var<uniform> p: P;

fn gather(k: u32, n: u32) -> f32 {
  let ci = k / 2u;
  let t = k - ci * 2u;
  if (p.axis == 0u) {
    let q = n / p.win;
    let w = n - q * p.win;
    if (q < t || q - t >= p.hin) { return 0.0; }
    return x[(ci * p.hin + q - t) * p.win + w];
  }
  let h = n / (p.win + 1u);
  let q = n - h * (p.win + 1u);
  if (q < t || q - t >= p.win) { return 0.0; }
  return x[(ci * p.hin + h) * p.win + q - t];
}

fn store(r: u32, c: u32, sum: f32) {
  let co = r / 4u;
  let ph = r - co * 4u;
  var v = sum + b[co];
  if ((p.flags & 1u) != 0u) { v = gelu(v); }
  if (p.axis == 0u) {
    let q = c / p.win;
    let w = c - q * p.win;
    let o = 4u * q + ph;
    if (o < 2u || o - 2u >= 4u * p.hin) { return; }
    y[(co * 4u * p.hin + o - 2u) * p.win + w] = v;
  } else {
    let h = c / (p.win + 1u);
    let q = c - h * (p.win + 1u);
    let o = 4u * q + ph;
    if (o < 2u || o - 2u >= 4u * p.win) { return; }
    y[(co * p.hin + h) * 4u * p.win + o - 2u] = v;
  }
}
${P(`select(p.hin * (p.win + 1u), (p.hin + 1u) * p.win, p.axis == 0u)`,t)}
`,ne=`
struct P { parts: u32, c: u32, inner: u32, cs: u32, gs: u32, mode: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read> stats: array<f32>;
@group(0) @binding(2) var<storage, read_write> partial: array<f32>;
@group(0) @binding(3) var<uniform> p: P;
var<workgroup> sums: array<f32, 256>;
@compute @workgroup_size(256)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_index) li: u32) {
  let g = wg.y;
  let n = p.c * p.inner;
  let chunk = (n + p.parts - 1u) / p.parts;
  let lo = wg.x * chunk;
  let hi = min(n, lo + chunk);
  let mean = stats[g * 4u];
  var s = 0.0;
  for (var e = lo + li; e < hi; e += 256u) {
    let ch = e / p.inner;
    let v = x[ch * p.cs + g * p.gs + e - ch * p.inner];
    if (p.mode == 0u) { s += v; } else { let d = v - mean; s = fma(d, d, s); }
  }
  sums[li] = s;
  workgroupBarrier();
  for (var span = 128u; span > 0u; span >>= 1u) {
    if (li < span) { sums[li] += sums[li + span]; }
    workgroupBarrier();
  }
  if (li == 0u) { partial[g * p.parts + wg.x] = sums[0]; }
}
`,re=`
struct P { parts: u32, n: u32, mode: u32 }
@group(0) @binding(0) var<storage, read> partial: array<f32>;
@group(0) @binding(1) var<storage, read_write> stats: array<f32>;
@group(0) @binding(2) var<uniform> p: P;
var<workgroup> sums: array<f32, 256>;
@compute @workgroup_size(256)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_index) li: u32) {
  let g = wg.x;
  var s = 0.0;
  for (var i = li; i < p.parts; i += 256u) { s += partial[g * p.parts + i]; }
  sums[li] = s;
  workgroupBarrier();
  for (var span = 128u; span > 0u; span >>= 1u) {
    if (li < span) { sums[li] += sums[li + span]; }
    workgroupBarrier();
  }
  if (li != 0u) { return; }
  let total = sums[0];
  let n = f32(p.n);
  if (p.mode == 0u) {
    stats[g * 4u] = total / n;
  } else if (p.mode == 1u) {
    stats[g * 4u + 1u] = 1.0 / sqrt(total / n + 1e-5);
  } else {
    let sd = sqrt(total / (n - 1.0));
    stats[g * 4u + 1u] = 1.0 / (sd + 1e-5);
    stats[g * 4u + 2u] = sd;
  }
}
`,ie=`
${O}
struct P { c: u32, h: u32, w: u32, perH: u32, gelu: u32 }
@group(0) @binding(0) var<storage, read_write> x: array<f32>;
@group(0) @binding(1) var<storage, read> stats: array<f32>;
@group(0) @binding(2) var<storage, read> gamma: array<f32>;
@group(0) @binding(3) var<storage, read> beta: array<f32>;
@group(0) @binding(4) var<uniform> p: P;
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3u, @builtin(num_workgroups) groups: vec3u) {
  let i = id.x + id.y * groups.x * 256u;
  let plane = p.h * p.w;
  if (i >= p.c * plane) { return; }
  let ch = i / plane;
  let g = select(0u, (i - ch * plane) / p.w, p.perH == 1u);
  var v = (x[i] - stats[g * 4u]) * stats[g * 4u + 1u] * gamma[ch] + beta[ch];
  if (p.gelu == 1u) { v = gelu(v); }
  x[i] = v;
}
`,ae=`
struct P { c: u32, h: u32, w: u32, perH: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read> stats: array<f32>;
@group(0) @binding(2) var<storage, read> gamma: array<f32>;
@group(0) @binding(3) var<storage, read> beta: array<f32>;
@group(0) @binding(4) var<storage, read> scale: array<f32>;
@group(0) @binding(5) var<storage, read_write> res: array<f32>;
@group(0) @binding(6) var<uniform> p: P;
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3u, @builtin(num_workgroups) groups: vec3u) {
  let i = id.x + id.y * groups.x * 256u;
  let plane = p.h * p.w;
  if (i >= p.c * plane) { return; }
  let ch = i / plane;
  let at = i - ch * plane;
  let g = select(0u, at / p.w, p.perH == 1u);
  let mean = stats[g * 4u];
  let rstd = stats[g * 4u + 1u];
  let a = (x[i] - mean) * rstd * gamma[ch] + beta[ch];
  let gch = ch + p.c;
  let gate = (x[gch * plane + at] - mean) * rstd * gamma[gch] + beta[gch];
  res[i] = res[i] + scale[ch] * (a / (1.0 + exp(-gate)));
}
`,F=`
struct P { c: u32, h: u32, w: u32, emb: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read> emb: array<f32>;
@group(0) @binding(2) var<storage, read_write> y: array<f32>;
@group(0) @binding(3) var<uniform> p: P;
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3u, @builtin(num_workgroups) groups: vec3u) {
  let i = id.x + id.y * groups.x * 256u;
  let plane = p.h * p.w;
  if (i >= p.c * plane) { return; }
  var v = x[i] / (1.0 + exp(-x[i + p.c * plane]));
  if (p.emb == 1u) {
    let ch = i / plane;
    v += emb[ch * p.h + (i - ch * plane) / p.w];
  }
  y[i] = v;
}
`,I=`
struct P { n: u32 }
@group(0) @binding(0) var<storage, read_write> x: array<f32>;
@group(0) @binding(1) var<storage, read> y: array<f32>;
@group(0) @binding(2) var<uniform> p: P;
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3u, @builtin(num_workgroups) groups: vec3u) {
  let i = id.x + id.y * groups.x * 256u;
  if (i < p.n) { x[i] = x[i] + y[i]; }
}
`,oe=`
struct P { n: u32 }
@group(0) @binding(0) var<storage, read_write> x: array<f32>;
@group(0) @binding(1) var<storage, read> stats: array<f32>;
@group(0) @binding(2) var<uniform> p: P;
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3u, @builtin(num_workgroups) groups: vec3u) {
  let i = id.x + id.y * groups.x * 256u;
  if (i < p.n) { x[i] = (x[i] - stats[0]) * stats[1]; }
}
`,se=`
struct P { c: u32, n: u32, pos: u32 }
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read> gamma: array<f32>;
@group(0) @binding(2) var<storage, read> beta: array<f32>;
@group(0) @binding(3) var<storage, read> pos: array<f32>;
@group(0) @binding(4) var<storage, read_write> y: array<f32>;
@group(0) @binding(5) var<uniform> p: P;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let t = id.x;
  if (t >= p.n) { return; }
  var s = 0.0;
  for (var ch = 0u; ch < p.c; ch++) { s += x[ch * p.n + t]; }
  let mean = s / f32(p.c);
  var q = 0.0;
  for (var ch = 0u; ch < p.c; ch++) { let d = x[ch * p.n + t] - mean; q = fma(d, d, q); }
  let rstd = 1.0 / sqrt(q / f32(p.c) + 1e-5);
  for (var ch = 0u; ch < p.c; ch++) {
    var v = (x[ch * p.n + t] - mean) * rstd * gamma[ch] + beta[ch];
    if (p.pos == 1u) { v += pos[ch * p.n + t]; }
    y[ch * p.n + t] = v;
  }
}
`,ce=(e=`f32`)=>`
${N(e)}
struct P { nq: u32, nk: u32, qr0: u32, kr0: u32, head0: u32 }
@group(0) @binding(0) var<storage, read> q: array<f32>;
@group(0) @binding(1) var<storage, read> kv: array<f32>;
@group(0) @binding(2) var<storage, read_write> s: array<f32>;
@group(0) @binding(3) var<uniform> p: P;
${A(e)} // [16 d][16 query quads], [16 d][16 key quads]
@compute @workgroup_size(16, 16)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_id) l: vec3u, @builtin(local_invocation_index) li: u32) {
  let h = p.head0 + wg.z;
  let row0 = wg.y * 64u;
  let col0 = wg.x * 64u;
  var acc: array<vec4f, 4>;
  for (var d0 = 0u; d0 < 64u; d0 += 16u) {
    // Invocation li: queries and keys 4 (li % 16).. at dimension li / 16.
    let d = d0 + li / 16u;
    var av = vec4f(0.0);
    var bv = vec4f(0.0);
    for (var c = 0u; c < 4u; c++) {
      let e = (li % 16u) * 4u + c;
      let i = row0 + e;
      let j = col0 + e;
      av[c] = select(0.0, q[(p.qr0 + h * 64u + d) * p.nq + min(i, p.nq - 1u)], i < p.nq);
      bv[c] = select(0.0, kv[(p.kr0 + h * 64u + d) * p.nk + min(j, p.nk - 1u)], j < p.nk);
    }
    as_[li] = ${j(e,`av`)};
    bs_[li] = ${j(e,`bv`)};
    workgroupBarrier();${M(e)}
    workgroupBarrier();
  }
  for (var i = 0u; i < 4u; i++) {
    let r = row0 + l.y * 4u + i;
    if (r >= p.nq) { continue; }
    for (var j = 0u; j < 4u; j++) {
      let c = col0 + l.x * 4u + j;
      if (c < p.nk) { s[(wg.z * p.nq + r) * p.nk + c] = acc[i][j]; }
    }
  }
}
`,le=`
struct P { nk: u32 }
@group(0) @binding(0) var<storage, read_write> s: array<f32>;
@group(0) @binding(1) var<uniform> p: P;
var<workgroup> red: array<f32, 256>;
@compute @workgroup_size(256)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(num_workgroups) groups: vec3u, @builtin(local_invocation_index) li: u32) {
  let base = (wg.x + wg.y * groups.x) * p.nk;
  var m = -3.0e38;
  for (var j = li; j < p.nk; j += 256u) { m = max(m, s[base + j]); }
  red[li] = m;
  workgroupBarrier();
  for (var span = 128u; span > 0u; span >>= 1u) {
    if (li < span) { red[li] = max(red[li], red[li + span]); }
    workgroupBarrier();
  }
  m = red[0];
  workgroupBarrier();
  var sum = 0.0;
  for (var j = li; j < p.nk; j += 256u) {
    let e = exp(s[base + j] - m);
    s[base + j] = e;
    sum += e;
  }
  red[li] = sum;
  workgroupBarrier();
  for (var span = 128u; span > 0u; span >>= 1u) {
    if (li < span) { red[li] += red[li + span]; }
    workgroupBarrier();
  }
  let inv = 1.0 / red[0];
  for (var j = li; j < p.nk; j += 256u) { s[base + j] *= inv; }
}
`,ue=(e=`f32`)=>`
${N(e)}
struct P { nq: u32, nk: u32, vr0: u32, head0: u32 }
@group(0) @binding(0) var<storage, read> s: array<f32>;
@group(0) @binding(1) var<storage, read> kv: array<f32>;
@group(0) @binding(2) var<storage, read_write> o: array<f32>;
@group(0) @binding(3) var<uniform> p: P;
${A(e)} // [16 keys][16 query quads], [16 keys][16 d quads]
@compute @workgroup_size(16, 16)
fn main(@builtin(workgroup_id) wg: vec3u, @builtin(local_invocation_id) l: vec3u, @builtin(local_invocation_index) li: u32) {
  let h = p.head0 + wg.z;
  let row0 = wg.y * 64u;
  var acc: array<vec4f, 4>;
  for (var j0 = 0u; j0 < p.nk; j0 += 16u) {
    // Invocation li: queries and dimensions 4 (li / 16).. at key li % 16.
    let jj = li % 16u;
    let j = j0 + jj;
    var a = vec4f(0.0);
    var b = vec4f(0.0);
    for (var c = 0u; c < 4u; c++) {
      let r = (li / 16u) * 4u + c;
      let i = row0 + r;
      if (j < p.nk) {
        if (i < p.nq) { a[c] = s[(wg.z * p.nq + i) * p.nk + j]; }
        b[c] = kv[(p.vr0 + h * 64u + r) * p.nk + j];
      }
    }
    as_[jj * 16u + li / 16u] = ${j(e,`a`)};
    bs_[jj * 16u + li / 16u] = ${j(e,`b`)};
    workgroupBarrier();${M(e)}
    workgroupBarrier();
  }
  for (var i = 0u; i < 4u; i++) {
    let r = row0 + l.y * 4u + i;
    if (r >= p.nq) { continue; }
    for (var j = 0u; j < 4u; j++) {
      let d = l.x * 4u + j;
      o[(h * 64u + d) * p.nq + r] = acc[i][j];
    }
  }
}
`,de=4096,fe=`
struct P { frames: u32, len: u32 }
@group(0) @binding(0) var<storage, read> mix: array<f32>;      // [2, len]
@group(0) @binding(1) var<storage, read> win: array<f32>;
@group(0) @binding(2) var<storage, read> tw: array<vec2f>;
@group(0) @binding(3) var<storage, read_write> y: array<vec2f>;  // [2 frames, 64 k1, 64 n2]
@group(0) @binding(4) var<uniform> p: P;
fn reflect(i: i32, n: i32) -> i32 {
  var j = select(i, -i, i < 0);
  return select(j, 2 * (n - 1) - j, j >= n);
}
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let n2 = id.x;
  let k1 = id.y;
  let s = id.z;
  if (n2 >= 64u || k1 >= 64u || s >= 2u * p.frames) { return; }
  let ch = s / p.frames;
  let f = s - ch * p.frames;
  let padded = i32(p.len) + 3072;
  var acc = vec2f(0.0);
  for (var n1 = 0u; n1 < 64u; n1++) {
    let n = n1 * 64u + n2;
    let at = reflect(reflect(i32((f + 2u) * 1024u + n) - 2048, padded) - 1536, i32(p.len));
    let v = mix[ch * p.len + u32(at)] * win[n];
    let t = tw[((k1 * n1) % 64u) * 64u];
    acc += v * vec2f(t.x, -t.y);
  }
  let t = tw[k1 * n2];
  y[(s * 64u + k1) * 64u + n2] = vec2f(acc.x * t.x + acc.y * t.y, acc.y * t.x - acc.x * t.y);
}
`,pe=`
struct P { frames: u32 }
@group(0) @binding(0) var<storage, read> y: array<vec2f>;
@group(0) @binding(1) var<storage, read> tw: array<vec2f>;
@group(0) @binding(2) var<storage, read_write> spec: array<f32>;
@group(0) @binding(3) var<uniform> p: P;
@compute @workgroup_size(32)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let k2 = id.x;
  let k1 = id.y;
  let s = id.z;
  if (k2 >= 32u || k1 >= 64u || s >= 2u * p.frames) { return; }
  var acc = vec2f(0.0);
  for (var n2 = 0u; n2 < 64u; n2++) {
    let v = y[(s * 64u + k1) * 64u + n2];
    let t = tw[((k2 * n2) % 64u) * 64u];
    acc += vec2f(v.x * t.x + v.y * t.y, v.y * t.x - v.x * t.y);
  }
  let ch = s / p.frames;
  let f = s - ch * p.frames;
  let k = k1 + 64u * k2;
  spec[((ch * 2u) * 2048u + k) * p.frames + f] = acc.x;
  spec[((ch * 2u + 1u) * 2048u + k) * p.frames + f] = acc.y;
}
`,me=`
struct P { frames: u32, source: u32 }
@group(0) @binding(0) var<storage, read> z: array<f32>;     // [16, 2048, frames]
@group(0) @binding(1) var<storage, read> stats: array<f32>;
@group(0) @binding(2) var<storage, read> tw: array<vec2f>;
@group(0) @binding(3) var<storage, read_write> y: array<vec2f>;
@group(0) @binding(4) var<uniform> p: P;
fn bin(ch: u32, f: u32, k: u32) -> vec2f {
  let kk = select(k, 4096u - k, k > 2048u);
  if (kk == 2048u) { return vec2f(0.0); }
  let base = (p.source * 4u + ch * 2u) * 2048u + kk;
  let re = z[base * p.frames + f] * stats[2] + stats[0];
  let im = z[(base + 2048u) * p.frames + f] * stats[2] + stats[0];
  return select(vec2f(re, im), vec2f(re, -im), k > 2048u);
}
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let n2 = id.x;
  let k1 = id.y;
  let s = id.z;
  if (n2 >= 64u || k1 >= 64u || s >= 2u * p.frames) { return; }
  let ch = s / p.frames;
  let f = s - ch * p.frames;
  var acc = vec2f(0.0);
  for (var k2 = 0u; k2 < 64u; k2++) {
    let v = bin(ch, f, k1 + 64u * k2);
    let t = tw[((k2 * n2) % 64u) * 64u];
    acc += vec2f(v.x * t.x - v.y * t.y, v.x * t.y + v.y * t.x);
  }
  let t = tw[k1 * n2];
  y[(s * 64u + k1) * 64u + n2] = vec2f(acc.x * t.x - acc.y * t.y, acc.x * t.y + acc.y * t.x);
}
`,he=`
struct P { frames: u32 }
@group(0) @binding(0) var<storage, read> y: array<vec2f>;
@group(0) @binding(1) var<storage, read> tw: array<vec2f>;
@group(0) @binding(2) var<storage, read> win: array<f32>;
@group(0) @binding(3) var<storage, read_write> out: array<f32>;  // [2 frames, 4096]
@group(0) @binding(4) var<uniform> p: P;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let n2 = id.x;
  let n1 = id.y;
  let s = id.z;
  if (n2 >= 64u || n1 >= 64u || s >= 2u * p.frames) { return; }
  var acc = 0.0;
  for (var k1 = 0u; k1 < 64u; k1++) {
    let v = y[(s * 64u + k1) * 64u + n2];
    let t = tw[((k1 * n1) % 64u) * 64u];
    acc += v.x * t.x - v.y * t.y;
  }
  let n = n1 * 64u + n2;
  out[s * 4096u + n] = acc / 4096.0 * win[n];
}
`,ge=`
struct P { frames: u32, len: u32, source: u32, out_at: u32 }
@group(0) @binding(0) var<storage, read> fr: array<f32>;
@group(0) @binding(1) var<storage, read> env: array<f32>;
@group(0) @binding(2) var<storage, read> xt: array<f32>;      // [8, len]
@group(0) @binding(3) var<storage, read> tstats: array<f32>;
@group(0) @binding(4) var<storage, read_write> out: array<f32>; // [2, len] at out_at (one per source asked for)
@group(0) @binding(5) var<uniform> p: P;
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) id: vec3u, @builtin(num_workgroups) groups: vec3u) {
  let i = id.x + id.y * groups.x * 256u;
  if (i >= 2u * p.len) { return; }
  let ch = i / p.len;
  let j = i - ch * p.len;
  let pos = 3584u + j;
  var acc = 0.0;
  let last = pos / 1024u;
  for (var jj = select(0u, last - 3u, last >= 3u); jj <= last; jj++) {
    if (jj < 2u || jj >= p.frames + 2u) { continue; }
    let n = pos - jj * 1024u;
    if (n < 4096u) { acc += fr[(ch * p.frames + jj - 2u) * 4096u + n]; }
  }
  let t = xt[(p.source * 2u + ch) * p.len + j] * tstats[2] + tstats[0];
  out[p.out_at + i] = acc / env[1536u + j] + t;
}
`,_e=172032,ve=[`drums`,`bass`,`other`,`vocals`],L=2048,ye=e=>e.reduce((e,t)=>e*t,1);var be=class e{constructor(e,t,n,r,i){this.device=e,this.steps=t,this.mixBuffer=n,this.outBuffer=r,this.owned=i,this.fineStages=/* @__PURE__ */ new Set,this.autoRuns=0}get bytes(){return this.owned.reduce((e,t)=>e+t.size,0)}static async create(t,n,r,i={}){var a,o;if(r.segment!==172032)throw Error(`htdemucs weights are for a ${r.segment}-sample segment, not ${_e}`);if(i.f16&&!t.features.has(`shader-f16`))throw Error(`htdemucs f16 needs a device opened with shader-f16`);let s=(a=i.sources)==null?[(o=i.source)==null?0:o]:a;if(s.length===0||s.some(e=>!(e>=0&&e<ve.length)))throw Error(`htdemucs sources must be indices into ${ve.join(`, `)}, got ${s.join(`, `)}`);let c=i.f16?`f16`:`f32`,l=ce(c),u=ue(c);t.pushErrorScope(`validation`);let d=_e,f=[],p=e=>{let n=t.createBuffer({size:Math.max(16,Math.ceil(e)*4),usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST});return f.push(n),n},m=p(Math.ceil(n.byteLength/4));t.queue.writeBuffer(m,0,n.buffer,n.byteOffset,n.byteLength);let h=e=>{let t=r.tensors[e];if(!t)throw Error(`htdemucs weights: missing tensor ${e}`);return t},g=e=>{let{byte_offset:t,shape:n,dtype:r}=h(e),i=ye(n)*(r===`f16`?2:4);return{buffer:m,offset:t,size:Math.ceil(i/4)*4}},_=e=>h(e).dtype===`f16`,v=e=>h(e).shape[0],y=new Float32Array(de*2);for(let e=0;e<de;e+=1)y[e*2]=Math.cos(2*Math.PI*e/de),y[e*2+1]=Math.sin(2*Math.PI*e/de);let b=p(y.length);t.queue.writeBuffer(b,0,y);let x=L/4*48*168,S=p(2*d),C=p(2*d*s.length),w=p(4),T=p(4),E=p(4*L),D=p(4096),O=p(64),k=p(2752512),A=p(4*L*168),j=p(x),M=p(x/8),N=p(2*x),P=[p(16*L*168),p(16*L*168)],be=p(16*L*168),R=p(8*d),z=p(1376256),B=[],V=[];for(let e=0;e<4;e+=1)B.push(p(48*2**e*(L/4**(e+1))*168)),V.push(p(48*2**e*(d/4**(e+1))));let H=1344,U=p(512*H),W=p(344064),xe=p(512*H),Se=p(344064),Ce=p(512*H),we=p(344064),Te=p(1536*H),Ee=p(1032192),De=p(688128),Oe=p(1024*H),ke=p(512*H),Ae=p(344064),je=p(2048*H),Me=p(4*H*H),Ne=/* @__PURE__ */ new Map,Pe=e=>{let n=Ne.get(e);return n||(n=t.createComputePipeline({layout:`auto`,compute:{module:t.createShaderModule({code:e}),entryPoint:`main`}}),Ne.set(e,n)),n},Fe=e=>{let n=new Uint32Array(Math.ceil(e.length/4)*4);n.set(e);let r=t.createBuffer({size:n.byteLength,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return t.queue.writeBuffer(r,0,n),f.push(r),r},Ie=[],G=`input`,Le=/* @__PURE__ */ new Map([[I,`add`],[u,`attn_out`],[l,`attn_scores`],[le,`softmax`],[F,`glu`],[ae,`gn_glu`],[ie,`gn`],[me,`istft_a`],[he,`istft_b`],[se,`layer_norm`],[oe,`normalize`],[ge,`overlap_add`],[re,`stats_final`],[ne,`stats`],[fe,`stft_a`],[pe,`stft_b`]]),K=(e,n,r,i,a=``)=>{var o;let s=Pe(e),c=[...n,Fe(r)].map((e,t)=>({binding:t,resource:e instanceof GPUBuffer?{buffer:e}:e})),l=`${G} ${(o=Le.get(e))==null?`gemm`:o}${a?` ${a}`:``}`;Ie.push({kind:`dispatch`,label:l,pipeline:s,group:t.createBindGroup({layout:s.getBindGroupLayout(0),entries:c}),count:i})},q=e=>{let t=Math.ceil(e/256),n=Math.min(t,32768);return[n,Math.ceil(t/n),1]},J=(e,t,n)=>Ie.push({kind:`stage`,name:e,buffer:t,floats:n}),Re=(e,t,n,r,i,a,o,s)=>{let c=r*i,l=Math.max(1,Math.min(256,Math.floor(4096/n),Math.ceil(c/16384)));K(ne,[e,t,D],[l,r,i,a,o,0],[l,n,1]),K(re,[D,t],[l,c,0],[n,1,1]),K(ne,[e,t,D],[l,r,i,a,o,1],[l,n,1]),K(re,[D,t],[l,c,s],[n,1,1])},ze=(e,t,n,r,i)=>{i?Re(e,E,n,t,r,n*r,r,1):Re(e,E,1,1,t*n*r,0,0,1)},Y=(e,t,n,r,i=0,a=O)=>{let{sh:o=1,sw:s=1,ph:l=0,pw:u=0,dh:d=1,dw:f=1}=r,p=v(`${t}.w`),m=h(`${t}.w`).shape[1],y=m/(r.kh*r.kw),b=Math.floor((r.hin+2*l-d*(r.kh-1)-1)/o)+1,x=Math.floor((r.win+2*u-f*(r.kw-1)-1)/s)+1;return K(ee(_(`${t}.w`),c),[e,g(`${t}.w`),g(`${t}.b`),a,n],[p,m,y,r.kh,r.kw,o,s,l,u,d,f,r.hin,r.win,b,x,i],[Math.ceil(b*x/64),Math.ceil(p/64),1],t.split(`.`).slice(1).join(`.`)),[b,x]},Be=(e,t,n,r,i,a,o)=>{let s=v(`${t}.w`),l=h(`${t}.w`).shape[1],u=a===0?(r+1)*i:r*(i+1);K(te(_(`${t}.w`),c),[e,g(`${t}.w`),g(`${t}.b`),n],[s,l,l/2,r,i,a,o],[Math.ceil(u/64),Math.ceil(s/64),1],`tr`)},Ve=(e,t,n,r,i)=>{for(let a=0;a<2;a+=1){let o=`${e}.dc${a}`,s=2**a,c=v(`${o}.c1.w`);Y(j,`${o}.c1`,M,{hin:n,win:r,kh:1,kw:3,pw:s,dw:s}),ze(M,c,n,r,i),K(ie,[M,E,g(`${o}.n1.g`),g(`${o}.n1.b`)],[c,n,r,+!!i,1],q(c*n*r)),Y(M,`${o}.c2`,N,{hin:n,win:r,kh:1,kw:1}),ze(N,2*t,n,r,i),K(ae,[N,E,g(`${o}.n2.g`),g(`${o}.n2.b`),g(`${o}.ls`),j],[t,n,r,+!!i],q(t*n*r))}},He=R;Re(S,w,1,1,2*d,0,0,2),Ie.push({kind:`copy`,from:S,to:He,bytes:2*d*4}),K(oe,[He,w],[2*d],q(2*d)),K(fe,[S,g(`stft.window`),b,k],[168,d],[1,64,336]),K(pe,[k,b,A],[168],[1,64,336]),Re(A,T,1,1,4*L*168,0,0,2),K(oe,[A,T],[4*L*168],q(4*L*168)),J(`norm_spec`,A,4*L*168);let Ue=He,We=A,X=d,Z=L;for(let e=0;e<4;e+=1){let t=48*2**e;G=`tenc${e}`;let[,n]=Y(Ue,`tenc${e}.conv`,j,{hin:1,win:X,kh:1,kw:8,sw:4,pw:2},1);X=n,Ve(`tenc${e}`,t,1,X,!1),Y(j,`tenc${e}.rw`,N,{hin:1,win:X,kh:1,kw:1}),K(F,[N,O,V[e]],[t,1,X,0],q(t*X)),J(`tenc${e}`,V[e],t*X),Ue=V[e],G=`enc${e}`;let[r]=Y(We,`enc${e}.conv`,j,{hin:Z,win:168,kh:8,kw:1,sh:4,ph:2},1);Z=r,Ve(`enc${e}`,t,Z,168,!0),Y(j,`enc${e}.rw`,N,{hin:Z,win:168,kh:1,kw:1}),K(F,[N,e===0?g(`freq_emb`):O,B[e]],[t,Z,168,+(e===0)],q(t*Z*168)),J(`enc${e}`,B[e],t*Z*168),We=B[e]}G=`tf_in`,Y(B[3],`up`,xe,{hin:1,win:H,kh:1,kw:1}),Y(V[3],`up_t`,Se,{hin:1,win:672,kh:1,kw:1}),K(se,[xe,g(`norm_in.g`),g(`norm_in.b`),g(`pos`),U],[512,H,1],[21,1,1]),K(se,[Se,g(`norm_in_t.g`),g(`norm_in_t.b`),g(`pos_t`),W],[512,672,1],[11,1,1]),J(`tf_in`,U,512*H),J(`tf_in_t`,W,344064);let Ge=(e,t,n,r)=>K(se,[e,g(`${t}.g`),g(`${t}.b`),O,n],[512,r,0],[Math.ceil(r/64),1,1]),Q=(e,t,n,r,i=0,a=O)=>Y(e,t,n,{hin:1,win:r,kh:1,kw:1},i,a),Ke=(e,t,n,r,i,a,o,s)=>{for(let c=0;c<8;c+=4){let d=`heads ${c}-${c+4-1}`;K(l,[e,t,Me],[r,i,a,o,c],[Math.ceil(i/64),Math.ceil(r/64),4],d);let f=4*r,p=Math.min(f,32768);K(le,[Me],[i],[p,Math.ceil(f/p),1],d),K(u,[Me,t,n],[r,i,s,c],[1,Math.ceil(r/64),4],d)}},qe=(e,t,n,r)=>{Ge(e,`${t}.nf`,r,n),Q(r,`${t}.ff1`,je,n,1),Q(je,`${t}.ff2`,e,n,2,g(`${t}.g2`)),Re(e,E,1,1,512*n,0,0,1),K(ie,[e,E,g(`${t}.no.g`),g(`${t}.no.b`)],[512,1,n,0,0],q(512*n))};for(let e=0;e<5;e+=1){let t=`tf${e}`,n=`tft${e}`;if(G=t,e%2==0)for(let[e,r,i,a,o,s]of[[U,t,H,xe,Te,ke],[W,n,672,Se,Ee,Ae]])Ge(e,`${r}.n1`,a,i),Q(a,`${r}.qkv`,o,i),Ke(o,o,s,i,i,0,512,1024),Q(s,`${r}.out`,e,i,2,g(`${r}.g1`)),qe(e,r,i,a);else Ge(U,`${t}.n1`,xe,H),Q(xe,`${t}.q`,Te,H),Ge(W,`${t}.nkv`,we,672),Q(we,`${t}.kv`,De,672),Ge(W,`${n}.n1`,Se,672),Q(Se,`${n}.q`,Ee,672),Ge(U,`${n}.nkv`,Ce,H),Q(Ce,`${n}.kv`,Oe,H),Ke(Te,De,ke,H,672,0,0,512),Ke(Ee,Oe,Ae,672,H,0,0,512),Q(ke,`${t}.out`,U,H,2,g(`${t}.g1`)),Q(Ae,`${n}.out`,W,672,2,g(`${n}.g1`)),qe(U,t,H,xe),qe(W,n,672,Se);J(`tf${e}`,U,512*H),J(`tft${e}`,W,344064)}let $=P[0];G=`dec0`,Q(U,`down`,$,H);for(let e=0;e<4;e+=1){let t=48*2**(3-e);G=`dec${e}`;let n=Z*168;K(I,[$,B[3-e]],[t*n],q(t*n)),Y($,`dec${e}.rw`,N,{hin:Z,win:168,kh:3,kw:3,ph:1,pw:1}),K(F,[N,O,j],[t,Z,168,0],q(t*n)),Ve(`dec${e}`,t,Z,168,!0);let r=e===3?be:P[(e+1)%2];Be(j,`dec${e}.tr`,r,Z,168,0,e===3?0:1),Z*=4,J(`dec${e}`,r,v(`dec${e}.tr.w`)/4*Z*168),$=r}$=P[0],G=`tdec0`,Q(W,`down_t`,$,672);for(let e=0;e<4;e+=1){let t=48*2**(3-e);G=`tdec${e}`,K(I,[$,V[3-e]],[t*X],q(t*X)),Y($,`tdec${e}.rw`,N,{hin:1,win:X,kh:1,kw:3,pw:1}),K(F,[N,O,j],[t,1,X,0],q(t*X)),Ve(`tdec${e}`,t,1,X,!1);let n=e===3?R:P[(e+1)%2];Be(j,`tdec${e}.tr`,n,1,X,1,e===3?0:1),X*=4,J(`tdec${e}`,n,v(`tdec${e}.tr.w`)/4*X),$=n}G=`output`,s.forEach((e,t)=>{K(me,[be,T,b,k],[168,e],[1,64,336],ve[e]),K(he,[k,b,g(`istft.window`),z],[168],[1,64,336],ve[e]),K(ge,[z,g(`istft.env`),R,w,C],[168,d,e,t*2*d],q(2*d),ve[e]),t<s.length-1&&J(`out_${ve[e]}`,C,2*d*(t+1))}),J(`out`,C,2*d*s.length);let Je=await t.popErrorScope();if(Je)throw f.forEach(e=>e.destroy()),Error(`htdemucs graph rejected: ${Je.message}`);let Ye=new e(t,Ie,S,C,f);return await t.queue.onSubmittedWorkDone(),Ye}async run(e,t,n={}){var r,i;let a=_e;if(e.length!==a||t.length!==a)throw Error(`htdemucs segment must be ${a} samples per channel, got ${e.length} and ${t.length}`);let{device:o}=this;o.queue.writeBuffer(this.mixBuffer,0,e.buffer,e.byteOffset,e.byteLength),o.queue.writeBuffer(this.mixBuffer,a*4,t.buffer,t.byteOffset,t.byteLength);let s=o.createCommandEncoder(),c=null,l=[],u=0,d=0,f=(r=n.slice)==null?`none`:r,p=async()=>{c==null||c.end(),c=null;let e=performance.now();o.queue.submit([s.finish()]),await o.queue.onSubmittedWorkDone();let t=performance.now()-e;return u+=t,d+=1,s=o.createCommandEncoder(),t},m=(i=n.budgetMs)==null?8:i,h=[],g=``;f===`auto`&&++this.autoRuns%50==0&&this.fineStages.clear();let _=0,v=performance.now();for(let e of this.steps){if((f===`dispatch`||f===`auto`&&this.fineStages.has(_))&&c){let e=await p();n.timings&&h.push({label:g,ms:e})}if(e.kind===`dispatch`){g=e.label,c!=null||(c=s.beginComputePass()),c.setPipeline(e.pipeline),c.setBindGroup(0,e.group),c.dispatchWorkgroups(...e.count);continue}if(e.kind===`copy`){c==null||c.end(),c=null,s.copyBufferToBuffer(e.from,0,e.to,0,e.bytes);continue}if((f===`stage`||f===`auto`&&!this.fineStages.has(_))&&e.name!==`out`){let e=await p();f===`auto`&&e>m&&this.fineStages.add(_)}if(_+=1,!n.stages&&e.name!==`out`)continue;c==null||c.end(),c=null;let t=o.createBuffer({size:e.floats*4,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});s.copyBufferToBuffer(e.buffer,0,t,0,e.floats*4),l.push({name:e.name,buffer:t})}await p();let y=performance.now()-v,x={};for(let{name:e,buffer:t}of l)await t.mapAsync(GPUMapMode.READ),x[e]=new Float32Array(t.getMappedRange().slice(0)),t.destroy();let S=x.out;n.stages||delete x.out;let C=Array.from({length:S.length/(2*a)},(e,t)=>({left:S.subarray(t*2*a,t*2*a+a),right:S.subarray(t*2*a+a,(t+1)*2*a)}));return b(b({left:C[0].left,right:C[0].right,stems:C,gpuMs:u,wallMs:y,slices:d},n.stages?{stages:x}:{}),n.timings?{timings:h}:{})}destroy(){this.owned.forEach(e=>e.destroy())}};const R=/* @__PURE__ */ new Map;let z=null,B=null,V=``,H=``,U=!1,W=null;const xe=async()=>{if(B)return B;if(!navigator.gpu)throw Error(`no WebGPU in this worker`);let e=await navigator.gpu.requestAdapter({powerPreference:`high-performance`});if(!e)throw Error(`no WebGPU adapter`);U=e.features.has(`shader-f16`);let t=await e.requestDevice({requiredFeatures:U?[`shader-f16`]:[]});return t.lost.then(e=>{W=`device lost (${e.reason}): ${e.message}`,R.clear(),z=null}),H=`${e.info.vendor} ${e.info.architecture}`,V=`${H}${U?` f16`:``}`,B=t,t};self.onmessage=async e=>{let t=e.data;try{if(t.kind===`load`){var n;let e;try{e=await xe()}catch(e){var r;self.postMessage({id:t.id,error:String((r=e==null?void 0:e.message)==null?e:r),scope:`device`});return}if(t.model===`htdemucs`){if(!z)try{z=await be.create(e,t.weights,t.manifest,{sources:[0,1,2,3]})}catch(e){var i;self.postMessage({id:t.id,error:String((i=e==null?void 0:e.message)==null?e:i),scope:`model`});return}self.postMessage({id:t.id,result:`${H} f32`,bytes:z==null?void 0:z.bytes});return}if(!R.has(t.model))try{R.set(t.model,await w.create(e,t.weights,t.manifest,{f16:U?`storage`:void 0}))}catch(e){var a;self.postMessage({id:t.id,error:String((a=e==null?void 0:e.message)==null?e:a),scope:`model`});return}self.postMessage({id:t.id,result:V,bytes:(n=R.get(t.model))==null?void 0:n.bytes});return}if(t.kind===`percussive`){let e;try{e=await xe()}catch(e){var o;self.postMessage({id:t.id,error:String((o=e==null?void 0:e.message)==null?e:o),scope:`device`});return}if(W)throw Error(W);let n=await D(e,t.mel,t.frames);self.postMessage({id:t.id,result:n},{transfer:[n.percussive.buffer,n.total.buffer]});return}if(t.kind===`separate`){if(W)throw Error(W);if(!z)throw Error(`htdemucs not loaded`);let{stems:e}=await z.run(t.left,t.right,{slice:`auto`});self.postMessage({id:t.id,result:{stems:e}},{transfer:[e[0].left.buffer]});return}if(t.kind===`unload`){if(t.model===`htdemucs`)z==null||z.destroy(),z=null;else{var s;(s=R.get(t.model))==null||s.destroy(),R.delete(t.model)}self.postMessage({id:t.id,result:!0});return}if(t.kind===`dispose`){for(let e of R.values())e.destroy();R.clear(),z==null||z.destroy(),z=null,B==null||B.destroy(),self.postMessage({id:t.id,result:!0});return}let e=R.get(t.model),l=[],u=[];for(let n of t.chunks){if(W)throw Error(W);if(!e)throw Error(`${t.model} not loaded`);let r=await e.run(n,{slice:`auto`});l.push(r.beat.slice()),u.push(r.downbeat.slice())}let d;if(t.percussive&&B&&!W)try{d=await D(B,t.percussive.mel,t.percussive.frames)}catch(e){var c;console.warn(`[beat-this-gpu] percussive energy failed: ${(c=e==null?void 0:e.message)==null?e:c}`)}let f=[...l,...u,...d?[d.percussive,d.total]:[]];self.postMessage({id:t.id,result:{beat:l,downbeat:u,percussive:d}},{transfer:f.map(e=>e.buffer)})}catch(e){var l;self.postMessage({id:t.id,error:String((l=e==null?void 0:e.message)==null?e:l)})}};