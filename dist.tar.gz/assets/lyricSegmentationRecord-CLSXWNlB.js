import{T as e}from"./three-CRVeZmyf.js";import{i as t,r as n}from"./wordSegmentation-BwAsv7Io.js";var r=[{params:{reasoning_effort:`none`}},{params:{chat_template_kwargs:{enable_thinking:!1}}},{params:{}}],i=`You segment song lyrics into words for a typography engine.

You receive numbered lyric lines. For each line, split it into the units a human reader would
treat as single words, and return them in order.

Hard rules, in priority order:
1. Lossless. Concatenating one line’s segments must reproduce that line character for character,
   including every space, punctuation mark and symbol. Never add, drop, reorder or normalise a
   character. Never translate, romanise, or correct spelling.
2. Same count. Return exactly one segment array per input line, in the same order.
3. Split at meaning, not at characters. For Chinese, Japanese and Korean, group characters into
   real words and set phrases (不知道 / 孤独的 / キラキラ), not one character per segment.
   Keep verb–complement and noun–suffix pairs together when they read as one word.
4. One word per segment. A segment carries a single content word plus the grammatical tail glued
   to it. If a segment still holds a second noun, verb or adjective, split it again. Spaces are
   not the only split points: a Japanese or Chinese line usually has none and still needs one
   segment per word. Returning a whole clause, or a whole line, as one segment is a failure.
5. Japanese specifically: split before every content word, and keep each content word together
   with the okurigana, auxiliaries and particles that follow it (見えない / ように / 集めたい /
   けど). Sentence-final particles (よ / ね / さ) attach to what precedes them.
6. Keep space-delimited words whole for Latin scripts, and keep contractions such as it’s or
   don’t in one segment.
7. Attach trailing punctuation to the segment it follows (世界。 not 世界 + 。). A bracket or quote
   stays in one segment with the text it wraps ((拼图女孩) not ( + 拼图女孩 + )). A space belongs
   to the segment that precedes it.
8. The "N. " prefix on each input line is numbering added by this request. It is NOT part of the
   lyric. Never include it in a segment.

Examples. Given:
  1. 把回忆拼好给你
  2. It’s unbelievable, isn’t it?
  3. いっぱいあるんだよ欲しいもの
  4. 見えないようにさ 隠しても
answer exactly:
  {"lines": [["把", "回忆", "拼好", "给", "你"], ["It’s ", "unbelievable, ", "isn’t ", "it?"], ["いっぱい", "あるんだよ", "欲しい", "もの"], ["見えない", "ように", "さ ", "隠しても"]]}

Respond with JSON only: {"lines": [["seg", "seg"], ["seg"]]}. No prose, no code fence.`,a=e=>{let t=e.map((e,t)=>`${t+1}. ${e}`).join(`
`);return`Segment these ${e.length} lyric lines.\n\n${t}`},o=e=>[i,``,`If you cannot produce JSON, answer with ${e.length} plain lines instead, separating words`,`with "/" and nothing else.`,``,a(e)].join(`
`),s=/\s/,c=(e,t)=>{if(e.join(``)===t)return e;let n=[],r=0;for(let i of e){let e=i.replace(/\s+/gu,``);if(!e)continue;let a=r,o=0;for(;r<t.length&&o<e.length;){let n=t[r];if(s.test(n))r+=1;else{if(n!==e[o])return null;o+=1,r+=1}}if(o<e.length)return null;n.push(t.slice(a,r))}if(n.length===0)return null;let i=t.slice(r);return i.trim()?null:(n[n.length-1]+=i,n)},l=e=>`${Math.round(e.startTime*1e3)}|${e.fullText}`,u=(e,t,n)=>({version:1,songKey:e,updatedAt:Date.now(),source:t,lines:n}),d=e=>{if(!e||typeof e!=`object`)return!1;let t=e;return t.version===1&&typeof t.songKey==`string`&&typeof t.updatedAt==`number`&&(t.source===`ai`||t.source===`manual`)&&!!t.lines&&typeof t.lines==`object`},f=(t,r)=>{if(!t||!r)return t;let i=!1,a=t.lines.map(t=>{let a=r.lines[l(t)];return n(t.fullText,a)?(i=!0,e(e({},t),{},{wordSegments:a})):t});return i?e(e({},t),{},{lines:a}):t},p=(e,t)=>!e||!t?0:e.lines.reduce((e,r)=>{let i=t.lines[l(r)];return n(r.fullText,i)?e+1:e},0),m=e=>e.lines.map(e=>t(e).map(e=>e.segment)),h=e=>m(e).map(e=>e.join(`/`)).join(`
`),g=class extends Error{constructor(e,t=null){super(e),this.name=`SegmentationImportError`,this.row=t}},_=e=>e.replace(/\r\n?/g,`
`).split(`
`).map(e=>e.split(`/`).filter(e=>e.length>0)),v=e=>{let t;try{t=JSON.parse(e)}catch(e){throw new g(`invalid-json`)}let n=Array.isArray(t)?t:t==null?void 0:t.lines;if(!Array.isArray(n)||!n.every(e=>Array.isArray(e)&&e.every(e=>typeof e==`string`)))throw new g(`invalid-json-shape`);return n},y=(e,t)=>{let r=e.replace(/\r\n?/g,`
`),i=r.trim();if(!i)throw new g(`empty`);let a=/^```[^\n]*\n([\s\S]*?)\n?```$/.exec(i),o=a?a[1]:r,s=/^[\[{]/.test(o.trimStart()),u=s?v(o.trim()):_(o),d=t.lines.filter(e=>!!e.fullText),f=()=>u.length===t.lines.length||u.length===d.length;if(!s&&!f()){let e=u.filter(e=>e.join(``).trim()!==``);e.length===d.length&&(u=e)}if(!f())throw new g(`line-count-mismatch`);let p=u.length===t.lines.length?t.lines:d,m={},h=0;if(u.forEach((e,t)=>{let r=p[t];if(!r.fullText){if(e.join(``))throw new g(`line-text-mismatch`,t+1);return}let i=c(e,r.fullText);if(!i||!n(r.fullText,i))throw new g(`line-text-mismatch`,t+1);m[l(r)]=i,h+=1}),h===0)throw new g(`empty`);return{lines:m,appliedCount:h}};export{u as a,y as c,p as i,r as l,f as n,l as o,h as r,d as s,g as t,o as u};