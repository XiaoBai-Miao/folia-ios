const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/dynamicIconImports-BjOCQR40.js","assets/preload-helper-l6fVzaRR.js","assets/stageLayerView-CEy1-pqa.js","assets/three-CRVeZmyf.js","assets/lucide-icons-CMXWxuRh.js","assets/noLyricLines-B-p7fl-W.js","assets/config-Dflnx4rn.js","assets/guard-BVyPvsUN.js","assets/noLyricLines-BBuVHDCs.css","assets/motionSignals-ryqt5AuR.js","assets/FoliumMountHost-CQrXhOCn.js","assets/alternateText-Cysn064e.js","assets/workerClient-DbgelPAH.js","assets/wordSegmentation-BwAsv7Io.js","assets/usePlaybackStore-COIAdFbi.js","assets/providerRegistry-B_nZn1zI.js","assets/platform-Dxn2vKCf.js","assets/staffCredits-CctSNbC5.js","assets/libraryTrace-BThNAXXq.js","assets/useVisualizerSettingsStore-DNJ9wZTD.js","assets/frameRateLimiter-CsRyFBcq.js","assets/urlBackground-hYExHnU2.js","assets/use-transform-B1zipTfl.js","assets/ColorField-Be0uiTWe.js","assets/registry-CSKRV85n.js","assets/tuningRegistry-BxWV7L2C.js","assets/glowBlurQuantize-CC5jpfBC.js","assets/useAppChromeStore-DBJXo_A1.js","assets/useAppViewStore-rznl0NWe.js","assets/kinds-BH-z2A0D.js","assets/stageContext-BBEwidLX.js","assets/audio-dmclc5eQ.js"])))=>i.map(i=>d[i]);
import{a as e,r as t,t as n}from"./preload-helper-l6fVzaRR.js";import{E as r,T as i}from"./three-CRVeZmyf.js";import{$ as a,$r as o,D as s,F as c,Fs as l,Nn as u,Ps as d,Ya as f,a as p,di as m,js as h,to as g,xn as _}from"./lucide-icons-CMXWxuRh.js";import{Ar as v,Cr as y,Dr as b,Jn as x,Tr as S,Xr as C,Zr as w,_r as T,en as E,gr as D,hi as O,hr as k,ti as ee,wr as te,zr as ne}from"./noLyricLines-B-p7fl-W.js";import{$t as A,Cn as re,Yt as ie,Zt as j,bn as ae,in as oe,yn as se}from"./config-Dflnx4rn.js";import{t as ce}from"./use-transform-B1zipTfl.js";import{C as le,Q as ue,T as de,V as fe,X as pe,Y as me,Z as he,_ as ge,a as _e,b as ve,f as M,l as ye,m as N,n as be,p as P,r as xe,s as Se}from"./urlBackground-hYExHnU2.js";import{f as Ce,l as F,o as we}from"./ColorField-Be0uiTWe.js";import{i as Te,o as Ee}from"./motionSignals-ryqt5AuR.js";var De=new Set,Oe=({timestamp:e})=>{De.forEach(t=>t.tick(e))},ke=class extends C{constructor(e){super(),this.state=`idle`,this.startTime=0,this.currentTime=0,this.started=!1,this.hasNextTarget=!1,this.nextTarget=0,this.stop=()=>{var e,t;this.state!==`idle`&&(this.teardown(),(e=(t=this.options).onStop)==null||e.call(t))},this.options=e,this.factory=e.type,this.generator=this.factory(e);let{driver:t}=e;t&&(this.driver=t(e=>this.tick(e))),this.startTime=this.now(),this.state=`running`,this.driver?this.driver.start():(De.size||ae.update(Oe,!0),De.add(this))}setTarget(e,t){this.nextTarget=e,this.nextVelocity=t,this.hasNextTarget=!0}retarget(e,t){let{options:n,generator:r}=this;n.keyframes=e,n.velocity=t,this.startTime=this.now(),this.currentTime=0,r.retarget?r.retarget(e,t):this.generator=this.factory(n)}tick(e){let{options:t,hasNextTarget:n}=this,{delay:r=0,onUpdate:i,onPlay:a}=t,o=Math.round(e-this.startTime)-r,s=this.currentTime=Math.max(0,o),c=this.generator.next(s),l=o<0?t.keyframes[0]:c.value;if(n){var u;this.hasNextTarget=!1;let{keyframes:e}=t;e[0]=l,e[1]=this.nextTarget,this.retarget(e,(u=this.nextVelocity)==null?this.getGeneratorVelocity():u)}if((n||!this.started)&&(this.started=!0,a==null||a()),this.state===`running`&&(i==null||i(l),c.done&&o>=0&&!n&&!this.hasNextTarget&&this.state===`running`)){var d;this.notifyFinished(),this.teardown(),this.state=`finished`,(d=t.onComplete)==null||d.call(t)}}getGeneratorVelocity(){return w(this.generator,this.currentTime,this.options.velocity)}now(){return this.driver?this.driver.now():re.now()}teardown(){this.state=`idle`,this.driver?this.driver.stop():(De.delete(this),De.size||se(Oe))}};function Ae(e,t,n){let r=e.get(),a=null,o,s=typeof r==`string`?r.replace(/[\d.-]/g,``):void 0,c=e=>o(s?e+s:e),l=()=>{var t;return(t=e.events.animationStart)==null?void 0:t.notify()},u=()=>{a&&(a.stop(),a=null),e.animation=void 0};if(e.attach((t,r)=>{o=r;let s=v(t);if((a==null?void 0:a.state)===`running`){a.setTarget(s,n.velocity);return}let d=v(e.get()),f=a?a.getGeneratorVelocity():e.getVelocity();if(u(),d===s)return;let p=i(i({keyframes:[d,s],velocity:f,restDelta:.001,restSpeed:.01},n),{},{onUpdate:c}),m=a=new ke(i(i({},p),{},{onPlay:l}));e.animation=m,m.then(()=>{var t;a===m&&(a=null,e.animation=void 0,(t=e.events.animationComplete)==null||t.notify())})},u),ne(t)){let r=n.skipInitialAnimation===!0,i=t.on(`change`,t=>{r?(r=!1,e.jump(je(t,s),!1)):e.set(je(t,s))}),a=e.on(`destroy`,i);return()=>{i(),a()}}return u}function je(e,t){return t?e+t:e}function Me(e,t,n){return Ae(e,t,i(i({},n),{},{type:ee}))}var I=e(l(),1);function Ne(e,t,n){let{isStatic:r}=(0,I.useContext)(b),i=()=>ne(e)?e.get():e;if(r)return ce(i);let a=y(i());return(0,I.useInsertionEffect)(()=>n(a,e,t),[a,JSON.stringify(t)]),a}function Pe(e,t={}){return Ne(e,t,Me)}var L=O(),Fe=e=>e,Ie={id:`bg-common`,titleKey:`options.visualizerBackgroundModeCommon`},Le={id:`bg-common-cover`,titleKey:`options.previewCoverBackgroundSettings`},Re=({config:e,actions:t,t:n,onSliderPointerDown:r,onSliderCommit:i})=>{var a,o,s,c;let l=e==null?void 0:e.common,u=t==null?void 0:t.common,d=(a=l==null?void 0:l.useCoverColorBg)!=null&&a;return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(fe,{def:Ie,bare:!0,children:[(0,L.jsx)(P,{label:n(`options.disableVisualizerVignette`),note:n(`options.disableVisualizerVignetteDesc`),checked:(o=l==null?void 0:l.disableVignette)!=null&&o,onChange:e=>{var t;return u==null||(t=u.onDisableVignetteChange)==null?void 0:t.call(u,e)}}),(0,L.jsx)(P,{label:n(`options.disableVisualizerGeometricBackground`),note:n(`options.disableVisualizerGeometricBackgroundDesc`),checked:(s=l==null?void 0:l.disableGeometricBackground)!=null&&s,onChange:e=>{var t;return u==null||(t=u.onDisableGeometricChange)==null?void 0:t.call(u,e)}})]}),(0,L.jsxs)(fe,{def:Le,children:[(0,L.jsx)(P,{label:n(`theme.addCoverColor`),note:n(`options.coverColorBackgroundDesc`),checked:d,onChange:e=>{var t;return u==null||(t=u.onCoverColorChange)==null?void 0:t.call(u,e)}}),(0,L.jsx)(Ce,{when:d,children:(0,L.jsx)(M,{sub:!0,label:n(`options.previewCoverBackgroundOpacity`),value:(c=l==null?void 0:l.opacity)==null?.75:c,min:0,max:1,step:.05,format:N,onChange:e=>{var t;return u==null||(t=u.onOpacityChange)==null?void 0:t.call(u,e)},onDragStart:r,onDragEnd:i})})]})]})},ze=384,Be=160,Ve=350,He=1e3,Ue=1e3,We=4e3,Ge=`data-picture-wait`,Ke=`data-picture-arriving`,qe={width:64,height:40},Je=null,Ye=e=>{if(!Je){let e=document.createElement(`canvas`);e.width=qe.width,e.height=qe.height,Je=e.getContext(`2d`,{willReadFrequently:!0}),Je&&(Je.imageSmoothingQuality=`high`)}if(!Je)return!1;try{Je.clearRect(0,0,qe.width,qe.height),Je.drawImage(e,0,0,qe.width,qe.height);let t=new Uint32Array(Je.getImageData(0,0,qe.width,qe.height).data.buffer);return t.every(e=>e===t[0])}catch(e){return Je=null,!1}},Xe=e=>[...e.querySelectorAll(`canvas`)].filter(e=>e.width>0&&e.height>0).map(e=>({canvas:e,blank:Ye(e)})),Ze=60,Qe=e=>[...e.querySelectorAll(`*`)].slice(0,Ze).some(e=>{let t=getComputedStyle(e);return!!t.backgroundImage&&t.backgroundImage!==`none`&&t.opacity!==`0`&&e.offsetWidth>0&&e.offsetHeight>0}),$e=e=>{var t;if(!e.firstElementChild||e.querySelector(`[data-picture-wait]`))return{shows:!1,whole:!1,waits:!1};let n=Xe(e),r=n.every(e=>!e.blank),i=n.some(e=>!e.blank)||!!((t=e.textContent)!=null&&t.trim())||e.querySelector(`svg, img`)!==null,a=!i&&Qe(e),o=e.querySelector(`[${Ke}]`)!==null;return{shows:i||a,whole:r,waits:o||a&&!r}},et=e=>e.getAnimations({subtree:!0}).some(e=>{var t;return e.playState===`running`&&Number.isFinite(Number((t=e.effect)==null?void 0:t.getComputedTiming().endTime))}),tt=(e,t,n)=>{let r=performance.now(),i=r,a=0,o=0,s=0,c=new MutationObserver(()=>{i=performance.now()});t===`still`&&c.observe(e,{subtree:!0,childList:!0,attributes:!0,characterData:!0});let l=()=>{c.disconnect(),window.clearTimeout(o),window.cancelAnimationFrame(s)},u=()=>{o=window.setTimeout(()=>{s=window.requestAnimationFrame(f)})},d=()=>{let n=performance.now(),{shows:o,whole:s,waits:c}=$e(e),l=o&&!c;return l&&!a&&(a=n),l&&(s||n-a>=Ue)&&(t===`drawn`||n-a>=Ve&&(n-i>=Be&&!et(e)||n-a>=He))?`shown`:n-r>=We?o?`shown`:`empty`:null},f=()=>{let e;try{e=d()}catch(t){console.warn(`[LivePicture] A stage could not be read:`,t),e=`failed`}e?(l(),n(e)):u()};return u(),l},nt=(e,t,n=Math.min(e.width,ze))=>{t.width=Math.max(1,n),t.height=Math.max(1,Math.round(e.height*n/Math.max(1,e.width)));let r=t.getContext(`2d`);r&&(r.imageSmoothingQuality=`high`,r.drawImage(e,0,0,t.width,t.height))},rt=e=>e.replace(/[A-Z]/g,e=>`-${e.toLowerCase()}`),it=e=>{if(!$e(e).shows)return null;let t=e.cloneNode(!0),n=t.querySelectorAll(`canvas`);e.querySelectorAll(`canvas`).forEach((e,t)=>{let r=n[t];r.style.width=`${e.offsetWidth}px`,r.style.height=`${e.offsetHeight}px`,e.width>0&&e.height>0&&nt(e,r)});let r=[...e.querySelectorAll(`*`)],i=t.querySelectorAll(`*`);i.forEach(e=>{e.style.willChange=`auto`});for(let t of e.getAnimations({subtree:!0})){let e=t.effect,n=e!=null&&e.target&&!e.pseudoElement?i[r.indexOf(e.target)]:void 0;if(!(e!=null&&e.target)||!n)continue;let a=getComputedStyle(e.target);for(let t of e.getKeyframes())for(let e of Object.keys(t))e!==`offset`&&e!==`computedOffset`&&e!==`easing`&&e!==`composite`&&n.style.setProperty(rt(e),a.getPropertyValue(rt(e)));n.style.animation=`none`}return t},at=e=>{let t=new Set(e.querySelectorAll(`canvas`)),n=e=>{for(let n of e)n.addedNodes.forEach(e=>{e instanceof HTMLCanvasElement?t.add(e):e instanceof Element&&e.querySelectorAll(`canvas`).forEach(e=>t.add(e))})},r=new MutationObserver(n);return r.observe(e,{subtree:!0,childList:!0}),()=>{n(r.takeRecords()),r.disconnect();for(let n of t)try{var e;if(n.getContext(`2d`))continue;let t=(e=n.getContext(`webgl2`))==null?n.getContext(`webgl`):e;if(t&&!t.isContextLost()){var i;(i=t.getExtension(`WEBGL_lose_context`))==null||i.loseContext()}}catch(e){}}},ot=e=>{let t=e.cloneNode(!0),n=t.querySelectorAll(`canvas`);return e.querySelectorAll(`canvas`).forEach((e,t)=>{e.width>0&&e.height>0&&nt(e,n[t],e.width)}),t},st=(0,I.createContext)(null),ct=()=>{let e=(0,I.useContext)(st);return(0,I.useLayoutEffect)(()=>{e==null||e.claim()},[e]),(0,I.useCallback)(()=>e==null?void 0:e.drawn(),[e])},lt=(0,I.createContext)(!1),ut=()=>(0,I.useContext)(lt),dt=e=>Math.max(0,Math.min(1,e)),ft=(e,t)=>t>=1?1:dt((e-t)/(1-t)),pt=(e,t)=>{let n=dt(e),r=dt(t),i=r<=0||r>=1?n:n<=r?.5*n/r:.5+.5*(n-r)/(1-r);return i*i*(3-2*i)},mt=e=>1-(1-e)**3,ht=(e,t)=>e.length===t.length&&e.every((e,n)=>e===t[n]),gt=(e,t,n)=>{let r=e.join(`|`),i=(0,I.useMemo)(()=>r.split(`|`),[r]),[a,o]=(0,I.useState)(i),s=(0,I.useRef)(i);return(0,I.useEffect)(()=>{var e;let r=s.current,a=e=>{s.current=e,o(e)};if(ht(r,i))return;if(t<=0||r.length!==i.length){a(i);return}let c=e=>e>=1?i:i.map((t,n)=>D(r[n],t,e)),l=(e=n==null?void 0:n.get())==null?1:e;if(n&&l<1)return n.on(`change`,e=>a(c(ft(e,l))));let u=performance.now(),d=0,f=e=>{let n=Math.min(1,(e-u)/t);a(c(n>=1?1:mt(n))),n<1&&(d=requestAnimationFrame(f))};return d=requestAnimationFrame(f),()=>cancelAnimationFrame(d)},[i,t,n]),t<=0?i:a},_t=24,vt=96,yt=()=>{if(typeof navigator>`u`)return!1;let e=navigator.userAgent,t=/iPad|iPhone|iPod/i.test(e)||navigator.platform===`MacIntel`&&navigator.maxTouchPoints>1,n=/WebKit/i.test(e),r=/CriOS|FxiOS|EdgiOS|OPiOS|DuckDuckGo|YaBrowser|GSA/i.test(e);return t&&n&&!r},bt=e=>new Promise(t=>{if(typeof document>`u`){t(null);return}let n=new Image;n.crossOrigin=`anonymous`,n.decoding=`async`,n.onload=()=>{try{let e=document.createElement(`canvas`),r=document.createElement(`canvas`);e.width=_t,e.height=_t,r.width=vt,r.height=vt;let i=e.getContext(`2d`),a=r.getContext(`2d`);if(!i||!a){t(null);return}let o=n.naturalWidth||n.width,s=n.naturalHeight||n.height,c=Math.min(o,s),l=Math.max(0,(o-c)/2),u=Math.max(0,(s-c)/2);i.imageSmoothingEnabled=!0,i.imageSmoothingQuality=`high`,i.drawImage(n,l,u,c,c,0,0,_t,_t),a.imageSmoothingEnabled=!0,a.imageSmoothingQuality=`high`,a.globalAlpha=1,a.drawImage(e,0,0,_t,_t,0,0,vt,vt),[{x:-8,y:-8,size:112,alpha:.22},{x:6,y:0,size:vt,alpha:.14},{x:0,y:6,size:vt,alpha:.14}].forEach(({x:t,y:n,size:r,alpha:i})=>{a.globalAlpha=i,a.drawImage(e,0,0,_t,_t,t,n,r,r)}),a.globalAlpha=1,t(r.toDataURL(`image/jpeg`,.72))}catch(e){console.warn(`[FluidBackground] Failed to build soft focus cover`,e),t(null)}},n.onerror=()=>t(null),n.src=e}),xt=320,St=640,Ct=1e3,wt=(e,t)=>{var n;e.fillStyle=`#000`,e.fillStyle=t;let r=String(e.fillStyle),[i,a,o]=r.startsWith(`#`)?[1,3,5].map(e=>parseInt(r.slice(e,e+2),16)):(n=r.match(/[\d.]+/g))==null?[`0`,`0`,`0`]:n;return[r,`rgba(${i}, ${a}, ${o}, 0)`]},Tt=(e,t)=>{let n=document.createElement(`canvas`);return n.width=e,n.height=t,n},Et=null,Dt=()=>{if(Et!==null)return Et;try{let e=Tt(4,1).getContext(`2d`,{willReadFrequently:!0});!e||typeof e.filter!=`string`?Et=!1:(e.filter=`blur(1px)`,e.fillStyle=`#fff`,e.fillRect(2,0,1,1),Et=e.getImageData(1,0,1,1).data[3]>0)}catch(e){Et=!1}return Et},Ot=(e,t)=>{let{width:n,height:r}=e,i=n/Math.max(1,t*2.5),a=[],o=n,s=r;for(;o/2>=i&&o>2&&s>2;)o=Math.ceil(o/2),s=Math.ceil(s/2),a.push([o,s]);let c=[...a,...a.slice(0,-1).reverse(),[n,r]],l=e;for(let[e,t]of c){let n=Tt(e,t),r=n.getContext(`2d`);if(!r)return l;r.imageSmoothingEnabled=!0,r.imageSmoothingQuality=`high`,r.drawImage(l,0,0,e,t),l=n}return l},kt=(e,t,n,r)=>{let i=Tt(t,n),a=i.getContext(`2d`);if(!a)return null;let o=Math.max(t/e.width,n/e.height)*1.5,s=e.width*o,c=e.height*o,l=60*t/r,u=Dt();return u&&(a.filter=`blur(${l}px)`),a.imageSmoothingEnabled=!0,a.imageSmoothingQuality=`high`,a.drawImage(e,(t-s)/2,(n-c)/2,s,c),u?i:Ot(i,l)},At=(e,t,n,r)=>{let i=e.getContext(`2d`);if(!i)return;let{width:a,height:o}=e;if(i.clearRect(0,0,a,o),!t)return;i.drawImage(t,0,0,a,o);let s=Math.hypot(a,o),c=a*o/s,l=o/s*c,u=a/s*c,d=i.createLinearGradient(a/2-l,o/2-u,a/2+l,o/2+u),[f,p]=wt(i,n),[m,h]=wt(i,r);d.addColorStop(0,f),d.addColorStop(.5,p),d.addColorStop(.5,h),d.addColorStop(1,m),i.globalCompositeOperation=`overlay`,i.globalAlpha=.4,i.fillStyle=d,i.fillRect(0,0,a,o),i.globalCompositeOperation=`source-over`,i.globalAlpha=1},jt=({image:e,primaryColor:t,secondaryColor:n,onDrawn:r})=>{let i=(0,I.useRef)(null),[a,o]=(0,I.useState)(null);(0,I.useLayoutEffect)(()=>{let e=i.current;if(!e)return;let t=()=>{let t=e.clientWidth,n=e.clientHeight;o(e=>e&&e.width===t&&e.height===n?e:{width:t,height:n})};if(t(),typeof ResizeObserver>`u`)return;let n=new ResizeObserver(t);return n.observe(e),()=>n.disconnect()},[]);let s=(0,I.useRef)(r);(0,I.useLayoutEffect)(()=>{s.current=r});let c=(0,I.useRef)(!1),l=(0,I.useRef)(null);return(0,I.useLayoutEffect)(()=>{let r=i.current;if(!r||!a)return;if(a.width>0&&a.height>0){var o;let i=Math.max(1,Math.round(xt*a.height/a.width));(r.width!==xt||r.height!==i)&&(r.width=xt,r.height=i);let s=l.current;e?s&&s.image===e&&s.width===r.width&&s.height===r.height&&s.cssWidth===a.width||(s={image:e,width:r.width,height:r.height,cssWidth:a.width,canvas:kt(e,r.width,r.height,a.width)}):s=null,l.current=s,At(r,(o=s==null?void 0:s.canvas)==null?null:o,t,n)}if(c.current)return;let u=requestAnimationFrame(()=>{c.current=!0,s.current()});return()=>cancelAnimationFrame(u)},[a,e,t,n]),(0,L.jsx)(`canvas`,{ref:i,"aria-hidden":`true`,className:`absolute inset-0 w-full h-full`})},Mt=(0,I.memo)(({coverUrl:e,theme:t})=>{var n;let r=(0,I.useMemo)(yt,[]),[a,o]=(0,I.useState)(null),[s,c]=gt([t.primaryColor,t.secondaryColor],Ct);(0,I.useEffect)(()=>{let t=!1;return!r||!e?(o(null),()=>{t=!0}):(o(null),bt(e).then(e=>{t||o(e)}),()=>{t=!0})},[e,r]);let l=ct(),u=(0,I.useRef)(0),[d,f]=(0,I.useState)([]),[p,m]=(0,I.useState)(()=>new Set),h=(0,I.useRef)(new Set);(0,I.useEffect)(()=>{let e=new Set(d.map(e=>e.image));h.current.forEach(t=>{e.has(t)||(t.close(),h.current.delete(t))})},[d]),(0,I.useEffect)(()=>()=>{h.current.forEach(e=>e.close()),h.current.clear()},[]),(0,I.useEffect)(()=>{if(r)return;if(!e){f([]);return}let t=!1,n=new Image;return n.decoding=`async`,n.src=e,n.decode().then(()=>{let e=Math.min(1,St/Math.max(n.naturalWidth,n.naturalHeight));return createImageBitmap(n,{resizeWidth:Math.max(1,Math.round(n.naturalWidth*e)),resizeHeight:Math.max(1,Math.round(n.naturalHeight*e)),resizeQuality:`high`})}).then(n=>{t?n.close():(h.current.add(n),f(t=>{let r=t[t.length-1];return r&&r.sourceCover===e?t:(u.current+=1,[...r?[r]:[],{image:n,sourceCover:e,key:u.current}])}))},()=>{t||(f(t=>t.length>0?t:(u.current+=1,[{image:null,sourceCover:e,key:u.current}])),l())}),()=>{t=!0}},[e,r,l]);let g=ut(),_=(0,I.useRef)(g);(0,I.useLayoutEffect)(()=>{_.current=g});let[v,y]=(0,I.useState)(null);(0,I.useEffect)(()=>{(!e||r)&&l()},[e,r,l]);let b=(0,I.useCallback)(e=>{_.current&&y(e),m(t=>t.has(e)?t:new Set(t).add(e)),l()},[l]),[x,S]=(0,I.useState)(null),C=d[d.length-1],w=!!e&&!r&&!(C&&C.sourceCover===e&&C.key===x),T=r?(n=a==null?e:a)==null?null:n:null,E=r&&!!a,D=(0,I.useMemo)(()=>({transform:`scale(${E?1.28:1.2}) translateZ(0)`,opacity:E?.94:.3,willChange:`transform, opacity`,backfaceVisibility:`hidden`,WebkitBackfaceVisibility:`hidden`}),[E]);return(0,L.jsxs)(`div`,i(i({className:`absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-0`,style:{isolation:`isolate`,contain:`paint`,transform:`translateZ(0)`}},w?{[Ke]:``}:{}),{},{children:[e?(0,L.jsxs)(L.Fragment,{children:[r?(0,L.jsx)(`img`,{src:T==null?e:T,alt:``,"aria-hidden":`true`,draggable:!1,decoding:`async`,className:`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-out`,style:D}):(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`div`,{className:`absolute inset-0 w-full h-full transition-colors duration-1000`,style:{backgroundColor:t.backgroundColor,opacity:.8}}),d.map((e,t)=>{let n=t===d.length-1,r=p.has(e.key);return(0,L.jsx)(te.div,{className:`absolute inset-0 w-full h-full`,style:{willChange:`opacity`},initial:{opacity:+!n},animate:{opacity:n&&!r?0:1},transition:{duration:e.key===v?0:1.5,ease:`easeInOut`},onAnimationComplete:()=>{n&&r&&(f(t=>t.filter(t=>t.key===e.key)),m(t=>t.has(e.key)?new Set([e.key]):t),S(e.key))},children:(0,L.jsx)(jt,{image:e.image,primaryColor:s,secondaryColor:c,onDrawn:()=>b(e.key)})},e.key)})]}),r&&(0,L.jsxs)(L.Fragment,{children:[!E&&(0,L.jsx)(`img`,{src:e,alt:``,"aria-hidden":`true`,draggable:!1,decoding:`async`,className:`absolute inset-0 w-full h-full object-cover`,style:{transform:`scale(1.36) translateZ(0)`,opacity:.12,willChange:`transform, opacity`,backfaceVisibility:`hidden`,WebkitBackfaceVisibility:`hidden`}}),(0,L.jsx)(`div`,{className:`absolute inset-0 w-full h-full`,style:{backgroundColor:t.backgroundColor,opacity:.28}}),(0,L.jsx)(`div`,{className:`absolute inset-0 w-full h-full`,style:{background:`radial-gradient(circle at 20% 20%, ${t.accentColor}55 0%, transparent 42%), radial-gradient(circle at 80% 28%, ${t.secondaryColor}50 0%, transparent 44%), radial-gradient(circle at 50% 78%, ${t.primaryColor}28 0%, transparent 52%)`,opacity:E?.52:.7}})]})]}):(0,L.jsx)(`div`,{className:`absolute inset-0 w-full h-full transition-colors duration-1000`,style:{backgroundColor:t.backgroundColor,opacity:.8}}),(!e||r||C&&!C.image)&&(0,L.jsx)(`div`,{className:`absolute inset-0 w-full h-full`,style:{background:`linear-gradient(to bottom right, ${s}, transparent, ${c})`,opacity:r?.2:.4,mixBlendMode:r?`normal`:`overlay`}})]}))},(e,t)=>{if(e.coverUrl!==t.coverUrl)return!1;let n=e.theme,r=t.theme;return n.backgroundColor===r.backgroundColor&&n.primaryColor===r.primaryColor&&n.secondaryColor===r.secondaryColor}),Nt=null,Pt=null,Ft=!1,It=new Map,Lt=new Map,Rt=new Set,zt=new Set,Bt=0,Vt=e=>typeof e==`object`&&!!e&&`$$typeof`in e&&`render`in e,Ht=e=>e.replace(/(?:^|-)(\w)/g,(e,t)=>t.toUpperCase()),Ut=e=>{let t=new Map,n=new Map,r=Object.keys(e);return[e=>e,e=>`${e}Icon`,e=>`Lucide${e}`].forEach(e=>{r.forEach(r=>{let i=e(Ht(r));t.has(i)||(t.set(i,r),n.has(i.toLowerCase())||n.set(i.toLowerCase(),i))})}),{loaders:e,keysByName:t,namesByLowercase:n}},Wt=()=>{Bt+=1,zt.forEach(e=>e())},Gt=()=>(Pt!=null||(Pt=n(()=>import(`./dynamicIconImports-BjOCQR40.js`).then(e=>e.t).then(e=>(Nt=Ut(e.default),Ft=!1,Wt(),Nt)),__vite__mapDeps([0,1])).catch(e=>{throw Pt=null,Ft=!0,Wt(),e})),Pt),Kt=(e,t)=>{if(It.has(t))return Promise.resolve();let n=Lt.get(t);return n||(n=e.loaders[t]().then(e=>{Vt(e.default)&&(It.set(t,e.default),Rt.delete(t),Wt())}).catch(()=>{Rt.add(t),Wt()}).finally(()=>Lt.delete(t)),Lt.set(t,n)),n},qt=e=>typeof e==`string`?e.trim():``,Jt=async e=>{let t=(e==null?[]:e).map(qt).filter(Boolean);if(t.length===0)return;let n;try{n=await Gt()}catch(e){return}await Promise.all(t.map(e=>{let t=n.keysByName.has(e)?e:n.namesByLowercase.get(e.toLowerCase()),r=t?n.keysByName.get(t):void 0;return r?Kt(n,r):void 0}))},Yt=async e=>{let t=qt(e);if(!t)return!1;try{return(await Gt()).keysByName.has(t)}catch(e){return!1}},Xt=e=>{var t;let n=Nt==null?void 0:Nt.keysByName.get(qt(e));return n?(t=It.get(n))==null?null:t:null},Zt=e=>{let t=Xt(e);if(!t||typeof t.render!=`function`)return null;try{var n,r,i;let e=t.render({},null),a=(n=e==null||(r=e.props)==null?void 0:r.iconNode)==null?e==null||(i=e.props)==null||(i=i.icon)==null?void 0:i.node:n;return Array.isArray(a)?a:null}catch(e){return null}},Qt=e=>{let t=qt(e);if(!t)return`missing`;if(!Nt)return Ft?`missing`:`loading`;let n=Nt.keysByName.get(t);return n?It.has(n)?`ready`:Rt.has(n)?`missing`:`loading`:`missing`},$t=e=>[...new Set((e==null?[]:e).map(e=>typeof e==`string`?Nt==null?void 0:Nt.namesByLowercase.get(e.trim().toLowerCase()):void 0).filter(e=>e!==void 0&&Xt(e)!==null))],en=e=>(zt.add(e),()=>{zt.delete(e)}),tn=()=>Bt,nn=e=>{var t;let n=(t=e==null?void 0:e.join(`
`))==null?``:t;return(0,I.useEffect)(()=>{n&&Jt(n.split(`
`))},[n]),(0,I.useSyncExternalStore)(en,tn,tn)},rn=e=>{switch(e.type){case`circle`:return`bass`;case`square`:return`lowMid`;case`triangle`:return`mid`;case`cross`:return`treble`;default:return`default`}},an=e=>e===`triangle`?`polygon(50% 0%, 0% 100%, 100% 100%)`:e===`cross`?`polygon(20% 0%, 0% 20%, 30% 50%, 0% 80%, 20% 100%, 50% 70%, 80% 100%, 100% 80%, 70% 50%, 100% 20%, 80% 0%, 50% 30%)`:`none`,on=(e,t)=>{let n=(e.type===`circle`||e.type===`square`)&&!e.filled;return{border:n?`1px solid ${t.secondaryColor}`:`none`,backgroundColor:n?`transparent`:t.secondaryColor,borderRadius:e.type===`circle`?`50%`:`0%`,opacity:e.opacity,clipPath:an(e.type)}},sn=e=>({left:`${e.initialX}%`,top:`${e.initialY}%`,width:e.size,height:e.size,animationDuration:`${e.duration}s`,animationDelay:`${e.delay}s`,"--geometric-dir":e.reverse?-1:1,"--geometric-rotate":`${e.initialRotation}deg`}),cn=(e,t)=>{if(e.iconSlot===null||t.length===0)return null;let n=t[Math.floor(e.iconSlot*t.length)];return Qt(n)===`loading`?`loading`:Xt(n)},ln=({disabled:e=!1})=>e?null:(0,L.jsx)(`div`,{className:`absolute inset-0 pointer-events-none`,style:{background:`radial-gradient(circle, transparent 40%, rgba(0,0,0,0.6) 100%)`}}),un=({theme:e,audioPower:t,audioBands:n,shapes:r,particles:a,hideShapes:o,disableVignette:s,paused:c})=>{let l=e=>{let n=Pe(e||t,{stiffness:300,damping:30});return ce(n,[10,200],[.95,1.45])},u={bass:l(n==null?void 0:n.bass),lowMid:l(n==null?void 0:n.lowMid),mid:l(n==null?void 0:n.mid),vocal:l(n==null?void 0:n.vocal),treble:l(n==null?void 0:n.treble),default:l(t)},d=e.lyricsIcons||[];return(0,L.jsxs)(`div`,{className:c?`absolute inset-0 geometric-paused`:`absolute inset-0`,children:[!o&&(0,L.jsxs)(L.Fragment,{children:[r.map(t=>{let n=cn(t,d),r=n===`loading`?null:n;return(0,L.jsxs)(`div`,{className:`absolute geometric-drift`,style:sn(t),children:[(0,L.jsx)(te.div,{className:`w-full h-full transition-[color,background-color,border-color,opacity] duration-1000`,style:i(i(i({},on(t,e)),n===null?{}:{opacity:0}),{},{scale:u[rn(t)]})}),t.iconSlot!==null&&(0,L.jsx)(`div`,{className:`absolute inset-0 transition-opacity duration-1000`,style:{opacity:+!!r},children:(0,L.jsx)(te.div,{className:`w-full h-full flex items-center justify-center geometric-pulse transition-colors duration-1000`,style:{color:e.secondaryColor,scale:u.vocal,animationDuration:`${t.duration*.5}s`,animationDelay:`${t.delay}s`,"--geometric-peak":t.opacity*3},children:r&&(0,L.jsx)(r,{size:t.size,strokeWidth:1,absoluteStrokeWidth:!0})})})]},t.id)}),a.map(t=>(0,L.jsx)(`div`,{className:`absolute rounded-full geometric-rise transition-colors duration-1000`,style:{backgroundColor:e.accentColor,width:t.size,height:t.size,left:`${t.left}%`,top:`${t.top}%`,animationDuration:`${t.duration}s`,animationDelay:`${t.delay}s`,"--geometric-peak":t.opacity}},`p-${t.id}`))]}),(0,L.jsx)(ln,{disabled:s})]})},dn=({theme:e,audioPower:t,audioBands:n,seed:r,hideShapes:i=!1,disableVignette:a=!1,paused:o=!1})=>{nn(e.lyricsIcons);let s=(0,I.useMemo)(()=>{let e=[`circle`,`square`,`triangle`,`cross`],t=0;return Array.from({length:15}).map((n,r)=>{let i=t<6&&Math.random()>.7?Math.random():null;return i!==null&&(t+=1),{id:r,type:e[Math.floor(Math.random()*e.length)],iconSlot:i,initialX:Math.random()*100,initialY:Math.random()*100,size:40+Math.random()*100,duration:i===null?30+Math.random()*30:20+Math.random()*20,delay:Math.random()*5,opacity:.11+Math.random()*.08,reverse:Math.random()>.5,filled:Math.random()<.3,initialRotation:Math.random()*360}})},[r]),c=(0,I.useMemo)(()=>Array.from({length:20}).map((e,t)=>({id:t,size:Math.random()*4+1,left:Math.random()*100,top:Math.random()*100,opacity:Math.random()*.3,duration:15+Math.random()*20,delay:Math.random()*10})),[r]);return(0,L.jsx)(te.div,{className:`absolute inset-0`,initial:!1,animate:{opacity:1},exit:{opacity:0},transition:{duration:.6,ease:`easeInOut`},children:(0,L.jsx)(un,{theme:e,audioPower:t,audioBands:n,shapes:s,particles:c,hideShapes:i,disableVignette:a,paused:o})})},fn=I.memo(e=>{var t;let n=String((t=e.seed)==null?`default`:t);return(0,L.jsx)(`div`,{className:`absolute inset-0 overflow-hidden pointer-events-none`,children:(0,L.jsx)(S,{mode:`sync`,children:(0,L.jsx)(dn,i({},e),n)})})},(e,t)=>{var n,r,i;if(e.seed!==t.seed||e.audioPower!==t.audioPower||e.hideShapes!==t.hideShapes||e.disableVignette!==t.disableVignette||e.paused!==t.paused)return!1;let a=e.audioBands,o=t.audioBands;if(!a!=!o)return!1;let s=!0;if(a&&o&&(s=a.bass===o.bass&&a.lowMid===o.lowMid&&a.mid===o.mid&&a.vocal===o.vocal&&a.treble===o.treble),!s)return!1;let c=e.theme,l=t.theme,u=c.backgroundColor===l.backgroundColor&&c.primaryColor===l.primaryColor&&c.secondaryColor===l.secondaryColor&&c.accentColor===l.accentColor,d=!!(c.lyricsIcons===l.lyricsIcons||((n=c.lyricsIcons)==null?void 0:n.length)===((r=l.lyricsIcons)==null?void 0:r.length)&&(i=c.lyricsIcons)!=null&&i.every((e,t)=>{var n;return e===((n=l.lyricsIcons)==null?void 0:n[t])}));return u&&d}),pn=t({default:()=>mn}),mn=Fe({mode:`common`,order:10,labelKey:`options.visualizerBackgroundModeCommon`,labelFallback:`Common`,glyph:(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`path`,{d:`M4 17l5-8 5 8z`}),(0,L.jsx)(`circle`,{cx:`17.5`,cy:`8.5`,r:`3`,opacity:`0.55`})]}),command:{title:`Background: Common`,description:`Switch background to general layout`,keywords:[`background general`,`common`,`general`,`通用背景`,`ty`,`背景切换到 通用`,`背景切换到通用`]},song:({config:e,coverUrl:t,seed:n,staticMode:r})=>{var i;return[r||n==null?null:n,e!=null&&(i=e.common)!=null&&i.useCoverColorBg?t==null?null:t:null]},render:({config:e,theme:t,coverUrl:n,audioPower:r,audioBands:i,seed:a,staticMode:o,paused:s})=>{var c,l,u,d;let f=e==null?void 0:e.common,p=(c=f==null?void 0:f.useCoverColorBg)!=null&&c;return(0,L.jsxs)(L.Fragment,{children:[p&&(0,L.jsx)(`div`,{className:`absolute inset-0 z-0`,children:(0,L.jsx)(Mt,{coverUrl:n,theme:t})}),(0,L.jsx)(`div`,{className:`absolute inset-0 z-0 transition-all duration-1000`,style:{backgroundColor:t.backgroundColor,opacity:p?(l=f==null?void 0:f.opacity)==null?.75:l:1}}),!o&&(0,L.jsx)(`div`,{className:`absolute inset-0 z-0`,children:(0,L.jsx)(fn,{theme:t,audioPower:r,audioBands:i,seed:a,hideShapes:(u=f==null?void 0:f.disableGeometricBackground)!=null&&u,disableVignette:(d=f==null?void 0:f.disableVignette)!=null&&d,paused:s})})]})},renderSettingsPanel:e=>(0,L.jsx)(Re,i({},e)),renderQuickControls:({config:e,actions:t,t:n})=>{var r,i,a,o;let s=(r=e==null||(i=e.common)==null?void 0:i.useCoverColorBg)!=null&&r,c=!((a=e==null||(o=e.common)==null?void 0:o.disableVignette)!=null&&a);return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(he,{active:s,label:n(s?`theme.addCoverColor`:`theme.useDefaultColor`),onToggle:()=>{var e,n;return t==null||(e=t.common)==null||(n=e.onCoverColorChange)==null?void 0:n.call(e,!s)},children:(0,L.jsx)(f,{size:14})}),(0,L.jsx)(he,{active:c,label:n(`options.visualizerVignette`),onToggle:()=>{var e,n;return t==null||(e=t.common)==null||(n=e.onDisableVignetteChange)==null?void 0:n.call(e,c)},children:(0,L.jsx)(h,{size:14})})]})},resetSettings:e=>{var t,n,r,i,a,o,s,c;e==null||(t=e.common)==null||(n=t.onOpacityChange)==null||n.call(t,.75),e==null||(r=e.common)==null||(i=r.onCoverColorChange)==null||i.call(r,!1),e==null||(a=e.common)==null||(o=a.onDisableVignetteChange)==null||o.call(a,!1),e==null||(s=e.common)==null||(c=s.onDisableGeometricChange)==null||c.call(s,!1)}}),hn=`#version 300 es
precision mediump float;

layout(location = 0) in vec4 a_position;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_imageAspectRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;
uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

out vec2 v_objectUV;
out vec2 v_objectBoxSize;
out vec2 v_responsiveUV;
out vec2 v_responsiveBoxGivenSize;
out vec2 v_patternUV;
out vec2 v_patternBoxSize;
out vec2 v_imageUV;

vec3 getBoxSize(float boxRatio, vec2 givenBoxSize) {
  vec2 box = vec2(0.);
  // fit = none
  box.x = boxRatio * min(givenBoxSize.x / boxRatio, givenBoxSize.y);
  float noFitBoxWidth = box.x;
  if (u_fit == 1.) { // fit = contain
    box.x = boxRatio * min(u_resolution.x / boxRatio, u_resolution.y);
  } else if (u_fit == 2.) { // fit = cover
    box.x = boxRatio * max(u_resolution.x / boxRatio, u_resolution.y);
  }
  box.y = box.x / boxRatio;
  return vec3(box, noFitBoxWidth);
}

void main() {
  gl_Position = a_position;

  vec2 uv = gl_Position.xy * .5;
  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  vec2 givenBoxSize = vec2(u_worldWidth, u_worldHeight);
  givenBoxSize = max(givenBoxSize, vec2(1.)) * u_pixelRatio;
  float r = u_rotation * 3.14159265358979323846 / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);


  // ===================================================

  float fixedRatio = 1.;
  vec2 fixedRatioBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );

  v_objectBoxSize = getBoxSize(fixedRatio, fixedRatioBoxGivenSize).xy;
  vec2 objectWorldScale = u_resolution.xy / v_objectBoxSize;

  v_objectUV = uv;
  v_objectUV *= objectWorldScale;
  v_objectUV += boxOrigin * (objectWorldScale - 1.);
  v_objectUV += graphicOffset;
  v_objectUV /= u_scale;
  v_objectUV = graphicRotation * v_objectUV;

  // ===================================================

  v_responsiveBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  float responsiveRatio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
  vec2 responsiveBoxSize = getBoxSize(responsiveRatio, v_responsiveBoxGivenSize).xy;
  vec2 responsiveBoxScale = u_resolution.xy / responsiveBoxSize;

  #ifdef ADD_HELPERS
  v_responsiveHelperBox = uv;
  v_responsiveHelperBox *= responsiveBoxScale;
  v_responsiveHelperBox += boxOrigin * (responsiveBoxScale - 1.);
  #endif

  v_responsiveUV = uv;
  v_responsiveUV *= responsiveBoxScale;
  v_responsiveUV += boxOrigin * (responsiveBoxScale - 1.);
  v_responsiveUV += graphicOffset;
  v_responsiveUV /= u_scale;
  v_responsiveUV.x *= responsiveRatio;
  v_responsiveUV = graphicRotation * v_responsiveUV;
  v_responsiveUV.x /= responsiveRatio;

  // ===================================================

  float patternBoxRatio = givenBoxSize.x / givenBoxSize.y;
  vec2 patternBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  patternBoxRatio = patternBoxGivenSize.x / patternBoxGivenSize.y;

  vec3 boxSizeData = getBoxSize(patternBoxRatio, patternBoxGivenSize);
  v_patternBoxSize = boxSizeData.xy;
  float patternBoxNoFitBoxWidth = boxSizeData.z;
  vec2 patternBoxScale = u_resolution.xy / v_patternBoxSize;

  v_patternUV = uv;
  v_patternUV += graphicOffset / patternBoxScale;
  v_patternUV += boxOrigin;
  v_patternUV -= boxOrigin / patternBoxScale;
  v_patternUV *= u_resolution.xy;
  v_patternUV /= u_pixelRatio;
  if (u_fit > 0.) {
    v_patternUV *= (patternBoxNoFitBoxWidth / v_patternBoxSize.x);
  }
  v_patternUV /= u_scale;
  v_patternUV = graphicRotation * v_patternUV;
  v_patternUV += boxOrigin / patternBoxScale;
  v_patternUV -= boxOrigin;
  // x100 is a default multiplier between vertex and fragmant shaders
  // we use it to avoid UV presision issues
  v_patternUV *= .01;

  // ===================================================

  vec2 imageBoxSize;
  if (u_fit == 1.) { // contain
    imageBoxSize.x = min(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else if (u_fit == 2.) { // cover
    imageBoxSize.x = max(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else {
    imageBoxSize.x = min(10.0, 10.0 / u_imageAspectRatio * u_imageAspectRatio);
  }
  imageBoxSize.y = imageBoxSize.x / u_imageAspectRatio;
  vec2 imageBoxScale = u_resolution.xy / imageBoxSize;

  v_imageUV = uv;
  v_imageUV *= imageBoxScale;
  v_imageUV += boxOrigin * (imageBoxScale - 1.);
  v_imageUV += graphicOffset;
  v_imageUV /= u_scale;
  v_imageUV.x *= u_imageAspectRatio;
  v_imageUV = graphicRotation * v_imageUV;
  v_imageUV.x /= u_imageAspectRatio;

  v_imageUV += .5;
  v_imageUV.y = 1. - v_imageUV.y;
}`,gn=8294400,_n=class{constructor(e,t,n,a,o=0,s=0,c=2,l=gn,u=[]){var d;if(r(this,`parentElement`,void 0),r(this,`canvasElement`,void 0),r(this,`gl`,void 0),r(this,`program`,null),r(this,`uniformLocations`,{}),r(this,`fragmentShader`,void 0),r(this,`rafId`,null),r(this,`lastRenderTime`,0),r(this,`currentFrame`,0),r(this,`speed`,0),r(this,`currentSpeed`,0),r(this,`providedUniforms`,void 0),r(this,`mipmaps`,[]),r(this,`hasBeenDisposed`,!1),r(this,`resolutionChanged`,!0),r(this,`textures`,new Map),r(this,`minPixelRatio`,void 0),r(this,`maxPixelCount`,void 0),r(this,`isSafari`,xn()),r(this,`uniformCache`,{}),r(this,`textureUnitMap`,new Map),r(this,`ownerDocument`,void 0),r(this,`initProgram`,()=>{let e=yn(this.gl,hn,this.fragmentShader);e&&(this.program=e)}),r(this,`setupPositionAttribute`,()=>{let e=this.gl.getAttribLocation(this.program,`a_position`),t=this.gl.createBuffer();this.gl.bindBuffer(this.gl.ARRAY_BUFFER,t),this.gl.bufferData(this.gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),this.gl.STATIC_DRAW),this.gl.enableVertexAttribArray(e),this.gl.vertexAttribPointer(e,2,this.gl.FLOAT,!1,0,0)}),r(this,`setupUniforms`,()=>{let e={u_time:this.gl.getUniformLocation(this.program,`u_time`),u_pixelRatio:this.gl.getUniformLocation(this.program,`u_pixelRatio`),u_resolution:this.gl.getUniformLocation(this.program,`u_resolution`)};Object.entries(this.providedUniforms).forEach(([t,n])=>{if(e[t]=this.gl.getUniformLocation(this.program,t),n instanceof HTMLImageElement){let n=`${t}AspectRatio`;e[n]=this.gl.getUniformLocation(this.program,n)}}),this.uniformLocations=e}),r(this,`renderScale`,1),r(this,`parentWidth`,0),r(this,`parentHeight`,0),r(this,`parentDevicePixelWidth`,0),r(this,`parentDevicePixelHeight`,0),r(this,`devicePixelsSupported`,!1),r(this,`intersectionObserver`,null),r(this,`isInViewport`,!0),r(this,`resizeObserver`,null),r(this,`setupResizeObserver`,()=>{this.resizeObserver=new ResizeObserver(([e])=>{if(e!=null&&e.borderBoxSize[0]){var t;let n=(t=e.devicePixelContentBoxSize)==null?void 0:t[0];n!==void 0&&(this.devicePixelsSupported=!0,this.parentDevicePixelWidth=n.inlineSize,this.parentDevicePixelHeight=n.blockSize),this.parentWidth=e.borderBoxSize[0].inlineSize,this.parentHeight=e.borderBoxSize[0].blockSize}this.handleResize()}),this.resizeObserver.observe(this.parentElement)}),r(this,`setupIntersectionObserver`,()=>{let e=this.ownerDocument.defaultView;e!=null&&e.IntersectionObserver&&(this.intersectionObserver=new e.IntersectionObserver(([e])=>{var t;this.isInViewport=(t=e==null?void 0:e.isIntersecting)==null||t,this.updateCurrentSpeed()}),this.intersectionObserver.observe(this.parentElement))}),r(this,`handleVisualViewportChange`,()=>{var e;(e=this.resizeObserver)==null||e.disconnect(),this.setupResizeObserver()}),r(this,`handleResize`,()=>{var e,t;let n=0,r=0,i=Math.max(1,window.devicePixelRatio),a=(e=(t=visualViewport)==null?void 0:t.scale)==null?1:e;if(this.devicePixelsSupported){let e=Math.max(1,this.minPixelRatio/i);n=this.parentDevicePixelWidth*e*a,r=this.parentDevicePixelHeight*e*a}else{let e=Math.max(i,this.minPixelRatio)*a;if(this.isSafari){let t=Sn(this.ownerDocument);e*=Math.max(1,t)}n=Math.round(this.parentWidth)*e,r=Math.round(this.parentHeight)*e}let o=Math.sqrt(this.maxPixelCount)/Math.sqrt(n*r),s=Math.min(1,o),c=Math.round(n*s),l=Math.round(r*s),u=c/Math.round(this.parentWidth);(this.canvasElement.width!==c||this.canvasElement.height!==l||this.renderScale!==u)&&(this.renderScale=u,this.canvasElement.width=c,this.canvasElement.height=l,this.resolutionChanged=!0,this.gl.viewport(0,0,this.gl.canvas.width,this.gl.canvas.height),this.render(performance.now()))}),r(this,`render`,e=>{if(this.hasBeenDisposed)return;if(this.program===null){console.warn(`Tried to render before program or gl was initialized`);return}let t=e-this.lastRenderTime;this.lastRenderTime=e,this.currentSpeed!==0&&(this.currentFrame+=t*this.currentSpeed),this.gl.clear(this.gl.COLOR_BUFFER_BIT),this.gl.useProgram(this.program),this.gl.uniform1f(this.uniformLocations.u_time,this.currentFrame*.001),this.resolutionChanged&&(this.gl.uniform2f(this.uniformLocations.u_resolution,this.gl.canvas.width,this.gl.canvas.height),this.gl.uniform1f(this.uniformLocations.u_pixelRatio,this.renderScale),this.resolutionChanged=!1),this.gl.drawArrays(this.gl.TRIANGLES,0,6),this.currentSpeed===0?this.rafId=null:this.requestRender()}),r(this,`requestRender`,()=>{this.rafId!==null&&cancelAnimationFrame(this.rafId),this.rafId=requestAnimationFrame(this.render)}),r(this,`setTextureUniform`,(e,t)=>{if(!t.complete||t.naturalWidth===0)throw Error(`Paper Shaders: image for uniform ${e} must be fully loaded`);let n=this.textures.get(e);n&&this.gl.deleteTexture(n),this.textureUnitMap.has(e)||this.textureUnitMap.set(e,this.textureUnitMap.size);let r=this.textureUnitMap.get(e);this.gl.activeTexture(this.gl.TEXTURE0+r);let i=this.gl.createTexture();this.gl.bindTexture(this.gl.TEXTURE_2D,i),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_S,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_T,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MAG_FILTER,this.gl.LINEAR),this.gl.texImage2D(this.gl.TEXTURE_2D,0,this.gl.RGBA,this.gl.RGBA,this.gl.UNSIGNED_BYTE,t),this.mipmaps.includes(e)&&(this.gl.generateMipmap(this.gl.TEXTURE_2D),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR_MIPMAP_LINEAR));let a=this.gl.getError();if(a!==this.gl.NO_ERROR||i===null){console.error(`Paper Shaders: WebGL error when uploading texture:`,a);return}this.textures.set(e,i);let o=this.uniformLocations[e];if(o){this.gl.uniform1i(o,r);let n=`${e}AspectRatio`,i=this.uniformLocations[n];if(i){let e=t.naturalWidth/t.naturalHeight;this.gl.uniform1f(i,e)}}}),r(this,`areUniformValuesEqual`,(e,t)=>e===t?!0:Array.isArray(e)&&Array.isArray(t)&&e.length===t.length?e.every((e,n)=>this.areUniformValuesEqual(e,t[n])):!1),r(this,`setUniformValues`,e=>{this.gl.useProgram(this.program),Object.entries(e).forEach(([e,t])=>{let n=t;if(t instanceof HTMLImageElement&&(n=`${t.src.slice(0,200)}|${t.naturalWidth}x${t.naturalHeight}`),this.areUniformValuesEqual(this.uniformCache[e],n))return;this.uniformCache[e]=n;let r=this.uniformLocations[e];if(!r)console.warn(`Uniform location for ${e} not found`);else if(t instanceof HTMLImageElement)this.setTextureUniform(e,t);else if(Array.isArray(t)){let n=null,i=null;if(t[0]!==void 0&&Array.isArray(t[0])){let r=t[0].length;if(t.every(e=>e.length===r))n=t.flat(),i=r;else{console.warn(`All child arrays must be the same length for ${e}`);return}}else n=t,i=n.length;switch(i){case 2:this.gl.uniform2fv(r,n);break;case 3:this.gl.uniform3fv(r,n);break;case 4:this.gl.uniform4fv(r,n);break;case 9:this.gl.uniformMatrix3fv(r,!1,n);break;case 16:this.gl.uniformMatrix4fv(r,!1,n);break;default:console.warn(`Unsupported uniform array length: ${i}`)}}else typeof t==`number`?this.gl.uniform1f(r,t):typeof t==`boolean`?this.gl.uniform1i(r,+!!t):console.warn(`Unsupported uniform type for ${e}: ${typeof t}`)})}),r(this,`getCurrentFrame`,()=>this.currentFrame),r(this,`setFrame`,e=>{this.currentFrame=e,this.lastRenderTime=performance.now(),this.render(performance.now())}),r(this,`setSpeed`,(e=1)=>{this.speed=e,this.updateCurrentSpeed()}),r(this,`updateCurrentSpeed`,()=>{this.setCurrentSpeed(this.ownerDocument.hidden||!this.isInViewport?0:this.speed)}),r(this,`setCurrentSpeed`,e=>{this.currentSpeed=e,this.rafId===null&&e!==0&&(this.lastRenderTime=performance.now(),this.rafId=requestAnimationFrame(this.render)),this.rafId!==null&&e===0&&(cancelAnimationFrame(this.rafId),this.rafId=null)}),r(this,`setMaxPixelCount`,(e=gn)=>{this.maxPixelCount=e,this.handleResize()}),r(this,`setMinPixelRatio`,(e=2)=>{this.minPixelRatio=e,this.handleResize()}),r(this,`setUniforms`,e=>{this.setUniformValues(e),this.providedUniforms=i(i({},this.providedUniforms),e),this.render(performance.now())}),r(this,`handleDocumentVisibilityChange`,()=>{this.updateCurrentSpeed()}),r(this,`dispose`,()=>{var e;this.hasBeenDisposed=!0,this.rafId!==null&&(cancelAnimationFrame(this.rafId),this.rafId=null),this.gl&&this.program&&(this.textures.forEach(e=>{this.gl.deleteTexture(e)}),this.textures.clear(),this.gl.deleteProgram(this.program),this.program=null,this.gl.bindBuffer(this.gl.ARRAY_BUFFER,null),this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER,null),this.gl.bindRenderbuffer(this.gl.RENDERBUFFER,null),this.gl.bindFramebuffer(this.gl.FRAMEBUFFER,null),this.gl.getError()),this.resizeObserver&&(this.resizeObserver.disconnect(),this.resizeObserver=null),this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=null),(e=visualViewport)==null||e.removeEventListener(`resize`,this.handleVisualViewportChange),this.ownerDocument.removeEventListener(`visibilitychange`,this.handleDocumentVisibilityChange),this.uniformLocations={},this.canvasElement.remove(),delete this.parentElement.paperShaderMount}),(e==null?void 0:e.nodeType)===1)this.parentElement=e;else throw Error(`Paper Shaders: parent element must be an HTMLElement`);if(this.ownerDocument=e.ownerDocument,!this.ownerDocument.querySelector(`style[data-paper-shader]`)){let e=this.ownerDocument.createElement(`style`);e.innerHTML=bn,e.setAttribute(`data-paper-shader`,``),this.ownerDocument.head.prepend(e)}let f=this.ownerDocument.createElement(`canvas`);this.canvasElement=f,this.parentElement.prepend(f),this.fragmentShader=t,this.providedUniforms=n,this.mipmaps=u,this.currentFrame=s,this.minPixelRatio=c,this.maxPixelCount=l;let p=f.getContext(`webgl2`,a);if(!p)throw Error(`Paper Shaders: WebGL is not supported in this browser`);this.gl=p,this.initProgram(),this.setupPositionAttribute(),this.setupUniforms(),this.setUniformValues(this.providedUniforms),this.setupResizeObserver(),(d=visualViewport)==null||d.addEventListener(`resize`,this.handleVisualViewportChange),this.setupIntersectionObserver(),this.setSpeed(o),this.parentElement.setAttribute(`data-paper-shader`,``),this.parentElement.paperShaderMount=this,this.ownerDocument.addEventListener(`visibilitychange`,this.handleDocumentVisibilityChange)}};function vn(e,t,n){let r=e.createShader(t);return r?(e.shaderSource(r,n),e.compileShader(r),e.getShaderParameter(r,e.COMPILE_STATUS)?r:(console.error(`An error occurred compiling the shaders: `+e.getShaderInfoLog(r)),e.deleteShader(r),null)):null}function yn(e,t,n){let r=e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT),i=r?r.precision:null;i&&i<23&&(t=t.replace(/precision\s+(lowp|mediump)\s+float;/g,`precision highp float;`),n=n.replace(/precision\s+(lowp|mediump)\s+float/g,`precision highp float`).replace(/\b(uniform|varying|attribute)\s+(lowp|mediump)\s+(\w+)/g,`$1 highp $3`));let a=vn(e,e.VERTEX_SHADER,t),o=vn(e,e.FRAGMENT_SHADER,n);if(!a||!o)return null;let s=e.createProgram();return s?(e.attachShader(s,a),e.attachShader(s,o),e.linkProgram(s),e.getProgramParameter(s,e.LINK_STATUS)?(e.detachShader(s,a),e.detachShader(s,o),e.deleteShader(a),e.deleteShader(o),s):(console.error(`Unable to initialize the shader program: `+e.getProgramInfoLog(s)),e.deleteProgram(s),e.deleteShader(a),e.deleteShader(o),null)):null}var bn=`@layer paper-shaders {
  :where([data-paper-shader]) {
    isolation: isolate;
    position: relative;

    & canvas {
      contain: strict;
      display: block;
      position: absolute;
      inset: 0;
      z-index: -1;
      width: 100%;
      height: 100%;
      border-radius: inherit;
      corner-shape: inherit;
    }
  }
}`;function xn(){let e=navigator.userAgent.toLowerCase();return e.includes(`safari`)&&!e.includes(`chrome`)&&!e.includes(`android`)}function Sn(e){var t,n,r,i;let a=(t=(n=visualViewport)==null?void 0:n.scale)==null?1:t,o=(r=(i=visualViewport)==null?void 0:i.width)==null?window.innerWidth:r,s=window.innerWidth-e.documentElement.clientWidth,c=a*o+s,l=outerWidth/c,u=Math.round(100*l);return u%5==0?u/100:u===33?1/3:u===67?2/3:u===133?4/3:l}var R={fit:`contain`,scale:1,rotation:0,offsetX:0,offsetY:0,originX:.5,originY:.5,worldWidth:0,worldHeight:0},Cn={fit:`none`,scale:1,rotation:0,offsetX:0,offsetY:0,originX:.5,originY:.5,worldWidth:0,worldHeight:0},wn={none:0,contain:1,cover:2},Tn=`
#define TWO_PI 6.28318530718
#define PI 3.14159265358979323846
`,En=`
vec2 rotate(vec2 uv, float th) {
  return mat2(cos(th), sin(th), -sin(th), cos(th)) * uv;
}
`,Dn=`
  float hash11(float p) {
    p = fract(p * 0.3183099) + 0.1;
    p *= p + 19.19;
    return fract(p * p);
  }
`,On=`
  float hash21(vec2 p) {
    p = fract(p * vec2(0.3183099, 0.3678794)) + 0.1;
    p += dot(p, p + 19.19);
    return fract(p.x * p.y);
  }
`,kn=`
  float randomR(vec2 p) {
    vec2 uv = floor(p) / 100. + .5;
    return texture(u_noiseTexture, fract(uv)).r;
  }
`,An=`
  vec2 randomGB(vec2 p) {
    vec2 uv = floor(p) / 100. + .5;
    return texture(u_noiseTexture, fract(uv)).gb;
  }
`,jn=`
  color += 1. / 256. * (fract(sin(dot(.014 * gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453123) - .5);
`,Mn=`
vec3 permute(vec3 x) { return mod(((x * 34.0) + 1.0) * x, 289.0); }
float snoise(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
    -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1;
  i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0))
    + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy),
      dot(x12.zw, x12.zw)), 0.0);
  m = m * m;
  m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}
`,Nn=`
float fiberRandom(vec2 p) {
  vec2 uv = floor(p) / 100.;
  return texture(u_noiseTexture, fract(uv)).b;
}

float fiberValueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = fiberRandom(i);
  float b = fiberRandom(i + vec2(1.0, 0.0));
  float c = fiberRandom(i + vec2(0.0, 1.0));
  float d = fiberRandom(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  float x1 = mix(a, b, u.x);
  float x2 = mix(c, d, u.x);
  return mix(x1, x2, u.y);
}

float fiberNoiseFbm(in vec2 n, vec2 seedOffset) {
  float total = 0.0, amplitude = 1.;
  for (int i = 0; i < 4; i++) {
    n = rotate(n, .7);
    total += fiberValueNoise(n + seedOffset) * amplitude;
    n *= 2.;
    amplitude *= 0.6;
  }
  return total;
}

float fiberNoise(vec2 uv, vec2 seedOffset) {
  float epsilon = 0.001;
  float n1 = fiberNoiseFbm(uv + vec2(epsilon, 0.0), seedOffset);
  float n2 = fiberNoiseFbm(uv - vec2(epsilon, 0.0), seedOffset);
  float n3 = fiberNoiseFbm(uv + vec2(0.0, epsilon), seedOffset);
  float n4 = fiberNoiseFbm(uv - vec2(0.0, epsilon), seedOffset);
  return length(vec2(n1 - n2, n3 - n4)) / (2.0 * epsilon);
}
`,Pn={maxColorCount:10},Fn=`#version 300 es
precision mediump float;

uniform float u_time;

uniform vec4 u_colors[${Pn.maxColorCount}];
uniform float u_colorsCount;

uniform float u_distortion;
uniform float u_swirl;
uniform float u_grainMixer;
uniform float u_grainOverlay;

in vec2 v_objectUV;
out vec4 fragColor;

${Tn}
${En}
${On}

float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  float x1 = mix(a, b, u.x);
  float x2 = mix(c, d, u.x);
  return mix(x1, x2, u.y);
}

float noise(vec2 n, vec2 seedOffset) {
  return valueNoise(n + seedOffset);
}

vec2 getPosition(int i, float t) {
  float a = float(i) * .37;
  float b = .6 + fract(float(i) / 3.) * .9;
  float c = .8 + fract(float(i + 1) / 4.);

  float x = sin(t * b + a);
  float y = cos(t * c + a * 1.5);

  return .5 + .5 * vec2(x, y);
}

void main() {
  vec2 uv = v_objectUV;
  uv += .5;
  vec2 grainUV = uv * 1000.;

  float grain = noise(grainUV, vec2(0.));
  float mixerGrain = .4 * u_grainMixer * (grain - .5);

  const float firstFrameOffset = 41.5;
  float t = .5 * (u_time + firstFrameOffset);

  float radius = smoothstep(0., 1., length(uv - .5));
  float center = 1. - radius;
  for (float i = 1.; i <= 2.; i++) {
    uv.x += u_distortion * center / i * sin(t + i * .4 * smoothstep(.0, 1., uv.y)) * cos(.2 * t + i * 2.4 * smoothstep(.0, 1., uv.y));
    uv.y += u_distortion * center / i * cos(t + i * 2. * smoothstep(.0, 1., uv.x));
  }

  vec2 uvRotated = uv;
  uvRotated -= vec2(.5);
  float angle = 3. * u_swirl * radius;
  uvRotated = rotate(uvRotated, -angle);
  uvRotated += vec2(.5);

  vec3 color = vec3(0.);
  float opacity = 0.;
  float totalWeight = 0.;

  for (int i = 0; i < ${Pn.maxColorCount}; i++) {
    if (i >= int(u_colorsCount)) break;

    vec2 pos = getPosition(i, t) + mixerGrain;
    vec3 colorFraction = u_colors[i].rgb * u_colors[i].a;
    float opacityFraction = u_colors[i].a;

    float dist = length(uvRotated - pos);

    dist = pow(dist, 3.5);
    float weight = 1. / (dist + 1e-3);
    color += colorFraction * weight;
    opacity += opacityFraction * weight;
    totalWeight += weight;
  }

  color /= max(1e-4, totalWeight);
  opacity /= max(1e-4, totalWeight);

  float grainOverlay = valueNoise(rotate(grainUV, 1.) + vec2(3.));
  grainOverlay = mix(grainOverlay, valueNoise(rotate(grainUV, 2.) + vec2(-1.)), .5);
  grainOverlay = pow(grainOverlay, 1.3);

  float grainOverlayV = grainOverlay * 2. - 1.;
  vec3 grainOverlayColor = vec3(step(0., grainOverlayV));
  float grainOverlayStrength = u_grainOverlay * abs(grainOverlayV);
  grainOverlayStrength = pow(grainOverlayStrength, .8);
  color = mix(color, grainOverlayColor, .35 * grainOverlayStrength);

  opacity += .5 * grainOverlayStrength;
  opacity = clamp(opacity, 0., 1.);

  fragColor = vec4(color, opacity);
}
`,In=`#version 300 es
precision mediump float;

uniform float u_time;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;
uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

uniform float u_pxSize;
uniform vec4 u_colorBack;
uniform vec4 u_colorFront;
uniform float u_shape;
uniform float u_type;

out vec4 fragColor;

${Mn}
${Tn}
${Dn}
${On}

float getSimplexNoise(vec2 uv, float t) {
  float noise = .5 * snoise(uv - vec2(0., .3 * t));
  noise += .5 * snoise(2. * uv + vec2(0., .32 * t));

  return noise;
}

const int bayer2x2[4] = int[4](0, 2, 3, 1);
const int bayer4x4[16] = int[16](
0, 8, 2, 10,
12, 4, 14, 6,
3, 11, 1, 9,
15, 7, 13, 5
);

const int bayer8x8[64] = int[64](
0, 32, 8, 40, 2, 34, 10, 42,
48, 16, 56, 24, 50, 18, 58, 26,
12, 44, 4, 36, 14, 46, 6, 38,
60, 28, 52, 20, 62, 30, 54, 22,
3, 35, 11, 43, 1, 33, 9, 41,
51, 19, 59, 27, 49, 17, 57, 25,
15, 47, 7, 39, 13, 45, 5, 37,
63, 31, 55, 23, 61, 29, 53, 21
);

float getBayerValue(vec2 uv, int size) {
  ivec2 pos = ivec2(fract(uv / float(size)) * float(size));
  int index = pos.y * size + pos.x;

  if (size == 2) {
    return float(bayer2x2[index]) / 4.0;
  } else if (size == 4) {
    return float(bayer4x4[index]) / 16.0;
  } else if (size == 8) {
    return float(bayer8x8[index]) / 64.0;
  }
  return 0.0;
}


void main() {
  float t = .5 * u_time;

  float pxSize = u_pxSize * u_pixelRatio;
  vec2 pxSizeUV = gl_FragCoord.xy - .5 * u_resolution;
  pxSizeUV /= pxSize;
  vec2 canvasPixelizedUV = (floor(pxSizeUV) + .5) * pxSize;
  vec2 normalizedUV = canvasPixelizedUV / u_resolution;

  vec2 ditheringNoiseUV = canvasPixelizedUV;
  vec2 shapeUV = normalizedUV;

  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  vec2 givenBoxSize = vec2(u_worldWidth, u_worldHeight);
  givenBoxSize = max(givenBoxSize, vec2(1.)) * u_pixelRatio;
  float r = u_rotation * PI / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);

  float patternBoxRatio = givenBoxSize.x / givenBoxSize.y;
  vec2 boxSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  
  if (u_shape > 3.5) {
    vec2 objectBoxSize = vec2(0.);
    // fit = none
    objectBoxSize.x = min(boxSize.x, boxSize.y);
    if (u_fit == 1.) { // fit = contain
      objectBoxSize.x = min(u_resolution.x, u_resolution.y);
    } else if (u_fit == 2.) { // fit = cover
      objectBoxSize.x = max(u_resolution.x, u_resolution.y);
    }
    objectBoxSize.y = objectBoxSize.x;
    vec2 objectWorldScale = u_resolution.xy / objectBoxSize;

    shapeUV *= objectWorldScale;
    shapeUV += boxOrigin * (objectWorldScale - 1.);
    shapeUV += vec2(-u_offsetX, u_offsetY);
    shapeUV /= u_scale;
    shapeUV = graphicRotation * shapeUV;
  } else {
    vec2 patternBoxSize = vec2(0.);
    // fit = none
    patternBoxSize.x = patternBoxRatio * min(boxSize.x / patternBoxRatio, boxSize.y);
    float patternWorldNoFitBoxWidth = patternBoxSize.x;
    if (u_fit == 1.) { // fit = contain
      patternBoxSize.x = patternBoxRatio * min(u_resolution.x / patternBoxRatio, u_resolution.y);
    } else if (u_fit == 2.) { // fit = cover
      patternBoxSize.x = patternBoxRatio * max(u_resolution.x / patternBoxRatio, u_resolution.y);
    }
    patternBoxSize.y = patternBoxSize.x / patternBoxRatio;
    vec2 patternWorldScale = u_resolution.xy / patternBoxSize;

    shapeUV += vec2(-u_offsetX, u_offsetY) / patternWorldScale;
    shapeUV += boxOrigin;
    shapeUV -= boxOrigin / patternWorldScale;
    shapeUV *= u_resolution.xy;
    shapeUV /= u_pixelRatio;
    if (u_fit > 0.) {
      shapeUV *= (patternWorldNoFitBoxWidth / patternBoxSize.x);
    }
    shapeUV /= u_scale;
    shapeUV = graphicRotation * shapeUV;
    shapeUV += boxOrigin / patternWorldScale;
    shapeUV -= boxOrigin;
    shapeUV += .5;
  }

  float shape = 0.;
  if (u_shape < 1.5) {
    // Simplex noise
    shapeUV *= .001;

    shape = 0.5 + 0.5 * getSimplexNoise(shapeUV, t);
    shape = smoothstep(0.3, 0.9, shape);

  } else if (u_shape < 2.5) {
    // Warp
    shapeUV *= .003;

    for (float i = 1.0; i < 6.0; i++) {
      shapeUV.x += 0.6 / i * cos(i * 2.5 * shapeUV.y + t);
      shapeUV.y += 0.6 / i * cos(i * 1.5 * shapeUV.x + t);
    }

    shape = .15 / max(0.001, abs(sin(t - shapeUV.y - shapeUV.x)));
    shape = smoothstep(0.02, 1., shape);

  } else if (u_shape < 3.5) {
    // Dots
    shapeUV *= .05;

    float stripeIdx = floor(2. * shapeUV.x / TWO_PI);
    float rand = hash11(stripeIdx * 10.);
    rand = sign(rand - .5) * pow(.1 + abs(rand), .4);
    shape = sin(shapeUV.x) * cos(shapeUV.y - 5. * rand * t);
    shape = pow(abs(shape), 6.);

  } else if (u_shape < 4.5) {
    // Sine wave
    shapeUV *= 4.;

    float wave = cos(.5 * shapeUV.x - 2. * t) * sin(1.5 * shapeUV.x + t) * (.75 + .25 * cos(3. * t));
    shape = 1. - smoothstep(-1., 1., shapeUV.y + wave);

  } else if (u_shape < 5.5) {
    // Ripple

    float dist = length(shapeUV);
    float waves = sin(pow(dist, 1.7) * 7. - 3. * t) * .5 + .5;
    shape = waves;

  } else if (u_shape < 6.5) {
    // Swirl

    float l = length(shapeUV);
    float angle = 6. * atan(shapeUV.y, shapeUV.x) + 4. * t;
    float twist = 1.2;
    float offset = 1. / pow(max(l, 1e-6), twist) + angle / TWO_PI;
    float mid = smoothstep(0., 1., pow(l, twist));
    shape = mix(0., fract(offset), mid);

  } else {
    // Sphere
    shapeUV *= 2.;

    float d = 1. - pow(length(shapeUV), 2.);
    vec3 pos = vec3(shapeUV, sqrt(max(0., d)));
    vec3 lightPos = normalize(vec3(cos(1.5 * t), .8, sin(1.25 * t)));
    shape = .5 + .5 * dot(lightPos, pos);
    shape *= step(0., d);
  }


  int type = int(floor(u_type));
  float dithering = 0.0;

  switch (type) {
    case 1: {
      dithering = step(hash21(ditheringNoiseUV), shape);
    } break;
    case 2:
    dithering = getBayerValue(pxSizeUV, 2);
    break;
    case 3:
    dithering = getBayerValue(pxSizeUV, 4);
    break;
    default :
    dithering = getBayerValue(pxSizeUV, 8);
    break;
  }

  dithering -= .5;
  float res = step(.5, shape + dithering);

  vec3 fgColor = u_colorFront.rgb * u_colorFront.a;
  float fgOpacity = u_colorFront.a;
  vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
  float bgOpacity = u_colorBack.a;

  vec3 color = fgColor * res;
  float opacity = fgOpacity * res;

  color += bgColor * (1. - opacity);
  opacity += bgOpacity * (1. - opacity);

  fragColor = vec4(color, opacity);
}
`,Ln={simplex:1,warp:2,dots:3,wave:4,ripple:5,swirl:6,sphere:7},Rn={random:1,"2x2":2,"4x4":3,"8x8":4},zn=`#version 300 es
precision mediump float;

uniform vec2 u_resolution;
uniform float u_pixelRatio;

uniform vec4 u_colorFront;
uniform vec4 u_colorBack;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;

uniform float u_contrast;
uniform float u_roughness;
uniform float u_fiber;
uniform float u_fiberSize;
uniform float u_crumples;
uniform float u_crumpleSize;
uniform float u_folds;
uniform float u_foldCount;
uniform float u_drops;
uniform float u_seed;
uniform float u_fade;

uniform sampler2D u_noiseTexture;

in vec2 v_imageUV;

out vec4 fragColor;

float getUvFrame(vec2 uv) {
  float aax = 2. * fwidth(uv.x);
  float aay = 2. * fwidth(uv.y);

  float left   = smoothstep(0., aax, uv.x);
  float right = 1. - smoothstep(1. - aax, 1., uv.x);
  float bottom = smoothstep(0., aay, uv.y);
  float top = 1. - smoothstep(1. - aay, 1., uv.y);

  return left * right * bottom * top;
}

${Tn}
${En}
${kn}
float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = randomR(i);
  float b = randomR(i + vec2(1.0, 0.0));
  float c = randomR(i + vec2(0.0, 1.0));
  float d = randomR(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  float x1 = mix(a, b, u.x);
  float x2 = mix(c, d, u.x);
  return mix(x1, x2, u.y);
}
float fbm(vec2 n) {
  float total = 0.0, amplitude = .4;
  for (int i = 0; i < 3; i++) {
    total += valueNoise(n) * amplitude;
    n *= 1.99;
    amplitude *= 0.65;
  }
  return total;
}


float randomG(vec2 p) {
  vec2 uv = floor(p) / 50. + .5;
  return texture(u_noiseTexture, fract(uv)).g;
}
float roughness(vec2 p) {
  p *= .1;
  float o = 0.;
  for (float i = 0.; ++i < 4.; p *= 2.1) {
    vec4 w = vec4(floor(p), ceil(p));
    vec2 f = fract(p);
    o += mix(
    mix(randomG(w.xy), randomG(w.xw), f.y),
    mix(randomG(w.zy), randomG(w.zw), f.y),
    f.x);
    o += .2 / exp(2. * abs(sin(.2 * p.x + .5 * p.y)));
  }
  return o / 3.;
}

${Nn}

vec2 randomGB(vec2 p) {
  vec2 uv = floor(p) / 50. + .5;
  return texture(u_noiseTexture, fract(uv)).gb;
}
float crumpledNoise(vec2 t, float pw) {
  vec2 p = floor(t);
  float wsum = 0.;
  float cl = 0.;
  for (int y = -1; y < 2; y += 1) {
    for (int x = -1; x < 2; x += 1) {
      vec2 b = vec2(float(x), float(y));
      vec2 q = b + p;
      vec2 q2 = q - floor(q / 8.) * 8.;
      vec2 c = q + randomGB(q2);
      vec2 r = c - t;
      float w = pow(smoothstep(0., 1., 1. - abs(r.x)), pw) * pow(smoothstep(0., 1., 1. - abs(r.y)), pw);
      cl += (.5 + .5 * sin((q2.x + q2.y * 5.) * 8.)) * w;
      wsum += w;
    }
  }
  return pow(wsum != 0.0 ? cl / wsum : 0.0, .5) * 2.;
}
float crumplesShape(vec2 uv) {
  return crumpledNoise(uv * .25, 16.) * crumpledNoise(uv * .5, 2.);
}


vec2 folds(vec2 uv) {
  vec3 pp = vec3(0.);
  float l = 9.;
  for (float i = 0.; i < 15.; i++) {
    if (i >= u_foldCount) break;
    vec2 rand = randomGB(vec2(i, i * u_seed));
    float an = rand.x * TWO_PI;
    vec2 p = vec2(cos(an), sin(an)) * rand.y;
    float dist = distance(uv, p);
    l = min(l, dist);

    if (l == dist) {
      pp.xy = (uv - p.xy);
      pp.z = dist;
    }
  }
  return mix(pp.xy, vec2(0.), pow(pp.z, .25));
}

float drops(vec2 uv) {
  vec2 iDropsUV = floor(uv);
  vec2 fDropsUV = fract(uv);
  float dropsMinDist = 1.;
  for (int j = -1; j <= 1; j++) {
    for (int i = -1; i <= 1; i++) {
      vec2 neighbor = vec2(float(i), float(j));
      vec2 offset = randomGB(iDropsUV + neighbor);
      offset = .5 + .5 * sin(10. * u_seed + TWO_PI * offset);
      vec2 pos = neighbor + offset - fDropsUV;
      float dist = length(pos);
      dropsMinDist = min(dropsMinDist, dropsMinDist*dist);
    }
  }
  return 1. - smoothstep(.05, .09, pow(dropsMinDist, .5));
}

float lst(float edge0, float edge1, float x) {
  return clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
}

void main() {

  vec2 imageUV = v_imageUV;
  vec2 patternUV = v_imageUV - .5;
  patternUV = 5. * (patternUV * vec2(u_imageAspectRatio, 1.));

  vec2 roughnessUv = 1.5 * (gl_FragCoord.xy - .5 * u_resolution) / u_pixelRatio;
  float roughness = roughness(roughnessUv + vec2(1., 0.)) - roughness(roughnessUv - vec2(1., 0.));

  vec2 crumplesUV = fract(patternUV * .02 / u_crumpleSize - u_seed) * 32.;
  float crumples = u_crumples * (crumplesShape(crumplesUV + vec2(.05, 0.)) - crumplesShape(crumplesUV));

  vec2 fiberUV = 2. / u_fiberSize * patternUV;
  float fiber = fiberNoise(fiberUV, vec2(0.));
  fiber = .5 * u_fiber * (fiber - 1.);

  vec2 normal = vec2(0.);
  vec2 normalImage = vec2(0.);

  vec2 foldsUV = patternUV * .12;
  foldsUV = rotate(foldsUV, 4. * u_seed);
  vec2 w = folds(foldsUV);
  foldsUV = rotate(foldsUV + .007 * cos(u_seed), .01 * sin(u_seed));
  vec2 w2 = folds(foldsUV);

  float drops = u_drops * drops(patternUV * 2.);

  float fade = u_fade * fbm(.17 * patternUV + 10. * u_seed);
  fade = clamp(8. * fade * fade * fade, 0., 1.);

  w = mix(w, vec2(0.), fade);
  w2 = mix(w2, vec2(0.), fade);
  crumples = mix(crumples, 0., fade);
  drops = mix(drops, 0., fade);
  fiber *= mix(1., .5, fade);
  roughness *= mix(1., .5, fade);

  normal.xy += u_folds * min(5. * u_contrast, 1.) * 4. * max(vec2(0.), w + w2);
  normalImage.xy += u_folds * 2. * w;

  normal.xy += crumples;
  normalImage.xy += 1.5 * crumples;

  normal.xy += 3. * drops;
  normalImage.xy += .2 * drops;

  normal.xy += u_roughness * 1.5 * roughness;
  normal.xy += fiber;

  normalImage += u_roughness * .75 * roughness;
  normalImage += .2 * fiber;

  vec3 lightPos = vec3(1., 2., 1.);
  float res = dot(normalize(vec3(normal, 9.5 - 9. * pow(u_contrast, .1))), normalize(lightPos));

  vec3 fgColor = u_colorFront.rgb * u_colorFront.a;
  float fgOpacity = u_colorFront.a;
  vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
  float bgOpacity = u_colorBack.a;

  imageUV += .02 * normalImage;
  float frame = getUvFrame(imageUV);
  vec4 image = texture(u_image, imageUV);
  image.rgb += .6 * pow(u_contrast, .4) * (res - .7);

  frame *= image.a;

  vec3 color = fgColor * res;
  float opacity = fgOpacity * res;

  color += bgColor * (1. - opacity);
  opacity += bgOpacity * (1. - opacity);
  opacity = mix(opacity, 1., frame);

  color -= .007 * drops;

  color.rgb = mix(color, image.rgb, frame);

  fragColor = vec4(color, opacity);
}
`,Bn=`#version 300 es
precision mediump float;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_rotation;

uniform vec4 u_colorBack;
uniform vec4 u_colorShadow;
uniform vec4 u_colorHighlight;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;

uniform float u_size;
uniform float u_shadows;
uniform float u_angle;
uniform float u_stretch;
uniform float u_shape;
uniform float u_distortion;
uniform float u_highlights;
uniform float u_distortionShape;
uniform float u_shift;
uniform float u_blur;
uniform float u_edges;
uniform float u_marginLeft;
uniform float u_marginRight;
uniform float u_marginTop;
uniform float u_marginBottom;
uniform float u_grainMixer;
uniform float u_grainOverlay;

in vec2 v_imageUV;

out vec4 fragColor;

${Tn}
${En}
${On}

float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  float x1 = mix(a, b, u.x);
  float x2 = mix(c, d, u.x);
  return mix(x1, x2, u.y);
}

float getUvFrame(vec2 uv, float softness) {
  float aax = 2. * fwidth(uv.x);
  float aay = 2. * fwidth(uv.y);
  float left   = smoothstep(0., aax + softness, uv.x);
  float right  = 1. - smoothstep(1. - softness - aax, 1., uv.x);
  float bottom = smoothstep(0., aay + softness, uv.y);
  float top    = 1. - smoothstep(1. - softness - aay, 1., uv.y);
  return left * right * bottom * top;
}

const int MAX_RADIUS = 50;
vec4 samplePremultiplied(sampler2D tex, vec2 uv) {
  vec4 c = texture(tex, uv);
  c.rgb *= c.a;
  return c;
}
vec4 getBlur(sampler2D tex, vec2 uv, vec2 texelSize, vec2 dir, float sigma) {
  if (sigma <= .5) return texture(tex, uv);
  int radius = int(min(float(MAX_RADIUS), ceil(3.0 * sigma)));

  float twoSigma2 = 2.0 * sigma * sigma;
  float gaussianNorm = 1.0 / sqrt(TWO_PI * sigma * sigma);

  vec4 sum = samplePremultiplied(tex, uv) * gaussianNorm;
  float weightSum = gaussianNorm;

  for (int i = 1; i <= MAX_RADIUS; i++) {
    if (i > radius) break;

    float x = float(i);
    float w = exp(-(x * x) / twoSigma2) * gaussianNorm;

    vec2 offset = dir * texelSize * x;
    vec4 s1 = samplePremultiplied(tex, uv + offset);
    vec4 s2 = samplePremultiplied(tex, uv - offset);

    sum += (s1 + s2) * w;
    weightSum += 2.0 * w;
  }

  vec4 result = sum / weightSum;
  if (result.a > 0.) {
    result.rgb /= result.a;
  }

  return result;
}

vec2 rotateAspect(vec2 p, float a, float aspect) {
  p.x *= aspect;
  p = rotate(p, a);
  p.x /= aspect;
  return p;
}

float smoothFract(float x) {
  float f = fract(x);
  float w = fwidth(x);

  float edge = abs(f - 0.5) - 0.5;
  float band = smoothstep(-w, w, edge);

  return mix(f, 1.0 - f, band);
}

void main() {

  float patternRotation = -u_angle * PI / 180.;
  float patternSize = mix(200., 5., u_size);

  vec2 uv = v_imageUV;

  vec2 uvMask = gl_FragCoord.xy / u_resolution.xy;
  vec2 sw = vec2(.005);
  vec4 margins = vec4(u_marginLeft, u_marginTop, u_marginRight, u_marginBottom);
  float mask =
  smoothstep(margins[0], margins[0] + sw.x, uvMask.x + sw.x) *
  smoothstep(margins[2], margins[2] + sw.x, 1.0 - uvMask.x + sw.x) *
  smoothstep(margins[1], margins[1] + sw.y, uvMask.y + sw.y) *
  smoothstep(margins[3], margins[3] + sw.y, 1.0 - uvMask.y + sw.y);
  float maskOuter =
  smoothstep(margins[0] - sw.x, margins[0], uvMask.x + sw.x) *
  smoothstep(margins[2] - sw.x, margins[2], 1.0 - uvMask.x + sw.x) *
  smoothstep(margins[1] - sw.y, margins[1], uvMask.y + sw.y) *
  smoothstep(margins[3] - sw.y, margins[3], 1.0 - uvMask.y + sw.y);
  float maskStroke = maskOuter - mask;
  float maskInner =
  smoothstep(margins[0] - 2. * sw.x, margins[0], uvMask.x) *
  smoothstep(margins[2] - 2. * sw.x, margins[2], 1.0 - uvMask.x) *
  smoothstep(margins[1] - 2. * sw.y, margins[1], uvMask.y) *
  smoothstep(margins[3] - 2. * sw.y, margins[3], 1.0 - uvMask.y);
  float maskStrokeInner = maskInner - mask;

  uv -= .5;
  uv *= patternSize;
  uv = rotateAspect(uv, patternRotation, u_imageAspectRatio);

  float curve = 0.;
  float patternY = uv.y / u_imageAspectRatio;
  if (u_shape > 4.5) {
    // pattern
    curve = .5 + .5 * sin(.5 * PI * uv.x) * cos(.5 * PI * patternY);
  } else if (u_shape > 3.5) {
    // zigzag
    curve = 10. * abs(fract(.1 * patternY) - .5);
  } else if (u_shape > 2.5) {
    // wave
    curve = 4. * sin(.23 * patternY);
  } else if (u_shape > 1.5) {
    // lines irregular
    curve = .5 + .5 * sin(.5 * uv.x) * sin(1.7 * uv.x);
  } else {
    // lines
  }

  vec2 UvToFract = uv + curve;
  vec2 fractOrigUV = fract(uv);
  vec2 floorOrigUV = floor(uv);

  float x = smoothFract(UvToFract.x);
  float xNonSmooth = fract(UvToFract.x) + .0001;

  float highlightsWidth = 2. * max(.001, fwidth(UvToFract.x));
  highlightsWidth += 2. * maskStrokeInner;
  float highlights = smoothstep(0., highlightsWidth, xNonSmooth);
  highlights *= smoothstep(1., 1. - highlightsWidth, xNonSmooth);
  highlights = 1. - highlights;
  highlights *= u_highlights;
  highlights = clamp(highlights, 0., 1.);
  highlights *= mask;

  float shadows = pow(x, 1.3);
  float distortion = 0.;
  float fadeX = 1.;
  float frameFade = 0.;

  float aa = fwidth(xNonSmooth);
  aa = max(aa, fwidth(uv.x));
  aa = max(aa, fwidth(UvToFract.x));
  aa = max(aa, .0001);

  if (u_distortionShape == 1.) {
    distortion = -pow(1.5 * x, 3.);
    distortion += (.5 - u_shift);

    frameFade = pow(1.5 * x, 3.);
    aa = max(.2, aa);
    aa += mix(.2, 0., u_size);
    fadeX = smoothstep(0., aa, xNonSmooth) * smoothstep(1., 1. - aa, xNonSmooth);
    distortion = mix(.5, distortion, fadeX);
  } else if (u_distortionShape == 2.) {
    distortion = 2. * pow(x, 2.);
    distortion -= (.5 + u_shift);

    frameFade = pow(abs(x - .5), 4.);
    aa = max(.2, aa);
    aa += mix(.2, 0., u_size);
    fadeX = smoothstep(0., aa, xNonSmooth) * smoothstep(1., 1. - aa, xNonSmooth);
    distortion = mix(.5, distortion, fadeX);
    frameFade = mix(1., frameFade, .5 * fadeX);
  } else if (u_distortionShape == 3.) {
    distortion = pow(2. * (xNonSmooth - .5), 6.);
    distortion -= .25;
    distortion -= u_shift;

    frameFade = 1. - 2. * pow(abs(x - .4), 2.);
    aa = .15;
    aa += mix(.1, 0., u_size);
    fadeX = smoothstep(0., aa, xNonSmooth) * smoothstep(1., 1. - aa, xNonSmooth);
    frameFade = mix(1., frameFade, fadeX);

  } else if (u_distortionShape == 4.) {
    x = xNonSmooth;
    distortion = sin((x + .25) * TWO_PI);
    shadows = .5 + .5 * asin(distortion) / (.5 * PI);
    distortion *= .5;
    distortion -= u_shift;
    frameFade = .5 + .5 * sin(x * TWO_PI);
  } else if (u_distortionShape == 5.) {
    distortion -= pow(abs(x), .2) * x;
    distortion += .33;
    distortion -= 3. * u_shift;
    distortion *= .33;

    frameFade = .3 * (smoothstep(.0, 1., x));
    shadows = pow(x, 2.5);

    aa = max(.1, aa);
    aa += mix(.1, 0., u_size);
    fadeX = smoothstep(0., aa, xNonSmooth) * smoothstep(1., 1. - aa, xNonSmooth);
    distortion *= fadeX;
  }

  vec2 dudx = dFdx(v_imageUV);
  vec2 dudy = dFdy(v_imageUV);
  vec2 grainUV = v_imageUV - .5;
  grainUV *= (.8 / vec2(length(dudx), length(dudy)));
  grainUV += .5;
  float grain = valueNoise(grainUV);
  grain = smoothstep(.4, .7, grain);
  grain *= u_grainMixer;
  distortion = mix(distortion, 0., grain);

  shadows = min(shadows, 1.);
  shadows += maskStrokeInner;
  shadows *= mask;
  shadows = min(shadows, 1.);
  shadows *= pow(u_shadows, 2.);
  shadows = clamp(shadows, 0., 1.);

  distortion *= 3. * u_distortion;
  frameFade *= u_distortion;

  fractOrigUV.x += distortion;
  floorOrigUV = rotateAspect(floorOrigUV, -patternRotation, u_imageAspectRatio);
  fractOrigUV = rotateAspect(fractOrigUV, -patternRotation, u_imageAspectRatio);

  uv = (floorOrigUV + fractOrigUV) / patternSize;
  uv += pow(maskStroke, 4.);

  uv += vec2(.5);

  uv = mix(v_imageUV, uv, smoothstep(0., .7, mask));
  float blur = mix(0., 50., u_blur);
  blur = mix(0., blur, smoothstep(.5, 1., mask));

  float edgeDistortion = mix(.0, .04, u_edges);
  edgeDistortion += .06 * frameFade * u_edges;
  edgeDistortion *= mask;
  float frame = getUvFrame(uv, edgeDistortion);

  float stretch = 1. - smoothstep(0., .5, xNonSmooth) * smoothstep(1., 1. - .5, xNonSmooth);
  stretch = pow(stretch, 2.);
  stretch *= mask;
  stretch *= getUvFrame(uv, .1 + .05 * mask * frameFade);
  uv.y = mix(uv.y, .5, u_stretch * stretch);

  vec4 image = getBlur(u_image, uv, 1. / u_resolution / u_pixelRatio, vec2(0., 1.), blur);
  image.rgb *= image.a;
  vec4 backColor = u_colorBack;
  backColor.rgb *= backColor.a;
  vec4 highlightColor = u_colorHighlight;
  highlightColor.rgb *= highlightColor.a;
  vec4 shadowColor = u_colorShadow;

  vec3 color = highlightColor.rgb * highlights;
  float opacity = highlightColor.a * highlights;

  shadows = mix(shadows * shadowColor.a, 0., highlights);
  color = mix(color, shadowColor.rgb * shadowColor.a, .5 * shadows);
  color += .5 * pow(shadows, .5) * shadowColor.rgb;
  opacity += shadows;
  color = clamp(color, vec3(0.), vec3(1.));
  opacity = clamp(opacity, 0., 1.);

  color += image.rgb * (1. - opacity) * frame;
  opacity += image.a * (1. - opacity) * frame;

  color += backColor.rgb * (1. - opacity);
  opacity += backColor.a * (1. - opacity);

  float grainOverlay = valueNoise(rotate(grainUV, 1.) + vec2(3.));
  grainOverlay = mix(grainOverlay, valueNoise(rotate(grainUV, 2.) + vec2(-1.)), .5);
  grainOverlay = pow(grainOverlay, 1.3);

  float grainOverlayV = grainOverlay * 2. - 1.;
  vec3 grainOverlayColor = vec3(step(0., grainOverlayV));
  float grainOverlayStrength = u_grainOverlay * abs(grainOverlayV);
  grainOverlayStrength = pow(grainOverlayStrength, .8);
  grainOverlayStrength *= mask;
  color = mix(color, grainOverlayColor, .35 * grainOverlayStrength);

  opacity += .5 * grainOverlayStrength;
  opacity = clamp(opacity, 0., 1.);

  fragColor = vec4(color, opacity);
}
`,Vn={lines:1,linesIrregular:2,wave:3,zigzag:4,pattern:5},Hn={prism:1,lens:2,contour:3,cascade:4,flat:5},Un=`#version 300 es
precision mediump float;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;

uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

uniform vec4 u_colorFront;
uniform vec4 u_colorBack;
uniform vec4 u_colorHighlight;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;

uniform float u_type;
uniform float u_pxSize;
uniform bool u_originalColors;
uniform bool u_inverted;
uniform float u_colorSteps;

out vec4 fragColor;


${On}
${Tn}

float getUvFrame(vec2 uv, vec2 pad) {
  float aa = 0.0001;

  float left   = smoothstep(-pad.x, -pad.x + aa, uv.x);
  float right  = smoothstep(1.0 + pad.x, 1.0 + pad.x - aa, uv.x);
  float bottom = smoothstep(-pad.y, -pad.y + aa, uv.y);
  float top    = smoothstep(1.0 + pad.y, 1.0 + pad.y - aa, uv.y);

  return left * right * bottom * top;
}

vec2 getImageUV(vec2 uv) {
  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  float r = u_rotation * PI / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);

  vec2 imageBoxSize;
  if (u_fit == 1.) { // contain
    imageBoxSize.x = min(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else if (u_fit == 2.) { // cover
    imageBoxSize.x = max(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else {
    imageBoxSize.x = min(10.0, 10.0 / u_imageAspectRatio * u_imageAspectRatio);
  }
  imageBoxSize.y = imageBoxSize.x / u_imageAspectRatio;
  vec2 imageBoxScale = u_resolution.xy / imageBoxSize;

  vec2 imageUV = uv;
  imageUV *= imageBoxScale;
  imageUV += boxOrigin * (imageBoxScale - 1.);
  imageUV += graphicOffset;
  imageUV /= u_scale;
  imageUV.x *= u_imageAspectRatio;
  imageUV = graphicRotation * imageUV;
  imageUV.x /= u_imageAspectRatio;

  imageUV += .5;
  imageUV.y = 1. - imageUV.y;

  return imageUV;
}

const int bayer2x2[4] = int[4](0, 2, 3, 1);
const int bayer4x4[16] = int[16](
0, 8, 2, 10,
12, 4, 14, 6,
3, 11, 1, 9,
15, 7, 13, 5
);

const int bayer8x8[64] = int[64](
0, 32, 8, 40, 2, 34, 10, 42,
48, 16, 56, 24, 50, 18, 58, 26,
12, 44, 4, 36, 14, 46, 6, 38,
60, 28, 52, 20, 62, 30, 54, 22,
3, 35, 11, 43, 1, 33, 9, 41,
51, 19, 59, 27, 49, 17, 57, 25,
15, 47, 7, 39, 13, 45, 5, 37,
63, 31, 55, 23, 61, 29, 53, 21
);

float getBayerValue(vec2 uv, int size) {
  ivec2 pos = ivec2(fract(uv / float(size)) * float(size));
  int index = pos.y * size + pos.x;

  if (size == 2) {
    return float(bayer2x2[index]) / 4.0;
  } else if (size == 4) {
    return float(bayer4x4[index]) / 16.0;
  } else if (size == 8) {
    return float(bayer8x8[index]) / 64.0;
  }
  return 0.0;
}


void main() {

  float pxSize = u_pxSize * u_pixelRatio;
  vec2 pxSizeUV = gl_FragCoord.xy - .5 * u_resolution;
  pxSizeUV /= pxSize;
  vec2 canvasPixelizedUV = (floor(pxSizeUV) + .5) * pxSize;
  vec2 normalizedUV = canvasPixelizedUV / u_resolution;

  vec2 imageUV = getImageUV(normalizedUV);
  vec2 ditheringNoiseUV = canvasPixelizedUV;
  vec4 image = texture(u_image, imageUV);
  float frame = getUvFrame(imageUV, pxSize / u_resolution);

  int type = int(floor(u_type));
  float dithering = 0.0;

  float lum = dot(vec3(.2126, .7152, .0722), image.rgb);
  lum = u_inverted ? (1. - lum) : lum;

  switch (type) {
    case 1: {
      dithering = step(hash21(ditheringNoiseUV), lum);
    } break;
    case 2:
    dithering = getBayerValue(pxSizeUV, 2);
    break;
    case 3:
    dithering = getBayerValue(pxSizeUV, 4);
    break;
    default :
    dithering = getBayerValue(pxSizeUV, 8);
    break;
  }

  float colorSteps = max(floor(u_colorSteps), 1.);
  vec3 color = vec3(0.0);
  float opacity = 1.;

  dithering -= .5;
  float brightness = clamp(lum + dithering / colorSteps, 0.0, 1.0);
  brightness = mix(0.0, brightness, frame);
  brightness = mix(0.0, brightness, image.a);
  float quantLum = floor(brightness * colorSteps + 0.5) / colorSteps;
  quantLum = mix(0.0, quantLum, frame);

  if (u_originalColors == true) {
    vec3 normColor = image.rgb / max(lum, 0.001);
    color = normColor * quantLum;

    float quantAlpha = floor(image.a * colorSteps + 0.5) / colorSteps;
    opacity = mix(quantLum, 1., quantAlpha);
  } else {
    vec3 fgColor = u_colorFront.rgb * u_colorFront.a;
    float fgOpacity = u_colorFront.a;
    vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
    float bgOpacity = u_colorBack.a;
    vec3 hlColor = u_colorHighlight.rgb * u_colorHighlight.a;
    float hlOpacity = u_colorHighlight.a;

    fgColor = mix(fgColor, hlColor, step(1.02 - .02 * u_colorSteps, brightness));
    fgOpacity = mix(fgOpacity, hlOpacity, step(1.02 - .02 * u_colorSteps, brightness));

    color = fgColor * quantLum;
    opacity = fgOpacity * quantLum;
    color += bgColor * (1.0 - opacity);
    opacity += bgOpacity * (1.0 - opacity);
  }

  fragColor = vec4(color, opacity);
}
`,Wn=`#version 300 es
precision mediump float;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;
uniform float u_spread;
uniform float u_bias;
uniform float u_angle;
uniform float u_perspective;
uniform float u_count;
uniform float u_dispersion;
uniform float u_dispersionShift;
uniform float u_dispersionColor;
uniform float u_focusCenter;
uniform float u_focusEdges;
uniform float u_swirl;
uniform float u_noise;
uniform float u_noiseFrequency;
uniform float u_noiseOffset;
uniform float u_lensBulge;
uniform float u_lensCircle;
uniform float u_grainMixer;
uniform float u_grainOverlay;
uniform float u_imageX;
uniform float u_imageY;

in vec2 v_imageUV;

out vec4 fragColor;

${Tn}
${On}
${En}

float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1., 0.));
  float c = hash21(i + vec2(0., 1.));
  float d = hash21(i + vec2(1., 1.));
  vec2 u = f * f * (3. - 2. * f);
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float getUvFrame(vec2 uv) {
  vec2 invAA = 1. / clamp(fwidth(uv), 1e-5, .02);
  vec2 lo = clamp(uv * invAA + .5, 0., 1.);
  vec2 hi = clamp((1. - uv) * invAA + .5, 0., 1.);
  return lo.x * hi.x * lo.y * hi.y;
}

vec4 sampleOverWhite(vec2 uv) {
  vec4 img = texture(u_image, uv);
  float cover = img.a * getUvFrame(uv);
  vec3 colorOverWhite = mix(vec3(1.), img.rgb, cover);
  return vec4(colorOverWhite, cover);
}

vec3 hueColor(float hue) {
  vec3 rgb = clamp(abs(mod(hue * 6. + vec3(0., 4., 2.), 6.) - 3.) - 1., 0., 1.);
  rgb = rgb * rgb * (3. - 2. * rgb);
  return rgb;
}
                                            
float boxInradius() {
  return .5 * min(u_imageAspectRatio, 1.);
}

float boxOutradius() {
  return .5 * length(vec2(u_imageAspectRatio, 1.));
}

float spreadReach() {
  return .7 * pow(u_spread, 1.3 + 2.7 * u_spread);
}

float innerCircleMask(float radius, float inradius) {
  return 1. - smoothstep(.5 * inradius, 1.1 * inradius, radius);
}

float dispersionCurve(float t, float biasPow) {
  float mirroredT = u_bias < 0. ? 1. - t : t;
  float curved = pow(mirroredT, biasPow);
  return u_bias < 0. ? 1. - curved : curved;
}

vec2 getSpread(vec2 fromCenter, float radius, vec2 warpedUV, float edgeAA, float inradius, float outradius, float reach, out float outStrength) {
  float angleRad = radians(u_angle);
  vec2 uniformDir = vec2(cos(angleRad), sin(angleRad));

  float invInradius = 1. / inradius;
  vec2 radialDir = fromCenter * invInradius;
  float maxLen = (outradius + reach) * invInradius;
  float radialLen = radius * invInradius;
  if (radialLen > maxLen) radialDir *= maxLen / radialLen;
  vec2 spreadDir = mix(uniformDir, radialDir, u_perspective);

  float bandProximity = smoothstep(inradius * .8, inradius, radius);
  float lensCircleMaxing = bandProximity * u_lensCircle * u_lensCircle * u_lensCircle;
  spreadDir = mix(spreadDir, radialDir, lensCircleMaxing);

  vec2 warpedAbs = abs(warpedUV - .5);
  float inner = mix(1., smoothstep(0., mix(inradius, outradius, u_focusCenter), radius), u_focusCenter);
  float boxDist = max(warpedAbs.x, warpedAbs.y) * 2.;
  float outer = mix(1., 1. - min(boxDist, 1.), u_focusEdges);
  float strength = inner * outer;

  strength *= mix(1., mix(.15, .03, max(-u_lensBulge, 0.)), lensCircleMaxing);

  vec2 outside = max(warpedAbs - .5, 0.);
  float margin = max(reach * length(spreadDir) * (1. - u_lensCircle), edgeAA);
  strength *= 1. - smoothstep(0., margin, length(outside));

  outStrength = strength;
  vec2 axis = spreadDir * (reach * strength);

  if (u_noise > 0.) {
    float turn = (valueNoise(fromCenter * u_noiseFrequency * 18. + u_noiseOffset * 30.) - .5) * 2. * u_noise;
    float cs = cos(turn), sn = sin(turn);
    axis = mat2(cs, -sn, sn, cs) * axis;
  }

  axis.x /= u_imageAspectRatio;
  return axis;
}

vec2 lensWarp(vec2 fromCenter, float radius, float inradius, out float bulgeFade) {
  bulgeFade = 1.;
  if (u_lensBulge == 0. && u_lensCircle <= 0.) return fromCenter;
  if (radius < 1e-5) return fromCenter;
  
  float r = radius;

  if (u_lensBulge != 0.) {
    float rn = radius / inradius;
    float bulge = abs(u_lensBulge) * (u_lensBulge > 0. ? 1.4 : 1.2);
    if (u_lensBulge > 0.) bulgeFade = 1. - smoothstep(1.45, 1.53, rn * bulge);
    float map = u_lensBulge > 0.
      ? tan(min(rn * bulge, 1.53)) / tan(bulge)
      : atan(rn * tan(bulge)) / bulge;
    float bulgeScale = map / rn;
    fromCenter *= bulgeScale;
    r *= bulgeScale;
  }

  if (u_lensCircle > 0.) {
    vec2 dir = fromCenter / max(r, 1e-5);
    vec2 halfBox = vec2(u_imageAspectRatio, 1.) * .5;
    float rBox = min(halfBox.x / max(abs(dir.x), 1e-4), halfBox.y / max(abs(dir.y), 1e-4));
    float band = inradius * mix(.03, .2, .5 * (u_lensBulge + 1.));
    float innerEdge = inradius - band;
    float over = smoothstep(0., 1., (r - innerEdge) / band);
    float g = r + (rBox - inradius) * pow(over, 14.);
    fromCenter = dir * mix(r, g, u_lensCircle);
  }

  return fromCenter;
}

void main() {
  vec2 uv = v_imageUV;

  float invAspect = 1. / u_imageAspectRatio;
  float inradius = boxInradius();
  float outradius = boxOutradius();
  float reach = spreadReach();

  vec2 fromCenter = uv - .5;
  fromCenter.x *= u_imageAspectRatio;
  float radius = length(fromCenter);

  float bulgeFade;
  vec2 warpedFromCenter = lensWarp(fromCenter, radius, inradius, bulgeFade);
  vec2 baseUV = vec2(warpedFromCenter.x * invAspect, warpedFromCenter.y) + .5;

  vec2 baseDerivative = fwidth(baseUV);
  float edgeAA = clamp(2. * max(baseDerivative.x, baseDerivative.y), .001, .02);

  float spreadStrength;
  vec2 spreadAxis = getSpread(fromCenter, radius, baseUV, edgeAA, inradius, outradius, reach, spreadStrength);

  vec2 grainUV = vec2(0.);
  if (u_grainMixer > 0. || u_grainOverlay > 0.) {
    vec2 dudx = dFdx(v_imageUV);
    vec2 dudy = dFdy(v_imageUV);
    grainUV = (v_imageUV - .5) * (.8 / vec2(length(dudx), length(dudy))) + .5;
  }

  if (u_grainMixer > 0.) {
    float grainSeed = valueNoise(grainUV);
    vec2 jit = fract(grainSeed * vec2(157.31, 113.57)) * 2. - 1.;
    spreadAxis += jit * .3 * u_grainMixer * length(spreadAxis);
  }

  float count = floor(u_count);
  int countInteger = int(count);

  float invCount = 1. / count;
  float invSpan = 1. / max(count - 1., 1.);
  float hueBase = u_dispersionColor + .5;
  float biasPower = 1. + 2. * abs(u_bias);
  vec2 tapBias = .5 - vec2(u_imageX, u_imageY);

  float centerAmount = clamp(1. - u_dispersionShift, 0., 1.);
  float edgesAmount = clamp(1. + u_dispersionShift, 0., 1.);
  float dispersion = u_dispersion * mix(edgesAmount, centerAmount, innerCircleMask(radius, inradius));
  float dispersionPower = pow(dispersion, .8);

  float warpedRadius = length(warpedFromCenter);
  float swirlAngle = u_swirl * .4 * PI * spreadStrength * u_spread * min(1., inradius / max(warpedRadius, 1e-4));

  vec3 colorSum = vec3(0.);
  vec3 weightSum = vec3(0.);
  float coverSum = 0.;

  for (int i = 0; i < ${{maxSamples:50}.maxSamples}; i++) {
    if (i >= countInteger) break;

    float layer = float(i);
    float hue = hueBase + layer * invCount;

    float spread = layer * invSpan;
    if (u_bias != 0.) spread = dispersionCurve(spread, biasPower);

    // mix(axis, -axis, spread) is axis scaled by the signed position along the fan
    float fanPos = 1. - 2. * spread;
    vec2 tapUV = baseUV + spreadAxis * fanPos - .5;

    if (u_swirl != 0.) {
      tapUV.x *= u_imageAspectRatio;
      tapUV = rotate(tapUV, swirlAngle * fanPos);
      tapUV.x *= invAspect;
    }

    vec4 tap = sampleOverWhite(tapUV + tapBias);
    vec3 weight = 1. - dispersionPower * hueColor(hue);

    colorSum += tap.rgb * weight;
    weightSum += weight;
    coverSum += tap.a;
  }

  vec3 color = colorSum / max(weightSum, 1e-4);
  float coverAvg = coverSum * invCount;

  float ground = min(color.r, min(color.g, color.b));
  float alpha = max(coverAvg, 1. - ground);
  vec3 premult = max(color - (1. - alpha), 0.);
  fragColor = vec4(premult, alpha) * bulgeFade;

  if (u_grainOverlay > 0.) {
    float grain = valueNoise(rotate(grainUV, 1.) + vec2(3.));
    grain = mix(grain, valueNoise(rotate(grainUV, 2.) + vec2(-1.)), .5);
    grain = pow(grain, 1.3);
    float grainV = grain * 2. - 1.;
    float grainStrength = pow(u_grainOverlay * abs(grainV), .8) * fragColor.a;
    fragColor.rgb = mix(fragColor.rgb, vec3(step(0., grainV)) * fragColor.a, .35 * grainStrength);
  }
}
`,Gn=`#version 300 es
precision mediump float;

uniform float u_rotation;

uniform float u_time;

uniform vec4 u_colorFront;
uniform vec4 u_colorBack;
uniform float u_radius;
uniform float u_contrast;

uniform sampler2D u_image;
uniform float u_imageAspectRatio;

uniform float u_size;
uniform float u_grainMixer;
uniform float u_grainOverlay;
uniform float u_grainSize;
uniform float u_grid;
uniform bool u_originalColors;
uniform bool u_inverted;
uniform float u_type;

in vec2 v_imageUV;

out vec4 fragColor;

${Tn}
${En}
${On}

float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  float x1 = mix(a, b, u.x);
  float x2 = mix(c, d, u.x);
  return mix(x1, x2, u.y);
}

float lst(float edge0, float edge1, float x) {
  return clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
}

float sst(float edge0, float edge1, float x) {
  return smoothstep(edge0, edge1, x);
}

float getCircle(vec2 uv, float r, float baseR) {
  r = mix(.25 * baseR, 0., r);
  float d = length(uv - .5);
  float aa = fwidth(d);
  return 1. - smoothstep(r - aa, r + aa, d);
}

float getCell(vec2 uv) {
  float insideX = step(0.0, uv.x) * (1.0 - step(1.0, uv.x));
  float insideY = step(0.0, uv.y) * (1.0 - step(1.0, uv.y));
  return insideX * insideY;
}

float getCircleWithHole(vec2 uv, float r, float baseR) {
  float cell = getCell(uv);

  r = mix(.75 * baseR, 0., r);
  float rMod = mod(r, .5);

  float d = length(uv - .5);
  float aa = fwidth(d);
  float circle = 1. - smoothstep(rMod - aa, rMod + aa, d);
  if (r < .5) {
    return circle;
  } else {
    return cell - circle;
  }
}

float getGooeyBall(vec2 uv, float r, float baseR) {
  float d = length(uv - .5);
  float sizeRadius = .3;
  if (u_grid == 1.) {
    sizeRadius = .42;
  }
  sizeRadius = mix(sizeRadius * baseR, 0., r);
  d = 1. - sst(0., sizeRadius, d);

  d = pow(d, 2. + baseR);
  return d;
}

float getSoftBall(vec2 uv, float r, float baseR) {
  float d = length(uv - .5);
  float sizeRadius = clamp(baseR, 0., 1.);
  sizeRadius = mix(.5 * sizeRadius, 0., r);
  d = 1. - lst(0., sizeRadius, d);
  float powRadius = 1. - lst(0., 2., baseR);
  d = pow(d, 4. + 3. * powRadius);
  return d;
}

float getUvFrame(vec2 uv, vec2 pad) {
  float aa = 0.0001;

  float left   = smoothstep(-pad.x, -pad.x + aa, uv.x);
  float right  = smoothstep(1.0 + pad.x, 1.0 + pad.x - aa, uv.x);
  float bottom = smoothstep(-pad.y, -pad.y + aa, uv.y);
  float top    = smoothstep(1.0 + pad.y, 1.0 + pad.y - aa, uv.y);

  return left * right * bottom * top;
}

float sigmoid(float x, float k) {
  return 1.0 / (1.0 + exp(-k * (x - 0.5)));
}

float getLumAtPx(vec2 uv, float contrast) {
  vec4 tex = texture(u_image, uv);
  vec3 color = vec3(
  sigmoid(tex.r, contrast),
  sigmoid(tex.g, contrast),
  sigmoid(tex.b, contrast)
  );
  float lum = dot(vec3(0.2126, 0.7152, 0.0722), color);
  lum = mix(1., lum, tex.a);
  lum = u_inverted ? (1. - lum) : lum;
  return lum;
}

float getLumBall(vec2 p, vec2 pad, vec2 inCellOffset, float contrast, float baseR, float stepSize, out vec4 ballColor) {
  p += inCellOffset;
  vec2 uv_i = floor(p);
  vec2 uv_f = fract(p);
  vec2 samplingUV = (uv_i + .5 - inCellOffset) * pad + vec2(.5);
  float outOfFrame = getUvFrame(samplingUV, pad * stepSize);

  float lum = getLumAtPx(samplingUV, contrast);
  ballColor = texture(u_image, samplingUV);
  ballColor.rgb *= ballColor.a;
  ballColor *= outOfFrame;

  float ball = 0.;
  if (u_type == 0.) {
    // classic
    ball = getCircle(uv_f, lum, baseR);
  } else if (u_type == 1.) {
    // gooey
    ball = getGooeyBall(uv_f, lum, baseR);
  } else if (u_type == 2.) {
    // holes
    ball = getCircleWithHole(uv_f, lum, baseR);
  } else if (u_type == 3.) {
    // soft
    ball = getSoftBall(uv_f, lum, baseR);
  }

  return ball * outOfFrame;
}


void main() {

  float stepMultiplier = 1.;
  if (u_type == 0.) {
    // classic
    stepMultiplier = 2.;
  } else if (u_type == 1. || u_type == 3.) {
    // gooey & soft
    stepMultiplier = 6.;
  }

  float cellsPerSide = mix(300., 7., pow(u_size, .7));
  cellsPerSide /= stepMultiplier;
  float cellSizeY = 1. / cellsPerSide;
  vec2 pad = cellSizeY * vec2(1. / u_imageAspectRatio, 1.);
  if (u_type == 1. && u_grid == 1.) {
    // gooey diagonal grid works differently
    pad *= .7;
  }

  vec2 uv = v_imageUV;
  uv -= vec2(.5);
  uv /= pad;

  float contrast = mix(0., 15., pow(u_contrast, 1.5));
  float baseRadius = u_radius;
  if (u_originalColors == true) {
    contrast = mix(.1, 4., pow(u_contrast, 2.));
    baseRadius = 2. * pow(.5 * u_radius, .3);
  }

  float totalShape = 0.;
  vec3 totalColor = vec3(0.);
  float totalOpacity = 0.;

  vec4 ballColor;
  float shape;
  float stepSize = 1. / stepMultiplier;
  for (float x = -0.5; x < 0.5; x += stepSize) {
    for (float y = -0.5; y < 0.5; y += stepSize) {
      vec2 offset = vec2(x, y);

      if (u_grid == 1.) {
        float rowIndex = floor((y + .5) / stepSize);
        float colIndex = floor((x + .5) / stepSize);
        if (stepSize == 1.) {
          rowIndex = floor(uv.y + y + 1.);
          if (u_type == 1.) {
            colIndex = floor(uv.x + x + 1.);
          }
        }
        if (u_type == 1.) {
          if (mod(rowIndex + colIndex, 2.) == 1.) {
            continue;
          }
        } else {
          if (mod(rowIndex, 2.) == 1.) {
            offset.x += .5 * stepSize;
          }
        }
      }

      shape = getLumBall(uv, pad, offset, contrast, baseRadius, stepSize, ballColor);
      totalColor   += ballColor.rgb * shape;
      totalShape   += shape;
      totalOpacity += shape;
    }
  }

  const float eps = 1e-4;

  totalColor /= max(totalShape, eps);
  totalOpacity /= max(totalShape, eps);

  float finalShape = 0.;
  if (u_type == 0.) {
    finalShape = min(1., totalShape);
  } else if (u_type == 1.) {
    float aa = fwidth(totalShape);
    float th = .5;
    finalShape = smoothstep(th - aa, th + aa, totalShape);
  } else if (u_type == 2.) {
    finalShape = min(1., totalShape);
  } else if (u_type == 3.) {
    finalShape = totalShape;
  }

  vec2 grainSize = mix(2000., 200., u_grainSize) * vec2(1., 1. / u_imageAspectRatio);
  vec2 grainUV = v_imageUV - .5;
  grainUV *= grainSize;
  grainUV += .5;
  float grain = valueNoise(grainUV);
  grain = smoothstep(.55, .7 + .2 * u_grainMixer, grain);
  grain *= u_grainMixer;
  finalShape = mix(finalShape, 0., grain);

  vec3 color = vec3(0.);
  float opacity = 0.;

  if (u_originalColors == true) {
    color = totalColor * finalShape;
    opacity = totalOpacity * finalShape;

    vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
    color = color + bgColor * (1. - opacity);
    opacity = opacity + u_colorBack.a * (1. - opacity);
  } else {
    vec3 fgColor = u_colorFront.rgb * u_colorFront.a;
    float fgOpacity = u_colorFront.a;
    vec3 bgColor = u_colorBack.rgb * u_colorBack.a;
    float bgOpacity = u_colorBack.a;

    color = fgColor * finalShape;
    opacity = fgOpacity * finalShape;
    color += bgColor * (1. - opacity);
    opacity += bgOpacity * (1. - opacity);
  }

  float grainOverlay = valueNoise(rotate(grainUV, 1.) + vec2(3.));
  grainOverlay = mix(grainOverlay, valueNoise(rotate(grainUV, 2.) + vec2(-1.)), .5);
  grainOverlay = pow(grainOverlay, 1.3);

  float grainOverlayV = grainOverlay * 2. - 1.;
  vec3 grainOverlayColor = vec3(step(0., grainOverlayV));
  float grainOverlayStrength = u_grainOverlay * abs(grainOverlayV);
  grainOverlayStrength = pow(grainOverlayStrength, .8);
  color = mix(color, grainOverlayColor, .5 * grainOverlayStrength);

  opacity += .5 * grainOverlayStrength;
  opacity = clamp(opacity, 0., 1.);

  fragColor = vec4(color, opacity);
}
`,Kn={classic:0,gooey:1,holes:2,soft:3},qn={square:0,hex:1};function z(e){if(Array.isArray(e))return e.length===4?e:e.length===3?[...e,1]:$n;if(typeof e!=`string`)return $n;let t,n,r,i=1;if(e.startsWith(`#`))[t,n,r,i]=Jn(e);else if(e.startsWith(`rgb`)){let a=Yn(e);if(a===null)return $n;[t,n,r,i]=a}else if(e.startsWith(`hsl`)){let a=Xn(e);if(a===null)return $n;[t,n,r,i]=Zn(a)}else return console.error(`Unsupported color format`,e),$n;return[Qn(t,0,1),Qn(n,0,1),Qn(r,0,1),Qn(i,0,1)]}function Jn(e){return e=e.replace(/^#/,``),(e.length===3||e.length===4)&&(e=e.split(``).map(e=>e+e).join(``)),e.length===6&&(e+=`ff`),/^[0-9a-f]{8}$/i.test(e)?[parseInt(e.slice(0,2),16)/255,parseInt(e.slice(2,4),16)/255,parseInt(e.slice(4,6),16)/255,parseInt(e.slice(6,8),16)/255]:(console.warn(`Invalid hex color`),$n)}function Yn(e){var t,n,r;let i=e.match(/^rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([0-9.]+))?\s*\)$/i);return i?[parseInt((t=i[1])==null?`0`:t)/255,parseInt((n=i[2])==null?`0`:n)/255,parseInt((r=i[3])==null?`0`:r)/255,i[4]===void 0?1:parseFloat(i[4])]:null}function Xn(e){var t,n,r;let i=e.match(/^hsla?\s*\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*(?:,\s*([0-9.]+))?\s*\)$/i);return i?[parseInt((t=i[1])==null?`0`:t),parseInt((n=i[2])==null?`0`:n),parseInt((r=i[3])==null?`0`:r),i[4]===void 0?1:parseFloat(i[4])]:null}function Zn(e){let[t,n,r,i]=e,a=t/360,o=n/100,s=r/100,c,l,u;if(n===0)c=l=u=s;else{let e=(e,t,n)=>(n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*(2/3-n)*6:e),t=s<.5?s*(1+o):s+o-s*o,n=2*s-t;c=e(n,t,a+1/3),l=e(n,t,a),u=e(n,t,a-1/3)}return[c,l,u,i]}var Qn=(e,t,n)=>Math.min(Math.max(e,t),n),$n=[.5,.5,.5,1];function er(){if(typeof window>`u`)return;let e=new Image;return e.src=tr,e}var tr=`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAADAFBMVEUCAQMBAf7/AgMD/wID//7+/wT+A/4FAmYIAqIKnw7+//4EAisEAUgGBIYIewkFVhEJjAoFAuEFA8GWAv6T/gz+AzER/25z/wu1/w1nAggL/049BQUC/y39BrckAQQp/wr+AZYNOvx9AQkN/pELUvMFaAZTBAgIRgsO/7cJNQT+YgkLwRELIf5O/wlP/v79/q4IGAYLK4+kAQ1tAv4IdMpc/4xNMBF2/lQN2vTFAws9BLf9/3kJJgsMRF3+HwkLxfv9BVL8BHEN/9gMsg7cA/13/vv9OAqWA0sOofP9TAsIe/4FQqoF4Q/aAgsQwnKQAwa5BP0JW21NqgmY/f3Z/wkI7whGjAr7oAkLrGGf/JH8jg4zAj4R0Qr+xQ8VZv1Y/8O6//wfA/5bAT79/lQ1AGn8egkKdom0BgYOsfjtBAVDBoz9/zG0A238P/tsbQ/+A9rIig/HCEtvIgrM/1lwBWgIlmr62Q5qA5FndnEIXa+PthUMrqiRfw6SAodE/0cQm6UOirP5swuMCrEOjvo/dBVSA/79KvCgSBL9M1E/TwjUag/e//2WdPZ2TQ9ZMvfPxRD7aPpmOFqXSPu3pww5B/wR00wTgVf3y6dXW137ffv3c7GNj/icJG+4xvYQ61++CZOVll8p//uXzgyTKg6m/1L47w3cAY8EI1T7xvgKbkr7UsGBJPNsB7xL2wuvd5z3svmDmgipcGT8jez8oP0R6bNYuVpUxRn9LZVkqIijYxK7K/dZBtjH/71ZT/1myfz52fVm2WBfk0vxUFj+Vfv9/9plbfz3yl6VUl+flbNijrpfpfz5TZSGRKAI15X14pSt4vwQKMHOTQlKifz1sKW6A9u2A7R65waprffGcfeY/8iyUsFh3rn4lGERMUHJolveAs+PBdb5iZFuX8S8SH7Ekfe8Lwy0t5cLwsD3s2TzbHXa/478nLtNQ6NtstW15QvaKgr25FJm4vyXwFlPInIPId79dUr77fmr18BGdLHIS/mGx6dKw64L7v6k32XMJrWl8ELA3C70AAAgAElEQVR42gTBCTyUeQMA4P97zIx3ZjDvHGaMYQxjhhm33BGTY8h95sodkaNkXVGhKGdUri+SIxQ6nG36VUhS0rnZ6tsVfR2ibKlta7/d5wH7kMaTxlOVozEoHgU29/ayNC9YlrZdyVT+Lf/dAsDDc/xfzX+MLBa2LK23goK0aXhCxZ8qIAdXYj+c8zviDOtRkhEtRxNajHWLuCtdcfQqV2mgRlpDD6wJpKpBrGON27qa4nNeQOU8ViU0pZ2eCMN5mWO7bfR17Q9ItpsqgZJNJcJSq6cSWiV4q1zIDMmkqzAdpqT8gI5G3qm3YEyliPPG9kiwF7P99ghNn7zLs9EXFvFdLmlOdKBAp2ZyGTcI4JuBPYrWyGCYwgFwOhTmHeYC0zEDSp1iX3W71cqoW332M++OAYJUrEySVX0c5lzmDgLcAQ1yFVVOgQ5l+j1k6TEBidTUek7OF4T2kDYo2eVGwOrglKyGBXYyBrxFv9ptR16B+BJ0IFCsryJve0ZEuzNjLeEcw/0aK/kyku6JW0BiicnCBFptKAQRRNRrtmUV/YOn6GNMHXddsFf1YZCHMnFWgcyp2gnLOWTTBcVQVvM/FTgJAHl0NWHHzL0eqzuRXTDCEO03DoThV3kezhrtpNqKW0Bb3MSSAJMmmVnLEpexS8JrmYOr4KXz1cUmByty3N/sbEzBSP8tfGSCJ3caYDhymsPdGbwO4HAl/+PYDCZNf+H6kofkNk4N4Zn6NM4y1lJD7Tt2gyklnrR48dgbfHXgd9uzHvpamm3wKhcaLcawXWxL5T97dL7MeW3aZ7NDWksVZyZv8VQyjm94CDU7UjtbedqOCvB2DdE+wFC6a5JcEIgkKRJ8cfTGmW/2jMS5LEWWKiGY0BFaDNQ++2+sOifPMQ7CcHeFx+PPpcbzRoy4IKmVwHg/1842BwoGc2qlRVoNjCF59oXsrcBgVEP4u1GIX7jshIMqqPdbGTRJzMXcyyyiNG5fr5qFrUVntrktt4QdJugkr1kzNJCK1roWpTraix9JVMpZcsxGYsJlGiSyEgOFZzHy6YVlilnicmxUVkdX/PetzMBk92PNJNkIaLhmA30XPCrMuncWxOZK9kpLnqpYOOsLFFmaf2Mk8OH+BbwPH7HBX2KGI0Ns80gleH+Y6k0YZcF0sWgpoJA30BBbG59XaKyBHoxFtc2p9sFvyXqo2v2aRKN+1HLPshCibfZESAESYsLXmz3tT4wNMp0Wali+VPN93JIJaQ0AcXGrNMnSS0YASPcaNh32NhO0sWHKPhrNVpCBzyk4EWR/PnmKE+3s2cDO+YF6OddPNx7G4AIrZBPldw6tcss4bqzb6hBy6ccf3YaBSNRBFELueRFp7DXWNMFVAT9J1LNTntEyEI2gJS64oyKMKvSRrbpPQGE0rEEmHyqCl2oQravq51FwJXG0m/pPdRA6Xp3sSLdwGwNytaLg3g3VEE2eFESy/GijQPwmYPjwJT+bH/ax0dNT0NZAFQxyIqKzET00vUDuJ+T25QGCclaGZiJBxsjtz3YMZ0PPsq751h0ldwbZstMgHfnauk/7n1eZxEmYIPf5wPt0KJvg2V9bcYWGgua/Lvn/xG5q98tPLcGzHaac2+Cbs3niyPtGgfYgBT2OHgxvhGxzApoPxPoCOtUNCXX+ojW0ug7DOuyrOOG5GkWhaAzx6ZyGE8qbCPS1oxzPjcWSrG/ICNaNMKsra8bIlQVvmRQ/FY4WiHhnrVz/VfdOiOu6u66gG3NKogJ/0rGdbC+iPN1pbZ4HQAZODS+mC2z9dNBqSzd6mTQWKq+EI3fXgJQdqfqz6jY6Fbs4sWT/QkaLUOBnMhWRmSdrpTy769BcCql1UOmaqtFbDA9d7qEox8Lpa+TPXX+xm40jrB7EBK1lwu6IMud9xh7NBZCbq6PNN/QdTu0BVa2neF+s8b1dGns5tMGxQIP/+fiY60jZNp9n5D9MLm4NLWO2gXVG4xwDXHeHXMFEAITOVUGJRoBUwOV3miiTEPPzLrwDm74zFsW9zkfCASQvPi2RaF9qJ2HHWMJNxCHzDym6tNfXiEe28ZnjmHVGwlSvfgBo4afqcoTh4NNq7QQ1KrPJW+1uHEK1VvTghGa0DAePo8D6D1NCYgEPY239D/RQSUMxWJsAIi5KEp/3/9LH1wSTwl8/mfekwWyIhAwMPErzWxVSL7sFnFT1NqJ+Zb8hX4cqwyucXdUVkaqNeVL7abNtJV++aASn/d+Fw9qlVwplz4SqpVw5CBK7nq483nxbZ8p/8TtFwr8oD5uhq+lxfovd0x4+MHo1Wv14SJzqBo9Un1KCZ8NWfbA7jLeoMjnCcS8bjtKuxii0+0RPZlLS6NdhNKHeN2NSdCswa+K+aGFUTD9MLW9R7mhPT5i88TZvV5rWtuek07W/vBev9eJznPGkM8FrCZ53AB8+Ig7vKms99yRb5fpyoQssijTwz0i22O+HvjsjyGXpqseb4t4j6YW86PfJF2cnjmy8EKVF8sIomGUdVGBquOIDIlHsrgPkJEzw7KovqHB/kS+NPgs9nG9FkG1MJiA0GNwTyj5dRS0uiWTfSLf7jpL0ioLExajL/OJPkUbA6CIdKjpU6XrSY/6mE5Z1IDBoHX7tGx9fFkJZQPrPIW49pj9oUEykkiolzaein8mBh/C/0eAzYoFXHWJxYZWrv/ayPmcWsjfWyDy8ndnmPTldcJ05MaxOoIHWPcND2SOan44Wc1Oxyk59KHbiXwbrxB3qvAEA+Pd3zc3MkDFmxjG3K4ZxjHHfFXKNI691kyRLjmRCUmTQWnQo6XS8JNFBsTkqiRQpijalraTe1VPbpa1394/4PM+naUIl5jb9OQw4tXHsFyAoD/x8vmlYJu23hfowcTnJOXSMUdKum4IqKUd4HJguRiprd/Etw9K/NJ+UKE+T2v39ms2JRGhtNDxShw6kmZEdsr6fwVSzZUCgj/xK8CaD46MMqjtVmEE0DTPS7yo7so402lkAAr5A9TA8YbapYO+4tLHK+uBAqCsdrmkNB/tSNQxgrZRiBjhVSt904TQbBmEDW36UhZEwZN9TbWh1vtrLVYdkQKayJHgjO5aVftyaOhbtIVFjq0gImWcFJbXqPp+aGTaOzHzPptvWbli/tEz5BHs2WdU4y01sOWIdG+CPWbxSDnQ/KbYgddG1ggtPPUFvXeLdNH2EoslAveJl8GUVaLs6WWsoo3G2Q8KnvSkrNV13rJm4fF2jG2NKE3FMgjWPyCyVVZXDxk0WKQyzIcdGvhovfXwvS237WZN3PvX9Dh50V1CMuemc5AkPWBJzzlg8giqz/M3mICBajNsO3PSuByw3zV51gCTybHlfu/R+zXwVekhzN1C0gZCgqc3x8EUR5Mt8LndPRv3AbLnf2ZMLJ2TZBapthY8hSsIET5/vpH1T7/l1IKZl4pTp2eMVFT8J+1JyElnizM32GmBQTaTDJOwuvPCV3QDonD/6xjwgR6SA92MF+v+Xlo/BDyOZJpkM7QFh73uKxzX9hlDol/x5HVESyPM/HNyF6MwCg866UWXm9Jd2xsjrXyEKgjl11K41nEwzFzjyP0V9T87dStAustB/MkOwBaQoOCNG0+6dfSw2YIL2d+aAFbtewoPIATWJC+6il2nDFDx8Vlxg2a22oZG4My48gnrQEcDxOuE71wz51mkfvC3B8gjF04baNRpg6SGoHIAc+zB2Qqqn9yEzCXfpmpdN2kxdkiMQ/W/X7iT/RzkpBGvlGrx2Bs4pl3s8Akl3mRTsubk3x+CQH47r1ZNgECzf7IP0nV8lRUj1XqsW9+wNI0+oAx/lOGVsHcmalqdAqT/Rb+rp3wthEPxjXI6irxhTZc9U20OHSbYAJCX6MKHYW/P8XRlyam7KHfk5VTu8Tmebd889NmQ7hiuPb6bQu8inM/FOXkO7iEWd9hgyBVEErR+8P+Om2lFcXGp8DGe734LHfS2Pk7/pzSwPvdrkd7/NgVo0V8s5ir4NYME0CzGbOVoiygQKh+vexBN5PkUBa1bYInKhFqBi7f3FP9xdy5wmH5ByEL6YmlsN4H+lvQJBG8TSvwBmhcGUafV9uPlIYlkx7S81YuG+rzfC3Eb07PGLSnvKO1ujlkiGMoliWkYJ6XYpHzhP4z5odeImZqKxZT1hFN+arPz5Dw2e00ODXsBCGrf4jB+45ZT7UrN7VBRUYgrUJx0WkxNyMCSxRCIYwgyqxP8Zv9VC+6aiUgB0eIt08YI0fh2ZFRqSilUuRRvmt5jejdoSCjfaRFSca6RXh9kVAjX/OeC8Fbgdo+Ffx9K0zF8p4sLEk27kG2vWNThL82M/h1BScI2Kr8fOKkYdh+WXxAYVPhsD11sx5SDIEyx5CGwE1cQ3osdYdlEP3/AZPwvH8oc1WdqXU/OM6fdPELtY9JRSNHEepmC3ZWgsLZss2H2qwq00xxA81SAexVdwbL1ektQlJeVMZAGObIMXLK5lkb95dhjMzkc/Lq17iiAPa1uAovfIZZLe/kaNzRCUCr39gjN5YW18DwBEKdQkVriaJc5BKEHi5s3DEMukQIe9bStXDHyciJ0Xv84FSgb6OW6WuhFqtyjdjWTw/jt87MnpqzC9LTP5d6vqhMo3Y4u6dwfNAzL++6ah0G8ahltlcWiZPeGtcG104UJ67f4QMwOqq/jMIFw8leQ9VsbOhuOtjYqx9cXIaiBcng3fueAQPIz7hl+NJ2ltWAECQIyl81LAaRwlbECUyuuxtH/i/nb25kFilIsdm9q0qzIVxbO2/dyBPwsOdwI/A1NIhXctIgDDfKCMOLIhEHXE0TYiDRDEMkzWtQ9aBbO3WRIhTdI8MGpPh+xE3SEvZM3TsaSkSwo8aIp7vcBPSpNIUWc9dx2ihGIUfcCMA6h6H0sgzlYo2LzwzsSBG/vPLUKBRAIDClNo2hylJMPNHUF6/FyCi7vsPpUBU5f1Zryco/9dyqeIEYzdzRL4fhRqyDTW1lv0jlQjuBtfaUaKBPI7Hr/G7RcawKWd8xytCCHq0tGrABFlLf+tFnXvcFRUS9SdsaU+DOI67yy47KiS86yVHnkbvbnhw7R5+QMX6efQ0ueOVdVkKZ5o+0GzRYPc72WXnZ220/EEPvQ2mJs9umccvaJ9JQDlWujkWdH+bCuOl6OBriPwtt/6D57aofIHy0JVbraWRZDo7xiUeThF4JL+APjur4ftrBDOoDbMmJGGRvnl0iv71YPgcPgMSa8PT1ZvFkRgx3zPM6BFff0dTJbRNIHNd92hlQTTuYNVd2W6Pu7Myx+NgVOiFPeih7aHHc/Dn2tVtPIQZTLWhr1BSVJzNpZo72uzoDQW1D6KG7aCPz+193FdMxFtZ/hYE8idJqfsq7jHo6USnTep5tp8D4LWtSPqIJS9+U4cc8Ym8lJ94wuv8uj5DlIsflhtItJUoeNhAnkdEmUMIsLbGt6thjaw5suLGIwXg96aII8ttrigpcKpcdmqmOegLraj5h8AAQj+90zF3YhqscELTAFaWZuUAQMThYiUb/FNHAlDUttdbQAyP0iCmwvBlXj3bwwGkEZxh7Y8fY1TB+UUdVfjDXKAaoLYaWGWCmVzzxQxUQK7wSFq7btNyjcmKx2vXgKNSocDI3W0q3gacABoST1YfO0NC0OZ3VJ2PUAwXIcsOj7fJ6GGGw3hkT0GAMOIASUuHGB1NI2BNAAuhQtFj2vT4FWOBwA8AZQCJQw8v+fPYq97G8tFNng/7Ieg+y8KHAcI5wACkQOUMBG9bgUsiYNGzPHqgpWonRw8Fzw7aDForw4oGUkSvQQ4H18ev2sHhEVc+aMCAykFFh8LmGKQVJKhIlOdALmkAKIDBkf5txoCxwKdUAz0ToWOJaUGAeneA3pOjwFyZwApO7V3akpwjkl8oyOFoQqEjYfUC0cBHVCoAzuMMH42EggBKSJqxhsQWwBEu1doBqQKAktnbzMzwTSck8w4yPZwGjYeKiAjDxSHIz0HE3EjHAUOAk5RLXQHqIsOrysqUAHM8BmGZRVNw6Mi1QOeAQRaLLABABIkQAM0yABTbYCxYAC+HWBJ00xdN0r3YZU7ubbjAi0CrjFHxLMzaNEjFLz+4ScStCg4r358a5kbAtifbaHcTY18qVrMIdEEISdanHgWFdkBnM8/SEkTKfoHaS1aNTmZvNwAflsqqgZLAjBXyAMFyrIpbAVGV6oAKrCcPqAr45KYS/sfi9mObGiSlB0D+wALckOOCGOriDK83ywNfxUfTw5tHzwDGiJaJ4SU9holF5fx3X6qZhsRAQeNjT8E/kvHIKvUY1sAUZAea4Onlj9sE68EoEUB458HLCDmAB8MIw6JSiQAN73SPLEOfGU31KMYEYrTousmiyRtBTQ7ClaT3ANP6uFYKL84ahsIP6ssogAAK2ks+AYESgB6V3UYAypGWgKVqngClwwJ4MMim9fqCAHJWh0U5DQ7OVAdSk8dtdOMDCrNkgSBo/c0qyIuBDEFbkh0SUHxE+47GQEo0sga4YD6zesDkgAXwjKzLArVShiyFFWSYXkS3iSlNQsBUb4kAQKUESNv4bFLCMoBtfxJAAAACsmEpW4PjIM0DDK2ZbpZmBCz6FoZBgXsbtnLKab9EAxgAVmSeUimBgihp8IvMSfWAwTyz2AE0IhEJxVzmmrwNT0PncoCGQXQtXwua50xk3uPDI1DfqKHdklTBVYAioGcInu/CGIX1GcrkE1cTAHQHxBAprY2Ib/AxT4WBxZveQAd5CwBQsaMPgkdmgYbVQpqCW6JAP29BmFQDW+aDAMuXCMvfT9WrGXn00cmaaaXZvgDOV/4nwXQKgfTiEmisC6eemBCMrpfiElpnHRef3auBiVEA0qLWeFLEAUBBa5BCblqmQV/CgAZ1UEFS2EgCvpyuAMpGyc9BVooZsCBADmIoACXkboDAEwGNNmnABevAQcGNhceIVFDux3uWIIEPQAsjr5l1g8ClQpMAwJsOVsOFi0Uvq4cDl8PEVl0AAdaC6mFaVQiDNeeA9ECv47hpTZ7Qk1VRRwbdRax8vFXryTiYolAIwprBlZ0pa+KKl5wBU1lQRMCjFIw0l0YdXYDC6i9MgDUC6kp3+A48fLH86hBDQILLQBhZJ5hWwInm3QIHgYZEWvbV70xWqoFLAPERDLK4HM5/cWVKbX8bAMEE7o/Am2aue5ZF6OcLqqvVu8EC6f8aJbYBZOWXW5xKyBANEqjA6AskyIoAf5MBQGnKBpoPTABR+0/oFUHAU1VAKsOqV5NYgBBHwZZh1rUncwDCp7sSWwDQTYKBQdpCzmIrMgNN5QDEbEvW2QFgmmkKFOns0WDQamWLPHDNVGTniIfRQ5HqfKsg8Uue/ER8pZHd+ebUSOm7KgF63WiTIhrWg6oJYgEMYc0LhWELTvncXdcgScC3S+BnrjLYYsZK1PXQ4GJZugCuQAClGncjGcMCJwGMHx8c7mRwoVCQAMJPQO/MQBbcs68Zz2lDQgs/R85PVvPAzRJwGkC7MYIF/UDBRoHd1GhwYuAEoXDO6sFqIIUr3wOHGmZFK1zH11Bh8iGFWc8HgEoQwXvQRxHJDEUBTF/AplEfWUmWSMJpiEUvAcghlFGEQtETwA/BxQAeDBBt1IYKa4cADo6WpUuAAMg0w4DBroB1hgTiAJ/RN9REX0qcIM3Fb7b2AEEm+mOawIEXgFg1ne8ByE6fvMKVpI3IjdsAQETBiWUmjZGDQhjQTF8FgldAgNRNiACM16kCBXhkWoUp+4SP+hEEghL9k9wZjlmc6scT6cUqAASj5U5aTAbAwOEl3ICCG25JR4ffsEKYfUNKIkoY2UMcAkXDqEhrGQ2b2RrqaXjAx81CAUWeXVrAI4mGDm6bXtoAwYVMi4GSk5PUVtclscH8gIhvXQ9UiUA1unQH3gHBwkwq/5SRAaUD0GYbE0QL2MAiQbzlasuGxcYAwE0vhmvfgAe3CW/9BQfAiZ8Tnxx5COM3BRtf6U+K/tpYA+lJQO+LQPteW4WmCHRYyCQALcpWAIX8w0S5CQPI1seMBmCcEAegczCb/8FJpCzbAWD3H5NorMaMENXbcyM+SqnzMa1KAA9KRESUQB+C5mbhqFe5lVYhRtCGAK/a7AxcRIgu2O0PwDuLixjUViaEgz3FA0zqDci2tBRCSARPgRBM/NkGRlZeCFnHlEiyaQrgIgQyl66REcXNJslVzwimlyANCOKfrhClEyKOdFL7hiibMlFBQQg1jaLPAADCPz3BFXbRsbE1+oiTTkKCl8XnvRMQbUbRUgqR+ICSw/lJnACx3kIAhaIfB8W/BnkAGo4MoPAYEEA7RTnB5Sg3RinVnQRBQYS8wR+CaYzXT07BdYMDs8Gu44ABtULIyJHDl9wejIEAGo6jg0VoCpEOI0/YewzCgIzcEmGYDY8+rhtRfEyZQblSwUeDSI/X7sFhPM8FQbc4nCqKe0BtEIkeVqJcscyajxYOUfpyk2ANDYfAOmZD6zJTRSBDpgL/N5wnUqyClKcYB05MI1UBooALCvUhuAcyf9sJiv8GyJRzX/IQQCyC3ZBSzwcO9sXB4AIlRE2vh0HBpcF5grsAQPnqAA7obcALildiZ92TM224bdMmAwPQINWrPd+RCgHJxgDfwMv0YKRlEBHJnpxkJytDXXpANUtIEdWWmUSBAcJCSPkZZ0GEy8MDKof72cdh+oTQjqaLH0McSmDa3cQnJ6lQ0N/+aitLGabIwgrEzCvmmp/o49p5V0GNlRLPRbu2UehI31oa8rgCQhEB6mYuZpU0KMCA2URBW47L4EFCEEgFz8IC8xlQBN3t0iRJY+oxFKsIMEPAMBxbQZ5ChYjF24zfKVBA5UGcHmAAsQ3Zgwn9mMueQ53L9/rahkcB2PJEpl5AIasYhP/UBsSETYp00xgawArAIQDBEgPegICAY7xP353eEuT/Ty9fCWnKMRFNQQACMlLA661MINMsM2jlS7bJr8GyFo0bmasanYGCDqsgIONKQqkAGeBYAkHowDYzhhEM59lCAFQLOH9SCzwQAl9AQZI8AdUPFsoFXJbAAEoFp1vvyL6CQ8nDsdymYQNX0B+FM0EBi+IBmIX5R0i5ed+S0/eRBB2EQBmGBUDWLTLNyEHJKJOPiJaTmkSDpwQNgYCGQqA1LUHqtAwOYMi/of0CMIHTBipAIYEO2MKkkC1BQPDFD4Ax8nmll9bNkZ7bmwv1wIH6qkQQndEHQYPeXxUrLUnE28cVsctUWoZGjYVKWe9VAI7RFHZnmsoBWVmYD4xTWNtGZ9wFawr+wAASdAIf6sAjAbfucWuRAx4jNliQHDSAII30QYUYqZ4xSGTct2+WT1bCnw+AJcbNXKKSE8ZFR+fPATWLFkeHQcVH4CxT9sDtA1cAFADBk8ZBBaRRpJovyFHBAEoMwPaXYvvOh8bfQxDvxShtHKe4KQeeg/AXhcIJKBkjxwgXgB+PCAtPifdTwusJGdXJibqGQzCPyySkBZJpz9En7iGYiCX83wDeQbt1TdkV6IAAGxhL0wERTmBBzESBRUdFRMctnmVblQLazgBAsJXtHhcHCclXRoeywgpDynhVqyFWAZBYTWCEviIXzaHwMxdN05xDT5FAwDkBC0TbBYFo2ssKCNOTQkodAEG0uYMXix5sMvSBZxfQ3Egc5k+AjwvJQOEN9rFpuYXv4oFPCULWRr5AKprOYWuCATtAAlKBrcGkIICAd6cnwxqtl0lfz/5+hUR6q/mHdbFA68Qz8syO8Gibp8LetHFNF8tRAV0bEYORkJhTRQFxAMdPwUJMicmXlQKBmMsZwKoAMA1DGAAEQEnMhcBtQZgNggLxcHiAoCFFYEMAd91E7K+4vHKXBbOfJrOAG1E1YEkqxGsNwUr0w0pR2MitIQ5BlqXAA1atwMCSgBYnTuUtAxxNg0ApC4fgrhL7D5sQQM+pLcGg2RmHwIZNZPGC/cI+3Dbb8WlBSCJ/uO2txmjCBULLyHgqeRjEBLnACxYAkBvBQE2owNsMXy0kzWqADm6Oh7HbSK2kQ53AIoKAFWwN02IAuhiBIQgP30OBTUCcpQr5T2fJjB+bUd/2g5Go9sMv5CrnFlpfAWsi+mamCLtIz5VFsBrbb4AM42rGna4cyoQ2eMO3z8NN8BeNKCKBQp3jFrOL+zqP9WWCQukQGBjmPsTAChybv4zgnVctaQ+ynQlaFQJtTPSxEAsRLwRAK0pStgs2M0EBQtIBmKomNWHKHU1uDIsAg2kEHvlUc5/AgICJ34VcpskFZHSgGFydLhFCo6nCXFfWXgIGgY6R9CKIkFdswK6euK1SRkYAxdXV1Z+9UWpQQOzIqloZy0FIoAZfxX7FAEasEKHC04pAAbnGP4CkFFkEZniWC3xBD13ADNArAFjkW8nICQKAOvmzBI8y+QwMBUgcrY0WJdtSxl0hFiiptgP3hDTlmpdVwDTCwZ0BDrZS0eTQt5GALQLQQJcPsQNOkguZZwCIMTEeadTAyR+ijoz4Qo4VzZZAAAlkSVs6VUcZJepUq0Svzx14BNIbWLpMC7XFJGvfVpoWr+cAI4twmWi2I9wqgwAaiwDPtB9E7z2SlYSA4hvaKQ1nAZ/MnZ2kRZ5P60FIq16lCYDVwVsKAx1BqPRgzsOZvKTPIoBn9kCKTDuDtMFqtp2nRYWNRw6ZBc0MvZ2DYu0CLhiWBeCK9jSZwBQ2CySAafnVwKo3rdJXGWGUQv5gHlWsQQUAFUmWXi4AQNX/oqvEnkEUKG6tlZ9QkzDT1jLpmR9fWCg4wByAi0AWeNCBgYJ12ItvmMCNwrVZkYzcU5GBs8aT0XcqZ04IN6FTgQuL9dZDbIa1W0ER64dUb07oB0eE80fZ8/do84xBFGBcwGbppkJq530TW9GuGMsjLJLNAWrBU0KAKYedUoDH3QB0iGTAE7OOxuOVL8BIAMPUxKLA7HUBjHBHEQvFD87HYE40ZqAAXEF3+EI/FQAACAASURBVAA5VAcYSqwlTR4TFY8AFHwtHQXQhYMABwj490xjbrxCQRY1FA0MBmQdfy8KK5JQK5jIhiNb0AgjOAP7zB0TqcsihQUwRXSdVE4CD0RhWQx6EEYLhhYAeoE3P05iEwbgIiTEHEUiq1SOJcmGFl7Xv0dlavCgAliw5QDiemOUAuaucf5lhTXGhc5AoiqoZFu0WZDr+oQYAoJy3YAB2FsNETiWuCXLoc1tIQasfWYAMgQUTgYARFslHwpiRDUs1hBRoB0bQ7+s0NKTRd1E/RCeHiCeUK9JN5EAdJfznAEq8htHb5ADuUQCf8tY/UgQKaRCDSYrhAiA7UateS9WPksK2cYTfUrVpCTmA0SUrFBkXh0Am/veTf7P7Lb4DU8aKbKXz0zdwW3XchzRimAwkx59hHaKO2GnMbYaFW0YBYkNxWp1SEXiNNCm5g3DNIMgtw+ShZNpOpYq/Q8AswmkIiOEHX99N+JMMAC+JKYI7yrXvJWhZgcNbtz2wQA+bk7APAHTMxnOjSWcrcbzX+OZWahITJEaSlVq6X0QGs2kD7jsDlU8ixd3KQOKAgHdAVMANmNMOIuMjEusSjd7Aw4HHBUmlmJgCkxWYk4Veq5jVQ9CFDiuddoVjHF4dDYARDwtTkEhkSROFdWSdDsWaCj4BExuaA8OTiCxBNJIORyAAoMOTk1iT5wDLiZJBrs7VV4uAKKQCxESEKAfymPGhzOP0pVhBGA8ol5iCxpyOoZZFCJJRRXFTm8sA7PfEnuAEgFx0kBskwNQZhyzMLaesB4SdgBuQAKmhMetRhYAICQAP7EL9S9J8rk7xDAYgIxMIlDWBG0DAW8BYAdGkayHGwwrAi4b/r5sA0rCezgdXjtnijaFR5eSBAz/aVQ+mggCDxmYem6hDQtN369pqjuUEgAYD0BSUCT2CaA0BkkSSiDM6jOEQDOFjTDiIQAVX1TPI7bMwK6hF1sFT16bBoFTnVAAFcgndTYODzc/52xpHRZyNxDDkQBPhGMNhklGAbYDJLs3NFGGnC8lCpbuAl06ZWbRM0QQJgfnBAVVCyqR6L9SLIHQDAVNGpYiAIc1AJk8AIAA0TfDOzNArLrhf7hEtVMnMAEBCT81VCmAL7wJ+AKFpQS0Xx0tbQDcQgEJZzcdBW4AOQB2yAAFEeGWwhWAatIHABBbsCfCPlQAikYBjxdYEHgjNAUNL8OWdGkAXgMfOQDJ05gDZyTItT4pIibKF7+xXSp4Shfkxy9Vylsra8P4h50uKHAGw0KZJbkH2GZs1xvMPI3ddzg1sNxcsWHdA6IsCN0GeRJtVDCuDUWwaQAlQj0Ad2Ca6wMJA8+cfEoKOwP0EoXGHg6EdQUZaed7cUveOVMeswMfGy++GDwFsSsb6S9ehSIqVZF71JbZh6LBFLIRDiAACUrQGh3yN1sIIYIkUOeTKl1MTeQYCiMBFATQgh+ynTsCSAOav9AxNUF/AClE0gY7BIsUJiVNABBFJRT2FwgAslkF4mtM9lMDI6AGHrsDBEMhcPQBAnwmdg8o7YkIzxJYkJ77A35vQ2M8AOfeGivv6N1CumQj+RUGPQOXLeEAqgIp1Ig6o3nGdRl8PTUJyQFDEAJ/KNdr3gkIBywcNHDoiAfNW0CHClyw+AbbsU+ruOwbBAncmpU0WePmFgtJd4UAHD+zLgBSQQAugirUKWA8ERwyAjfDPLchDh3EdJRQgbHANWS4bDX2QWzJ2mJZh18YFTBxVgJsBe9gFSoE7VZXKLlzBo5G6q7l1hLxmQMMA6MLWH9PJUb3QgGZC4SBAx0BINreFj822QBjNwMgk00EK/kAtPUvcwxhc8cPRQBSsLgAbRwSGiMBLa5gDN0OekNWCnc1aV9sqeReuiznCC+PLMjJAh4xhq9iAwgOI3IvvyBg2TibaC5IlpM0Lkp8BdcGL9/LB3D9u3oJVwBZDSkkPQIITsjVS5NtqzukBoSUItLaLUeGQlRph9bxmRwAOCK8upGsTd/aP9AhFkwjBnErDQYAAT28k+5LG8IaPTLcvCciEHIbDW8PS3F7ZABuCV2xjgQ+9MHk5jktIvwbTCddCpWOGVBD4QIOfa+MURkdX70FKoRNAA08ttApUKfTq7tHm6YZAJYNRtEWHxgn4AKWIzQrKipAgSK8tk9aOQpky24DUkQGZnVQoRUBP0NDRI/UwgIAMfAoEBSLZDEgLRO1Br6SV38EF7rXIx/JAQ8E3EALBQcSgN0AFFDXMM+Lcw4EFpWDb2knRW/mRYYdfAUdfQLwWhkUCJQyms1ksgTMpHhbAHil+gEBS7anHDTwiRpCrmULHlgkaWl2VL1GDsrg1apysgeLQcKytiGpZUOcDMqz7zAAQwIiuAc+MjjuBK+JmoanK95NcXD4JyZd2Nh5dmU8IRLLDQdeCTYLvtBn6g+P6dw9JTYeVpoGi4ogu1N/K1HYkQC/YBpZAtrEZABeIfY1qIPPzFLFqQ4DDANRwxLNOQFjDca2WfiWsYh/pDePNz8H8AwduiJsSFkTWQRoen8WGw4Ahh81nyQBP5AGhR0E26ZwQ6DHcrwHTrJhA8yogTgLH9PiAFsgFGUJZgB2SLsyWzN9ASa5CB0yXwEJCam2WKEPNT54YlMBn+0OZwAdDwgEA9SnqxNDFoEDQT0NGaOFEHRADFm8F23JWUQQGhMCArWvLhNCfHChBBcNC6QNK40boQEAO+lRHA2CUxLhZyStpJ7pkDc/Cj5S9VMYHgC1PkR/KyVZmwEdKqJACDEcjSYbdxq+AKHVJUhxUMLPdHUdbAACCP33H9UAA8AELkYySGs1NZFvoAsnLu86CBTGMDtrpS3xOIHVHOVVSwUjxA3XFS3diDMPLbOzB9k7Wc9QwVJ5rhsB6E8S1AAGLXom2BIGMhblrl1bFXIYjQSmRiUtBVEKRbNsx4GKS0NiJC+HPpi9LQ76mjyf6OVwqBcGUmYEXgMTd2A6HWqzv7eGEQxBjkcBU/NVLCeshKpDLHJlq2tKGXeSSwFCJS0yAwEd0QEQYULiWW5o1uMgCv2UbVQVInoFKCv7FzYEEgB+31t4HjUs6mheCcGtRwxkMsMlBBHf1b0ADh8dZLtXOJM2kDUSjgxbWZmpAjISVgRbC4sCJugEjdR31gAp7hMAnkgTM5YXSQOZPGsHOAKwefkwknwPEBMqfn0NhJUI15ICbM0TWmmseAWuYeBQiaoWCRAA1AKbxAo92wPXEUQw7wDfnSIrnG4CGV3YXaBnPavwW4OXApQBfZxDwQ1iC6MENCEJAOKZqDFUARg48iFDTDLhNwWjqH4WHAE7PALJFQV7EwMBmYl4Mx4WDqsCAVgA3AQC/Ncp2LMA2aotBnxeNApPDKe9EVSiGS9JMEtKwJUIlwMUDac5oIEPRnapEikLMwAhzQUgJ3QiA/CiOgqWe23hYA0ZAglKDSQZOAEOC72KBJoavjfOPF3IWRciaEYtEzhLKwC2bklkNZgpRwI6WBtPAw+npsDsD6wU0TJ18JCbBy4aNIHPCstFAhRbFzkDOiYSlyULWoWJuUmHMaMPQhe5B3kbXkVL5bZfW0cOMzb+WAAAkGLfDwBkZAAVpGI4umrpsOchSIGKAzcBIjSXoBNokAlDLAFxFpsCbPTQTw5xswgtiyR9QVUGBDzWTAaVDqEAbCsATiO9za1IUezkU2NfcW/LHFaJ0Z8ACSpJVAV9AnL57hOjBs+jBFaPVyvne8dqLUfbF8GOEKVCDVsBLgxdJgBoClkAqUMmZS9cZrUUCgko/DTSHhYGPC75Dm1CIhnzGV44TgJ57DncEMTOEBWMAIEzFCASqi8BMQDtz2WwAChwVFEFYF5qEVJU837Uyx7fUGxE1YBGgu1N0nEsGiYBARCJGiv7nw4CCctmfyoGrnruhwzdwJUyHQMCWypq8T6caAAE20uVHZAlymbvOgSEAwDthEIcfAVjEQBvBRkXkhxrAm2ikI8RNt45FNuOoFokRRdegaaQOtexKJK1HiUAJWEDJgZz22IINjqFaReWG/QEzfsCRBPGyDdYRgcCrzIksE9ZRSXiAdKtH2VYAuzuqgMa3rADi5QGUH9vDzLeOQIEWwAJV4ubXVPDh5EkEzIVBjBkdMcxmAdVxQcDjxzkZr7HeTUzAQ3p9AaLaZGNHWb007EKkvOzc+9NfzgpIllL5myLFbQLygM4XgYF1J2Tvk0uFwIOEtlkSmFFA/yLJ80NAoMAXcbeHgxwl1jcouxbixCh2lPHTFx3qtaG2fp20wrwOgAL5yMrCgRJvQQtg38vXwf6doIW284PZBpHpsBJPzedw5AHCAEMS7YabRQzbkW6L7ndADPqNCkhAZiLdAMYfiZIPOYjGAwGD9Y6vGuiItqzLShPPJ6nT1V7ZoqepyOwL/dvFVxifBwAiHaMARYTQUxgAgACKxRvBh4kjk4AAwUq3gAAEeZC8yAMw5i22C0+GDtgBDwBXg98AwkROUA8S8YCBF903leViZjUa90cdTEOBrwDXHw1Bg8SIAD9EsSgIQwFDEcasGfBcl/3AGhtMD6YjLVaO7gLSl0BA32wU8o5AecqKYOtbh4BdQNIjo0geknWgXWS7wGzHxZ0A3NqHQEBcwCtNqlyt+c0AOkASngGAApBSYNSsGARwxoqz0NA/ggLh2AmkXEAlkauySUDu3QbBNpQUzkdYm+uYokbAjUmTZkCjHh5Zg4uAQ1OY2Z3mUl9vCwNoKYnFjSlbmiP4RmPUKK7eZ0DPgnn0ZqDmJDuA98yAQ+aL1PCSm9NBjcyE3BMmwCmEOyvBOilD8z03gZJS04dEK5yxwBKUnLULgA795xy0+1MXWEPe0MSTWdOSllnH4JfHofxViJmgMVAnbIMYSY+wAUMGScQ1g8AYqARnwEBAwBI5pMFeFOj84MHBNMeuweIjvkDExPKh9omslGCSVgAiN7YEB44Qpp2LiBjPdarEADOBIQdaOdMeA1XMJ8TpvwQ2tGMe61kiAcdEAoCrtBNJ2/Rhs5WfILCBiM/lIG64B5EVH5MfuQS8x03Za2ACu7cEw7NMQ8fIgA9EhYzJYmjV4svwhdqDI+guRTTWvBAXB1UdpDG1QI4DIY3NMjq48cHAg/PbAeQEFlY8rE5ClIACwBx5RxSJp0jQxFhGENVSjUQBQw2iMOKTHxkGjWS9SnbArELcrY0rwyMZT8ShykQV+FwUJMuUgaIWSeyRBZdbRACRCCiiSAml2AEGGImDUh7HGwsHG5KaxaGKsADQ18qC6KJsaYtDUsAATMPnDFfNa8EAH09YH2HsN5GykhFWAxNkwAGCSh0Vh/nMSOlhmUY7RVMBADQmDc6QPpXOVQoBbAMOyECuunUyxPgsQ0ETnBwRXQBAD4Z9IYX3tRMpbUBBbEOtydiCAIYue+9ssJjHgR/2AeVIIGbAmlLYUymQyRwZQTXBlCWmgNl48hVM7QSIL0CdJNSu2lFnk8fiZUZPRFODQCEH0ExjxJKSHJHTWlhSvJmIZZqczI+ADBfRQ6D4Q78UtkAAwsBw2I4MWsZlxhDLwD/BwD4WAUGCne4shiGGyeronSUAQXP5UkAOZ+BfwIRRANQS2eyNSEDcP67cPQAAA5dPwTl5Eg5FHSFGiQZF6BZBxttv2GoyEQFB0xSNBUW/EssG1aRABX0L0oXTk9w9P/nm+ZVMmhBQhcIGxhYOHHoHwNzJldxFQB0KHapYgBDkY+WKIQBBS3cJQYOvmYAR0qKAE8GApuhVQDTKawrE0mPBQG0gt28GoU0YHBDwfqHHhjbkDpoSWVWA6kEs0e1jAIvmkyegpM6G1IBXUzELwUOM2kAISwmADRsQ0MwYxeYL/A6RQABzliwKBgSK4MIxgogDTzGA86dDMa+XUMCLkazOuVDGApvbCfg4CQac2iJU8SvkQMoMrD+PQICV+oinEEdBm0iJT4MyAhTZgFYEnkWnG9xn0y74ilvXe25Jbli4UIJQAJDDjXiA4QDDSiVdiMi/rXIbh7VAPAPxA4UU/bFj9kDQwQKkZtHAlmRGwAt1n4c5uKmg4kORgd5WBq/V17bNiFuAu4AXIauVmwyb1tJ3gLMkljMvYJpCGEM79RBkhofAX06o1gaLwLwTDaMDQEFuzw6UlE9ASVc4VhyijlwMBC8q5TXBwY+MsgHe0VJoAJjlgAUvh8zAAcyNgUYl0e7u2JdGR5GbEOPBQRZBIQBZnrZAvJGzYKVQg8nTwskXgRp1hvgBRwEizz0V35fMqtosBADNwJ5EsGJBAriES8rADV+1ohgBwcBL3YBFAiISgIAAaiaHtpdDgh2Oj1Dg8G1gzdxdGkYQwW7CQCTNDW1GGtT5qJptqfhAAM2bhqP/YwZCWvDU8wVZmt9qQ2yMo6+KHLZ/dslAgWy5BanAIcBnb5hcjI7WBZ6AqTuASP9LHZRiHh0WQ1dJzgqMXGNqSWF7duSohXEqt3EAck4ZwUVVX45ChZEIBYeFnpOC5wPIwA/Gt0cIcKsoqTJPZ1UTRMBWA9OMqWcK8/YAIvfnzBhEwXifwgthgYgEecXBAsQZSVfVQ0ER3w4TgE8iE6ZEIwoFTYzUwGwt2El03Wp4Q2IALsOJnVYBGZdKCUBwQAqAFqlQEZJRbtrwqcgXlIIUx2NcEShuvIBbgq0XVCNBAKhUT4JQB/OBgqIf3FzY6V7OyKAOAoBASg2GU9GAA4AfSMKojG0m5gyqAe3MXWTUgDAAgxFtBcbx3gCmAYBRCEIaWdBmXYDgQdPhQMSeVkjt+IFTuC6Ij8N8+cIOhMxFvN0DJU7rf6eCTpJ9QNR1LoQQQMgEY26fApxVC5HOGr9sKU9GORpdSRjAW4rUEs3GgRFo9IJvYmKIxn3EuAwADMMjc+dCqyePSGpQbkhEXoVHwb9SJ5eMR3zbXZ4JW2BqZVw2l7pIXRrAhSAEAVRS84yK4rNO2l2wNVcCFW7FQwbADpohDhH+ALV5AgD4rQpGReMQ9tkmLIzbxPPHStlIdXCbS1hCEj4yktcH8cO9QspuSFFc2sfFMjhw8WBfwH4AL00SwUDOthSQB54xEsG0i0ACE7WuddaHtLJZxcCSUEYrDRF7xRceFE3AC2x0k8HnShj+8mn1AICDQvHh7yrNLLpdSMBOF7XG0MIKTpg3XePZSgxj4EUDQW6ERczAmkHACMqRzp7jwLBHE1J+9rgGE0jMKR9eAC3iUeONakBJAvMALJ5jyVnHDpo4HcqIQQqJDKFNBhoGQpAAb6m34tpMCwA0p2et1pv9wIkr2yOkSgpxQLKc1IqDDsWJgQWiFnICOdG5B2pQ1FQEqBk2k0FSQ8oLkFGe38tCE61lDAABt0AMaACES7m5uDMWkOQJp0/Hg41dp5mhRNyv+xrYjkRExpXAACXB7ToUYIOVBcRGpltVbe8OYgfXFsByY4hGhkpkyoB7hcF6K0uvEqfZ3griUwBA1c/lD66CQFPcuK8UwRxQHrjeyZEa4w1vRQqYTgxzxgQEhpdGRUUHRNnf4vqR4ObYGCWlrtDMwhWI0ZhExohPDYcfbYDowruYrcukRU+j0IGABZOTatOWA6DbwRHWnODFRc4PImVa24k7ATGb0kbQpcSsL4YFbkgARWhBHl6vFpBPRSyVmOdTmIXefPQCLgLUWUpNV+MAwdW3p10p0eu5BxC504BVIXy9c4JWFeJA2BjBxPZAnIBVQAZhQU1ADH4DjnMGeNHLOhzGY0L6yQtbYoXAJyb6u1PF7UZ5yAt4JwGYldYBd0VembYLQBnVTpvhSA/ckID5KwqDCHKBp0YAiR0oOcfXFD5GQY+oUJH5JqHAR8UBB9QqIcTPwQDE/cukJsaOVIbAuUBaxEVKvd3i2+Q8BAfV8nGOwKY/DtMAgkLMOnoHpCTARcGXgIUhPyYDnVrAExDQSJ1gGIMGgtYAytm5mAuUxtoB58TXTtv6wUAa0NdRSmbkMUEc15QPzEmWRQCSiw5cA1VoRQfWtxc+T0F03kr1T9b7QirrbwAXiw9TpIQLwMRz1BPIlLVz2C9KLQez0US9jMGnUkwCDWWKKWkjQlmXDZjQFxL7nsoey5VQwonAARTHV+7T2o2FlIjAghKc4pLVFWlP5YBH+iWBrccMUpWvxfLgF2Uc3GlpxBgKSA1C26DD6lECOuPBZ1vBhzxaoJkOfOGBXEfH4SpqLmcqQgHLqpA2FJvoLGFBTTtEVwPgIAWD5czgF1YKwbKK0omhid9pnsG3sdBFgMCnWEwrAt/AAxsDcl3PWYuBXYZt/VAEHZFRyu9ERMlZA7aGdcCBgAJCPb3D2AtAxKrHCcRQEh3PMxxSgZzhpKkABTYngRSabRPLwAEwOdIZ7q4CXUDSQBW4y0NAs3GAJEzApI+A3ch8L5wJxDHl31utHwtomsfuOkYFHczQFQ9YpEkspI90XQaQREGQDYArfYUTT1n+WnEVRlkMK0YFEehewNFXB9Qf7NnPPRJozTB8ggFWhokACEeqsVTFD4NFOtfQSlGkYutE1BndA5zBjM1zCAsKWfDYBYCKsZanqqU8mgF3ANrEAI/HOsHDjgi8oycUYmlahbDEym+E2RZoJ7CuZQvFIZ+Jo+CNsk+dvgAXSsCovgCRS0tyH+aFYaA2V8ApQLIFAW2ZfgiAlIEuwIO4Ap2I1xnL9wAdig3UgIGf6YE6DbBBHsBdxUYPHjSAHNWkIRV4yToTJo9fHKeIa32X0luKS0KMxP3Ko1eRBJCWkIMxCT0QmGFVau4JCE8fyjMBrtGXRFQD0ey3ylvRggAFQMds0jrARM9SsnGPBPwES6Nxm00yQBywllTABaqCdwPMUoO5Qd85Skqddq+OgvwnB0cAXVO92EWHA4IdbRkNjHKtgz1P9igRVKWJTcjwZrR8wLfBG0HCOFOoHq8bxdTQkAxKg8nE1DGHtA3kQgro0sY9PUYwjnZqgN5FQeHiEMAFRkElNIELGVYpCzs7psuagceOx6VnFMNPy/MDQe9BwEqPVUNBAhc0tpXAFewAxZ+AKsGSriss+52JIsIOj6JVHuNtiQnblFpaV8ED8LHvw4EmBgHL1UP5gNrBQ0SQdz+AxUBqnMDNuBtmgbCMweoGxIq9AbOQIyvOd0DVEUOXzQAcJCuFF52j5Jz5aHRQ5YwMny8QQJcFYgAF1sGkRMQBTDDzDdfK4SKytaorCm44gSOswA1lc1IVWqFuh+6x3LnBSUAE2QIWigFHb3YC1BVDwWdb4eIFzrNRimjqSKpwzltIIWEdI49Mh06XQYKBw41oWjUAHwgEoKXEKItKQEDAAsANWhxAN8K2QR2g1UjAts3mDkh2jA/LHK7BM5OEQ6oBqLLHj0aA3U3MX2Kb1wEBNIHNul/ogAnOGEERQWVVxvZA01dshtiBA9sUJqjJEs0APzrxA5TLhld+ImbOIIBSAJ5CsWQ9nwDE4EAmwYAFsoF28p6D1uFMYMFfgYtE6qkNwAATiwqvE9QADoAAQBqF4wG3QAumBeeN0klpFMCJGmFA9QrBAiYUiAsAFvNnm/HCXOBHKIZXyFlQikDC34xeT4IqQES+kh8NAMYAUEAvgB0HiVoCiMIbI4DGSYNQndiOymW01MRHDwWzs/FkmNBosBbZlMJj0LSAQJUiguvPQAHSxcATgAEbkceKlAmA966PQGGvYaul2NcZG64cOS55stIjxIVAZyuYlwBAVoJLrV6cSQeOwLpDQQb3gMFBUOMOKCAHgTAJd/0fsZGRCZz9eoBhQZ9Lx+BmQgjUNWgNZEbkzIzJz7Kn22XMHV5p49UihqXk6EAeqS6kDqzQcAcjElhAwsAIw4bkjXuBXHmkwJFAT8NLgCQSA9fAmoWAII8yBinKIFM5qNFDVITCBY3q1P2BKNnIPIJoA1wSGtOVkMVL0wuW3qGmRItFEJdIwMNRwI4VlZyFA5ntqYu3bk8FuzvX73m+0e8MiSObrkfXIS3PqwgW30csgKb+sNWNAqkAUAHHBcAHisPF8KyNVwdjib4CQEEqB8BBk3RmxoOcAYqEdnBQnikHk+GCzazSTmuSQXIjV1IPVWWBJEz61wSEA0AQA89r+DVIWexHfEtWzwaxWhXkAxh4jFolqsEVsMROEk9ijfAAR5jTmj6exsBtYRyIiMoZ/4tVhPlPMTKWBfLMQIxUwEAmQxJGCMFSwPjJwj2GUxYFhcWg5u0ntEASB9dCwNnhlcp7wADVo2t9ZEqG8wJWw3bW4IBpoWxDiGWcPxTjgYaN78JGGW0oA4BFsFpqTAKAAQ80REueg8DlcPFnx1jXTAK5NnxwgEb60cNmUb1gDo4IDUGyQgCAW8uBE8AClg+kQEACiJyVT5uW8RBG87AFApFlOwHAicmhoIYJ5YKAQzVZCfCeuuSnEUSeZckEiordDgJUX3LlPazKnfNjiIeqMxVZAZZADTEEkZ8EXGL+gFGwrjaTHyCEb//H6AY7NQKJgsWLAEZPFuLZnZGRnQtp1EuJRVuJTGdca2pHwCthB51+ZgAuXp+lRMyJ2SAgrYB6m0Q+/4YDM6aKGi/fSuVCQVuWtMBKztbqWEoa85PVdo7zihmsFxiXjnaYQAUn5bbKOh6s08RBhjdaU82QD8htgUalV8OGmIHAFTgUJyiMgTgxg8fON4ZAaBIgnxJeaqd1gRvBBMITAdGJWRKWx0lAVHR0j4AdvYAdQNaQJUDRHlHml5cSLMjaYxAqHmbAaTZAZcZ5s6JLJGip7sCXaw2LCRnK1YMO4sFRAgVWgfXMfc+zt038JeI6lkCDQU5yCGeZRBOA9aMG3e0AZ7cmQmKjgeCWvmJnn7yAwY8uoEEL1wLBADizps1VFIzm5UYtBHFT5Qy46UAsQTBZCwPgljNPekNGEwdic0FR1JmP5AAhShTl4MCWwq2By1NKlUqzQQGAidkywDoSgYGtQ8JRdefJLqPjw5YsD85GiBWlRsDZ2GzVDkCvRSyUzIq16YUXEBLd2kGn+rLIwAAAK1JREFUf54DD3C0WwmGPi9OSjpCA0A7fFwUZTm0ktDZLl5VXmbFDDQACl7+QSry5QCM2bfNC+WAFj1LAzLsiwEBaQCW/1EGcMN/tG8OViQtylulBUxRADYm5SEBRAcAARkeMC5iRNgZhOoxnz4oHApa6gD3ASdbmF188wxpDZVKUL4RUhTSSRvrQAZLDcgauImabgJzkXIaALePAXot1j6Bdwe3AXoQAnXMFVuCApGWbjuRvTu7AAAAAElFTkSuQmCC`;function nr(e){let t=I.useRef(void 0),n=I.useCallback(t=>{let n=e.map(e=>{if(e!=null){if(typeof e==`function`){let n=e,r=n(t);return typeof r==`function`?r:()=>{n(null)}}return e.current=t,()=>{e.current=null}}});return()=>{n.forEach(e=>e==null?void 0:e())}},e);return I.useMemo(()=>e.every(e=>e==null)?null:e=>{t.current&&(t.current(),t.current=void 0),e!=null&&(t.current=n(e))},e)}function rr(e){if(e.naturalWidth<1024&&e.naturalHeight<1024){if(e.naturalWidth<1||e.naturalHeight<1)return;let t=e.naturalWidth/e.naturalHeight;e.width=Math.round(t>1?1024*t:1024),e.height=Math.round(t>1?1024:1024/t)}}var ir=[`fragmentShader`,`uniforms`,`webGlContextAttributes`,`speed`,`frame`,`width`,`height`,`minPixelRatio`,`maxPixelCount`,`mipmaps`,`style`];async function ar(e){let t={},n=[],r=e=>{try{return e.startsWith(`/`)||new URL(e),!0}catch(e){return!1}},i=e=>{try{return!e.startsWith(`/`)&&new URL(e,window.location.origin).origin!==window.location.origin}catch(e){return!1}};return Object.entries(e).forEach(([e,a])=>{if(typeof a==`string`){let o=a||`data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==`;if(!r(o)){console.warn(`Uniform "${e}" has invalid URL "${o}". Skipping image loading.`);return}let s=new Promise((n,r)=>{let a=new Image;i(o)&&(a.crossOrigin=`anonymous`),a.onload=()=>{rr(a),t[e]=a,n()},a.onerror=()=>{console.error(`Could not set uniforms. Failed to load image at ${o}`),r()},a.src=o});n.push(s)}else if(a instanceof HTMLImageElement){let r=a.decode().then(()=>{rr(a),t[e]=a});n.push(r)}else t[e]=a}),await Promise.all(n),t}var or=(0,I.forwardRef)(function(e,t){let{fragmentShader:n,uniforms:r,webGlContextAttributes:a,speed:o=0,frame:s=0,width:c,height:l,minPixelRatio:u,maxPixelCount:f,mipmaps:p,style:m}=e,h=d(e,ir),[g,_]=(0,I.useState)(!1),v=(0,I.useRef)(null),y=(0,I.useRef)(null),b=(0,I.useRef)(a);(0,I.useEffect)(()=>((async()=>{let e=await ar(r);v.current&&!y.current&&(y.current=new _n(v.current,n,e,b.current,o,s,u,f,p),_(!0))})(),()=>{var e;(e=y.current)==null||e.dispose(),y.current=null}),[n]),(0,I.useEffect)(()=>{let e=!1;return(async()=>{let t=await ar(r);if(!e){var n;(n=y.current)==null||n.setUniforms(t)}})(),()=>{e=!0}},[r,g]),(0,I.useEffect)(()=>{var e;(e=y.current)==null||e.setSpeed(o)},[o,g]),(0,I.useEffect)(()=>{var e;(e=y.current)==null||e.setMaxPixelCount(f)},[f,g]),(0,I.useEffect)(()=>{var e;(e=y.current)==null||e.setMinPixelRatio(u)},[u,g]),(0,I.useEffect)(()=>{var e;(e=y.current)==null||e.setFrame(s)},[s,g]);let x=nr([v,t]);return(0,L.jsx)(`div`,i({ref:x,style:c!==void 0||l!==void 0?i({width:typeof c==`string`&&isNaN(+c)===!1?+c:c,height:typeof l==`string`&&isNaN(+l)===!1?+l:l},m):m},h))});or.displayName=`ShaderMount`;function sr(e,t){if(Object.keys(e).length!==Object.keys(t).length)return!1;for(let a in e)if(a===`colors`){var n,r,i;let a=Array.isArray(e.colors),o=Array.isArray(t.colors);if(!a||!o){if(Object.is(e.colors,t.colors)===!1)return!1;continue}if(((n=e.colors)==null?void 0:n.length)!==((r=t.colors)==null?void 0:r.length)||!((i=e.colors)!=null&&i.every((e,n)=>{var r;return e===((r=t.colors)==null?void 0:r[n])})))return!1}else if(Object.is(e[a],t[a])===!1)return!1;return!0}var cr=[`speed`,`frame`,`colors`,`distortion`,`swirl`,`grainMixer`,`grainOverlay`,`fit`,`rotation`,`scale`,`originX`,`originY`,`offsetX`,`offsetY`,`worldWidth`,`worldHeight`],B={name:`Default`,params:i(i({},R),{},{speed:1,frame:0,colors:[`#e0eaff`,`#241d9a`,`#f75092`,`#9f50d3`],distortion:.8,swirl:.1,grainMixer:0,grainOverlay:0})};i(i({},R),{},{speed:.6,frame:0,colors:[`#aaa7d7`,`#3c2b8e`],distortion:1,swirl:1,grainMixer:0,grainOverlay:0}),i(i({},R),{},{speed:.1,frame:0,colors:[`#bcecf6`,`#00aaff`,`#00f7ff`,`#ffd447`],distortion:.8,swirl:.35,grainMixer:0,grainOverlay:0}),i(i({},R),{},{speed:1,frame:0,colors:[`#ffffff`,`#000000`],distortion:1,swirl:.2,rotation:90,grainMixer:0,grainOverlay:0});var lr=(0,I.memo)(function(e){let{speed:t=B.params.speed,frame:n=B.params.frame,colors:r=B.params.colors,distortion:a=B.params.distortion,swirl:o=B.params.swirl,grainMixer:s=B.params.grainMixer,grainOverlay:c=B.params.grainOverlay,fit:l=B.params.fit,rotation:u=B.params.rotation,scale:f=B.params.scale,originX:p=B.params.originX,originY:m=B.params.originY,offsetX:h=B.params.offsetX,offsetY:g=B.params.offsetY,worldWidth:_=B.params.worldWidth,worldHeight:v=B.params.worldHeight}=e,y=d(e,cr),b={u_colors:r.map(z),u_colorsCount:r.length,u_distortion:a,u_swirl:o,u_grainMixer:s,u_grainOverlay:c,u_fit:wn[l],u_rotation:u,u_scale:f,u_offsetX:h,u_offsetY:g,u_originX:p,u_originY:m,u_worldWidth:_,u_worldHeight:v};return(0,L.jsx)(or,i(i({},y),{},{speed:t,frame:n,fragmentShader:Fn,uniforms:b}))},sr),ur=[`speed`,`frame`,`colorBack`,`colorFront`,`shape`,`type`,`pxSize`,`size`,`fit`,`scale`,`rotation`,`originX`,`originY`,`offsetX`,`offsetY`,`worldWidth`,`worldHeight`],V={name:`Default`,params:i(i({},Cn),{},{speed:1,frame:0,scale:.6,colorBack:`#000000`,colorFront:`#00b2ff`,shape:`sphere`,type:`4x4`,size:2})};i(i({},Cn),{},{speed:1,frame:0,colorBack:`#730d54`,colorFront:`#00becc`,shape:`wave`,type:`4x4`,size:11,scale:1.2}),i(i({},Cn),{},{speed:1,frame:0,colorBack:`#000000`,colorFront:`#008000`,shape:`dots`,type:`random`,size:9}),i(i({},R),{},{speed:1,frame:0,colorBack:`#603520`,colorFront:`#c67953`,shape:`ripple`,type:`2x2`,size:3}),i(i({},R),{},{speed:1,frame:0,colorBack:`#00000000`,colorFront:`#47a8e1`,shape:`swirl`,type:`8x8`,size:2}),i(i({},R),{},{speed:1,frame:0,colorBack:`#301c2a`,colorFront:`#56ae6c`,shape:`warp`,type:`4x4`,size:2.5});var dr=(0,I.memo)(function(e){let{speed:t=V.params.speed,frame:n=V.params.frame,colorBack:r=V.params.colorBack,colorFront:a=V.params.colorFront,shape:o=V.params.shape,type:s=V.params.type,pxSize:c,size:l=c===void 0?V.params.size:c,fit:u=V.params.fit,scale:f=V.params.scale,rotation:p=V.params.rotation,originX:m=V.params.originX,originY:h=V.params.originY,offsetX:g=V.params.offsetX,offsetY:_=V.params.offsetY,worldWidth:v=V.params.worldWidth,worldHeight:y=V.params.worldHeight}=e,b=d(e,ur),x={u_colorBack:z(r),u_colorFront:z(a),u_shape:Ln[o],u_type:Rn[s],u_pxSize:l,u_fit:wn[u],u_scale:f,u_rotation:p,u_offsetX:g,u_offsetY:_,u_originX:m,u_originY:h,u_worldWidth:v,u_worldHeight:y};return(0,L.jsx)(or,i(i({},b),{},{speed:t,frame:n,fragmentShader:In,uniforms:x}))}),fr=`speed.frame.colorFront.colorBack.image.contrast.roughness.fiber.crumples.folds.drops.seed.fiberScale.fiberSize.crumplesScale.crumpleSize.blur.fade.foldsNumber.foldCount.fit.scale.rotation.originX.originY.offsetX.offsetY.worldWidth.worldHeight`.split(`.`),H={name:`Default`,params:i(i({},R),{},{fit:`cover`,scale:.6,speed:0,frame:0,colorFront:`#9fadbc`,colorBack:`#ffffff`,contrast:.3,roughness:.4,fiber:.3,fiberSize:.2,crumples:.3,crumpleSize:.35,folds:.65,foldCount:5,fade:0,drops:.2,seed:5.8})};i(i({},R),{},{fit:`cover`,speed:0,frame:0,scale:.6,colorFront:`#00eeff`,colorBack:`#ff0a81`,contrast:.85,roughness:0,fiber:.1,fiberSize:.2,crumples:0,crumpleSize:.3,folds:1,foldCount:3,fade:0,drops:.2,seed:2.2}),i(i({},R),{},{fit:`cover`,speed:0,frame:0,scale:.6,colorFront:`#c7b89e`,colorBack:`#999180`,contrast:.4,roughness:0,fiber:.35,fiberSize:.14,crumples:.7,crumpleSize:.1,folds:0,foldCount:1,fade:0,drops:.1,seed:1.6}),i(i({},R),{},{speed:0,frame:0,fit:`cover`,scale:3,colorFront:`#00000000`,colorBack:`#00000000`,contrast:0,roughness:1,fiber:.27,fiberSize:.22,crumples:1,crumpleSize:.5,folds:1,foldCount:15,fade:0,drops:0,seed:6});var pr=(0,I.memo)(function(e){let{speed:t=H.params.speed,frame:n=H.params.frame,colorFront:r=H.params.colorFront,colorBack:a=H.params.colorBack,image:o=``,contrast:s=H.params.contrast,roughness:c=H.params.roughness,fiber:l=H.params.fiber,crumples:u=H.params.crumples,folds:f=H.params.folds,drops:p=H.params.drops,seed:m=H.params.seed,fiberScale:h,fiberSize:g=h===void 0?H.params.fiberSize:.2/h,crumplesScale:_,crumpleSize:v=_===void 0?H.params.crumpleSize:.2/_,blur:y,fade:b=y===void 0?H.params.fade:y,foldsNumber:x,foldCount:S=x===void 0?H.params.foldCount:x,fit:C=H.params.fit,scale:w=H.params.scale,rotation:T=H.params.rotation,originX:E=H.params.originX,originY:D=H.params.originY,offsetX:O=H.params.offsetX,offsetY:k=H.params.offsetY,worldWidth:ee=H.params.worldWidth,worldHeight:te=H.params.worldHeight}=e,ne=d(e,fr),A=typeof window<`u`&&{u_noiseTexture:er()},re=i(i({u_image:o,u_colorFront:z(r),u_colorBack:z(a),u_contrast:s,u_roughness:c,u_fiber:l,u_fiberSize:g,u_crumples:u,u_crumpleSize:v,u_foldCount:S,u_folds:f,u_fade:b,u_drops:p,u_seed:m},A),{},{u_fit:wn[C],u_scale:w,u_rotation:T,u_offsetX:O,u_offsetY:k,u_originX:E,u_originY:D,u_worldWidth:ee,u_worldHeight:te});return(0,L.jsx)(or,i(i({},ne),{},{speed:t,frame:n,fragmentShader:zn,mipmaps:[`u_image`],uniforms:re}))},sr),mr=`speed.frame.colorBack.colorShadow.colorHighlight.image.shadows.angle.distortion.distortionShape.highlights.shape.shift.blur.edges.margin.marginLeft.marginRight.marginTop.marginBottom.grainMixer.grainOverlay.stretch.count.size.fit.scale.rotation.originX.originY.offsetX.offsetY.worldWidth.worldHeight`.split(`.`),U={name:`Default`,params:i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorBack:`#00000000`,colorShadow:`#000000`,colorHighlight:`#ffffff`,shadows:.25,size:.5,angle:0,distortionShape:`prism`,highlights:.1,shape:`lines`,distortion:.5,shift:0,blur:0,edges:.25,stretch:0,margin:0,marginLeft:0,marginRight:0,marginTop:0,marginBottom:0,grainMixer:0,grainOverlay:0})};i(i({},R),{},{fit:`cover`,scale:1.2,speed:0,frame:0,colorBack:`#00000000`,colorShadow:`#000000`,colorHighlight:`#ffffff`,shadows:0,size:.9,angle:0,distortionShape:`contour`,highlights:0,shape:`wave`,distortion:.5,shift:0,blur:.1,edges:.5,stretch:1,margin:0,marginLeft:0,marginRight:0,marginTop:0,marginBottom:0,grainMixer:0,grainOverlay:.05}),i(i({},R),{},{fit:`cover`,scale:4,speed:0,frame:0,colorBack:`#00000000`,colorShadow:`#000000`,colorHighlight:`#ffffff`,shadows:0,size:.7,angle:30,distortionShape:`flat`,highlights:0,shape:`linesIrregular`,distortion:1,shift:0,blur:1,edges:.5,stretch:1,margin:0,marginLeft:0,marginRight:0,marginTop:0,marginBottom:0,grainMixer:.1,grainOverlay:.1}),i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorBack:`#00000000`,colorShadow:`#000000`,colorHighlight:`#ffffff`,shadows:.4,size:.4,angle:0,distortionShape:`cascade`,highlights:0,shape:`lines`,distortion:.75,shift:0,blur:.25,edges:.5,stretch:0,margin:.1,marginLeft:.1,marginRight:.1,marginTop:.1,marginBottom:.1,grainMixer:0,grainOverlay:0});var hr=(0,I.memo)(function(e){let{speed:t=U.params.speed,frame:n=U.params.frame,colorBack:r=U.params.colorBack,colorShadow:a=U.params.colorShadow,colorHighlight:o=U.params.colorHighlight,image:s=``,shadows:c=U.params.shadows,angle:l=U.params.angle,distortion:u=U.params.distortion,distortionShape:f=U.params.distortionShape,highlights:p=U.params.highlights,shape:m=U.params.shape,shift:h=U.params.shift,blur:g=U.params.blur,edges:_=U.params.edges,margin:v,marginLeft:y=v==null?U.params.marginLeft:v,marginRight:b=v==null?U.params.marginRight:v,marginTop:x=v==null?U.params.marginTop:v,marginBottom:S=v==null?U.params.marginBottom:v,grainMixer:C=U.params.grainMixer,grainOverlay:w=U.params.grainOverlay,stretch:T=U.params.stretch,count:E,size:D=E===void 0?U.params.size:(1/(E*1.6))**(1/6)/.7-.5,fit:O=U.params.fit,scale:k=U.params.scale,rotation:ee=U.params.rotation,originX:te=U.params.originX,originY:ne=U.params.originY,offsetX:A=U.params.offsetX,offsetY:re=U.params.offsetY,worldWidth:ie=U.params.worldWidth,worldHeight:j=U.params.worldHeight}=e,ae=d(e,mr),oe={u_image:s,u_colorBack:z(r),u_colorShadow:z(a),u_colorHighlight:z(o),u_shadows:c,u_size:D,u_angle:l,u_distortion:u,u_shift:h,u_blur:g,u_edges:_,u_stretch:T,u_distortionShape:Hn[f],u_highlights:p,u_shape:Vn[m],u_marginLeft:y,u_marginRight:b,u_marginTop:x,u_marginBottom:S,u_grainMixer:C,u_grainOverlay:w,u_fit:wn[O],u_scale:k,u_rotation:ee,u_offsetX:A,u_offsetY:re,u_originX:te,u_originY:ne,u_worldWidth:ie,u_worldHeight:j};return(0,L.jsx)(or,i(i({},ae),{},{speed:t,frame:n,fragmentShader:Bn,mipmaps:[`u_image`],uniforms:oe}))}),gr=[`speed`,`frame`,`colorFront`,`colorBack`,`colorHighlight`,`image`,`type`,`colorSteps`,`originalColors`,`inverted`,`pxSize`,`size`,`fit`,`scale`,`rotation`,`originX`,`originY`,`offsetX`,`offsetY`,`worldWidth`,`worldHeight`],W={name:`Default`,params:i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorFront:`#94ffaf`,colorBack:`#000c38`,colorHighlight:`#eaff94`,type:`8x8`,size:2,colorSteps:2,originalColors:!1,inverted:!1})};i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorFront:`#eeeeee`,colorBack:`#5452ff`,colorHighlight:`#eeeeee`,type:`2x2`,size:3,colorSteps:1,originalColors:!0,inverted:!1}),i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorFront:`#a2997c`,colorBack:`#000000`,colorHighlight:`#ededed`,type:`random`,size:1,colorSteps:1,originalColors:!1,inverted:!1}),i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorFront:`#ffffff`,colorBack:`#000000`,colorHighlight:`#ffffff`,type:`8x8`,size:2,colorSteps:5,originalColors:!0,inverted:!1});var _r=(0,I.memo)(function(e){let{speed:t=W.params.speed,frame:n=W.params.frame,colorFront:r=W.params.colorFront,colorBack:a=W.params.colorBack,colorHighlight:o=W.params.colorHighlight,image:s=``,type:c=W.params.type,colorSteps:l=W.params.colorSteps,originalColors:u=W.params.originalColors,inverted:f=W.params.inverted,pxSize:p,size:m=p===void 0?W.params.size:p,fit:h=W.params.fit,scale:g=W.params.scale,rotation:_=W.params.rotation,originX:v=W.params.originX,originY:y=W.params.originY,offsetX:b=W.params.offsetX,offsetY:x=W.params.offsetY,worldWidth:S=W.params.worldWidth,worldHeight:C=W.params.worldHeight}=e,w=d(e,gr),T={u_image:s,u_colorFront:z(r),u_colorBack:z(a),u_colorHighlight:z(o),u_type:Rn[c],u_pxSize:m,u_colorSteps:l,u_originalColors:u,u_inverted:f,u_fit:wn[h],u_rotation:_,u_scale:g,u_offsetX:b,u_offsetY:x,u_originX:v,u_originY:y,u_worldWidth:S,u_worldHeight:C};return(0,L.jsx)(or,i(i({},w),{},{speed:t,frame:n,fragmentShader:Un,uniforms:T}))},sr),vr=`speed.frame.image.spread.bias.angle.perspective.count.dispersion.dispersionShift.dispersionColor.focusCenter.focusEdges.swirl.noise.noiseFrequency.noiseOffset.lensBulge.lensCircle.grainMixer.grainOverlay.imageX.imageY.fit.scale.rotation.originX.originY.offsetX.offsetY.worldWidth.worldHeight`.split(`.`),G={name:`Default`,params:i(i({},R),{},{scale:1,fit:`contain`,speed:0,frame:0,spread:.6,bias:1,angle:0,perspective:.1,count:35,dispersion:1,dispersionShift:0,dispersionColor:.6,focusCenter:.8,focusEdges:1,swirl:.35,noise:0,noiseFrequency:.25,noiseOffset:0,lensBulge:0,lensCircle:0,grainMixer:0,grainOverlay:0,imageX:0,imageY:0})};i(i({},R),{},{scale:1,fit:`contain`,speed:0,frame:0,spread:.7,bias:1,angle:0,perspective:.75,count:15,dispersion:1,dispersionShift:0,dispersionColor:.7,focusCenter:.9,focusEdges:1,swirl:1,noise:0,noiseFrequency:.25,noiseOffset:0,lensBulge:.95,lensCircle:1,grainMixer:.5,grainOverlay:0,imageX:0,imageY:0}),i(i({},R),{},{fit:`contain`,speed:0,frame:0,spread:.1,bias:0,angle:0,perspective:0,count:2,dispersion:1,dispersionShift:0,dispersionColor:.1,focusCenter:0,focusEdges:0,swirl:0,noise:0,noiseFrequency:.25,noiseOffset:0,lensBulge:0,lensCircle:0,grainMixer:.1,grainOverlay:.3,imageX:0,imageY:0}),i(i({},R),{},{scale:1,fit:`contain`,speed:0,frame:0,spread:.65,bias:-1,angle:0,perspective:.4,count:50,dispersion:0,dispersionShift:0,dispersionColor:.31,focusCenter:0,focusEdges:.6,swirl:0,noise:1,noiseFrequency:.35,noiseOffset:.3,lensBulge:0,lensCircle:0,grainMixer:0,grainOverlay:0,imageX:0,imageY:0});var yr=(0,I.memo)(function(e){let{speed:t=G.params.speed,frame:n=G.params.frame,image:r=``,spread:a=G.params.spread,bias:o=G.params.bias,angle:s=G.params.angle,perspective:c=G.params.perspective,count:l=G.params.count,dispersion:u=G.params.dispersion,dispersionShift:f=G.params.dispersionShift,dispersionColor:p=G.params.dispersionColor,focusCenter:m=G.params.focusCenter,focusEdges:h=G.params.focusEdges,swirl:g=G.params.swirl,noise:_=G.params.noise,noiseFrequency:v=G.params.noiseFrequency,noiseOffset:y=G.params.noiseOffset,lensBulge:b=G.params.lensBulge,lensCircle:x=G.params.lensCircle,grainMixer:S=G.params.grainMixer,grainOverlay:C=G.params.grainOverlay,imageX:w=G.params.imageX,imageY:T=G.params.imageY,fit:E=G.params.fit,scale:D=G.params.scale,rotation:O=G.params.rotation,originX:k=G.params.originX,originY:ee=G.params.originY,offsetX:te=G.params.offsetX,offsetY:ne=G.params.offsetY,worldWidth:A=G.params.worldWidth,worldHeight:re=G.params.worldHeight}=e,ie=d(e,vr),j={u_image:r,u_spread:a,u_bias:o,u_angle:s,u_perspective:c,u_count:l,u_dispersion:u,u_dispersionShift:f,u_dispersionColor:p,u_focusCenter:m,u_focusEdges:h,u_swirl:g,u_noise:_,u_noiseFrequency:v,u_noiseOffset:y,u_lensBulge:b,u_lensCircle:x,u_grainMixer:S,u_grainOverlay:C,u_imageX:w,u_imageY:T,u_fit:wn[E],u_rotation:O,u_scale:D,u_offsetX:te,u_offsetY:ne,u_originX:k,u_originY:ee,u_worldWidth:A,u_worldHeight:re};return(0,L.jsx)(or,i(i({},ie),{},{speed:t,frame:n,fragmentShader:Wn,mipmaps:[`u_image`],uniforms:j}))},sr),br=[`speed`,`frame`,`colorFront`,`colorBack`,`image`,`size`,`radius`,`contrast`,`originalColors`,`inverted`,`grainMixer`,`grainOverlay`,`grainSize`,`grid`,`type`,`fit`,`scale`,`rotation`,`originX`,`originY`,`offsetX`,`offsetY`,`worldWidth`,`worldHeight`],K={name:`Default`,params:i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorBack:`#f2f1e8`,colorFront:`#2b2b2b`,size:.5,radius:1.25,contrast:.4,originalColors:!1,inverted:!1,grainMixer:.2,grainOverlay:.2,grainSize:.5,grid:`hex`,type:`gooey`})};i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorBack:`#000000`,colorFront:`#29ff7b`,size:.5,radius:1.5,contrast:.3,originalColors:!1,inverted:!1,grainMixer:0,grainOverlay:0,grainSize:.5,grid:`square`,type:`soft`}),i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorBack:`#000000`,colorFront:`#b2aeae`,size:.6,radius:2,contrast:.01,originalColors:!0,inverted:!1,grainMixer:0,grainOverlay:0,grainSize:.5,grid:`hex`,type:`classic`}),i(i({},R),{},{fit:`cover`,speed:0,frame:0,colorBack:`#141414`,colorFront:`#ff8000`,size:.8,radius:1,contrast:1,originalColors:!1,inverted:!0,grainMixer:.05,grainOverlay:.3,grainSize:.5,grid:`square`,type:`holes`});var xr=(0,I.memo)(function(e){let{speed:t=K.params.speed,frame:n=K.params.frame,colorFront:r=K.params.colorFront,colorBack:a=K.params.colorBack,image:o=``,size:s=K.params.size,radius:c=K.params.radius,contrast:l=K.params.contrast,originalColors:u=K.params.originalColors,inverted:f=K.params.inverted,grainMixer:p=K.params.grainMixer,grainOverlay:m=K.params.grainOverlay,grainSize:h=K.params.grainSize,grid:g=K.params.grid,type:_=K.params.type,fit:v=K.params.fit,scale:y=K.params.scale,rotation:b=K.params.rotation,originX:x=K.params.originX,originY:S=K.params.originY,offsetX:C=K.params.offsetX,offsetY:w=K.params.offsetY,worldWidth:T=K.params.worldWidth,worldHeight:E=K.params.worldHeight}=e,D=d(e,br),O={u_image:o,u_colorFront:z(r),u_colorBack:z(a),u_size:s,u_radius:c,u_contrast:l,u_originalColors:u,u_inverted:f,u_grainMixer:p,u_grainOverlay:m,u_grainSize:h,u_grid:qn[g],u_type:Kn[_],u_fit:wn[v],u_rotation:b,u_scale:y,u_offsetX:C,u_offsetY:w,u_originX:x,u_originY:S,u_worldWidth:T,u_worldHeight:E};return(0,L.jsx)(or,i(i({},D),{},{speed:t,frame:n,fragmentShader:Gn,uniforms:O}))},sr),Sr=4,Cr=128,wr=(e,t)=>{let n=255,r=0;for(let i of e)n=Math.min(n,i[t]),r=Math.max(r,i[t]);return r-n},Tr=e=>{if(e.colors.length<2)return null;let t={r:wr(e.colors,`r`),g:wr(e.colors,`g`),b:wr(e.colors,`b`)},n=Object.keys(t).reduce((e,n)=>t[n]>t[e]?n:e,`r`),r=[...e.colors].sort((e,t)=>e[n]-t[n]),i=e.weight/2,a=0,o=1;for(let e=0;e<r.length-1&&(a+=r[e].weight,o=e+1,!(a>=i));e+=1);let s=r.slice(0,o),c=r.slice(o);return[{colors:s,weight:s.reduce((e,t)=>e+t.weight,0)},{colors:c,weight:c.reduce((e,t)=>e+t.weight,0)}]},Er=e=>{let t=e.colors.reduce((e,t)=>({r:e.r+t.r*t.weight,g:e.g+t.g*t.weight,b:e.b+t.b*t.weight}),{r:0,g:0,b:0});return{r:Math.round(t.r/e.weight),g:Math.round(t.g/e.weight),b:Math.round(t.b/e.weight),weight:e.weight}},Dr=({r:e,g:t,b:n})=>`#${e.toString(16).padStart(2,`0`)}${t.toString(16).padStart(2,`0`)}${n.toString(16).padStart(2,`0`)}`,Or=(e,t=5)=>{if(t<=0)return[];let n=new Map;for(let t=0;t<e.length;t+=4){if(e[t+3]<Cr)continue;let r=e[t],i=e[t+1],a=e[t+2],o=r>>Sr<<8|i>>Sr<<4|a>>Sr,s=n.get(o);s?(s.r+=r,s.g+=i,s.b+=a,s.weight+=1):n.set(o,{r,g:i,b:a,weight:1})}let r=[...n.values()].map(e=>({r:Math.round(e.r/e.weight),g:Math.round(e.g/e.weight),b:Math.round(e.b/e.weight),weight:e.weight}));if(r.length===0)return[];let i=[{colors:r,weight:r.reduce((e,t)=>e+t.weight,0)}];for(;i.length<Math.min(t,r.length);){let e=-1,t=-1;for(let n=0;n<i.length;n+=1){let r=i[n];if(r.colors.length<2)continue;let a=Math.max(wr(r.colors,`r`),wr(r.colors,`g`),wr(r.colors,`b`))*Math.sqrt(r.weight);a>t&&(t=a,e=n)}if(e<0)break;let n=Tr(i[e]);if(!n)break;i.splice(e,1,...n)}return i.map(Er).sort((e,t)=>t.weight-e.weight).map(Dr)},kr=()=>{var e,t,n,r;if(typeof window>`u`)return null;let i=window.Capacitor;return!i||((e=i.isNativePlatform)==null?void 0:e.call(i))!==!0&&((t=i.getPlatform)==null?void 0:t.call(i))!==`android`||(n=(r=i.Plugins)==null?void 0:r.FoliaNative)==null?null:n},Ar=e=>{if(!e)return new Uint8Array;let t=atob(e),n=new Uint8Array(t.length);for(let e=0;e<t.length;e+=1)n[e]=t.charCodeAt(e);return n},jr=e=>{let t=`image/jpeg`;if(!e)return t;if(Array.isArray(e)){let n=e.find(e=>String((e==null?void 0:e.name)||``).toLowerCase()===`content-type`);return n!=null&&n.value?String(n.value).split(`;`)[0]:t}let n=Object.entries(e).find(([e])=>e.toLowerCase()===`content-type`);return n?String(n[1]).split(`;`)[0]:t},Mr=async e=>{if(!e||!/^https?:/i.test(e))return null;let t=kr();if(!(t!=null&&t.httpRequest))return null;try{let n=await t.httpRequest({url:e,method:`GET`,headers:{},bodyText:``,bodyBase64:``,redirect:`follow`});if(n.status<200||n.status>=300)return null;let r=Ar(n.bodyBase64);if(r.length===0)return null;let i=r.buffer.slice(r.byteOffset,r.byteOffset+r.byteLength),a=new Blob([i],{type:jr(n.headers)}),o=URL.createObjectURL(a);return{url:o,revoke:()=>URL.revokeObjectURL(o)}}catch(e){return console.warn(`[nativeImageFetch] failed to fetch image bytes, falling back to direct load`,e),null}},Nr=(e,{silent:t=!1}={})=>new Promise(n=>{let r=new Image;r.crossOrigin=`Anonymous`,r.onload=()=>{let e=document.createElement(`canvas`),i=e.getContext(`2d`);if(!i)n(null);else{e.width=50,e.height=50;try{i.drawImage(r,0,0,50,50),n(i.getImageData(0,0,50,50).data)}catch(e){t||console.warn(`Failed to read image pixels for color extraction`,e),n(null)}}},r.onerror=e=>{t||console.warn(`Failed to load image for color extraction`,e),n(null)},r.src=e}),Pr=async(e,t={})=>{let{silent:n=!1}=t,r=await Mr(e);if(r)try{return await Nr(r.url,{silent:n})}finally{r.revoke()}return await Nr(e,{silent:n})},Fr=(e,t)=>{let n=[];for(let t=0;t<e.length;t+=8){let r=e[t],i=e[t+1],a=e[t+2];if(e[t+3]<128)continue;let o=Math.max(r,i,a),s=Math.min(r,i,a),c=(o+s)/2;((o===s?0:(o-s)/(255-Math.abs(o+s-255)))>.2&&c>30&&c<220||n.length<100)&&n.push({r,g:i,b:a})}n.sort((e,t)=>{let n=(Math.max(e.r,e.g,e.b)-Math.min(e.r,e.g,e.b))/255;return(Math.max(t.r,t.g,t.b)-Math.min(t.r,t.g,t.b))/255-n});let r=[];for(let e of n){if(r.length>=t)break;(r.every(t=>Math.sqrt((e.r-t.r)**2+(e.g-t.g)**2+(e.b-t.b)**2)>20)||r.length===0)&&r.push(e)}return r.map(e=>`#${e.r.toString(16).padStart(2,`0`)}${e.g.toString(16).padStart(2,`0`)}${e.b.toString(16).padStart(2,`0`)}`)},Ir=async(e,t=5)=>{let n=await Pr(e);return n?Fr(n,t):[]},Lr=async(e,t=5)=>{let n=await Pr(e);return n?Or(n,t):[]},Rr=(e,t,n)=>{let r=e.setUniformValues;n&&typeof r==`function`?r(t):e.setUniforms(t)},zr=Object.freeze({antialias:!1,depth:!1}),Br=e=>(t=>{if(e.current=t,t)return()=>{var n;e.current=null;let r=(n=t.paperShaderMount)==null?void 0:n.canvasElement;if(!r)return;let i=r.getContext(`webgl2`);queueMicrotask(()=>{var e;!i||r.isConnected||i.isContextLost()||(e=i.getExtension(`WEBGL_lose_context`))==null||e.loseContext()})}}),Vr=.35,Hr=(e,t)=>(e==null?void 0:e.rhythmic)===!1?0:!e||e.impact===void 0?t:(Vr+.65*e.impact)*t,Ur=(e=[],t=1)=>({events:e,trackScale:t,lastBeat:null,lastDownbeat:null,cursor:0,lastTime:null,beatImpact:0,downbeatImpact:0,rotationSign:1,firedBeats:0,firedDownbeats:0,lastFiredT:null}),Wr=(e,t)=>{let n=0,r=e.length;for(;n<r;){let i=n+r>>1;e[i].t<=t?n=i+1:r=i}return n},Gr=(e,t,n)=>{let r=new Set(t),a=e.map((e,t)=>t).filter(e=>!n||n.pulse[e]!==0),o=a.length<e.length?a.map(t=>e[t]):e,s=n&&a.length<e.length?i(i({},n),{},{impact:a.map(e=>n.impact[e]),low:a.map(e=>n.low[e]),mid:a.map(e=>n.mid[e]),high:a.map(e=>n.high[e]),rhythmic:a.map(e=>n.rhythmic[e]),pulse:a.map(()=>1)}):n,c=o.map((e,t)=>{let n={t:e,kind:r.has(e)?`downbeat`:`beat`};return s&&(n.impact=s.impact[t],n.tone={low:s.low[t],mid:s.mid[t],high:s.high[t]},n.rhythmic=s.rhythmic[t]!==0),n}),l=new Set(e);if(t.forEach(e=>{l.has(e)||c.push({t:e,kind:`downbeat`})}),c.sort((e,t)=>e.t-t.t),s){let e=null;c.forEach(t=>{e=t.kind===`downbeat`?0:e===null?null:e+1,t.barPos=e})}return c},Kr=(e,t,n)=>{let r=Math.max(0,n)*1e3;if(e.beatImpact*=Math.exp(-r/160*2.3),e.downbeatImpact*=Math.exp(-r/200*2.3),e.beatImpact<1e-4&&(e.beatImpact=0),e.downbeatImpact<1e-4&&(e.downbeatImpact=0),t===null||!Number.isFinite(t))return e.lastTime=null,e;let i=e.lastTime;e.lastTime=t;let a=i===null?NaN:t-i;if(i===null||a<0||a>.3)return e.cursor=Wr(e.events,t),e;for(;e.cursor<e.events.length&&e.events[e.cursor].t<=t;){let n=e.events[e.cursor];e.cursor+=1;let r=Math.max(0,t-n.t)*1e3,i=n.kind===`downbeat`,a=Hr(n,e.trackScale);e.beatImpact=Math.max(e.beatImpact,a*Math.exp(-r/160*2.3)),e.rotationSign=-e.rotationSign,e.lastFiredT=n.t,i?(e.downbeatImpact=Math.max(e.downbeatImpact,a*Math.exp(-r/200*2.3)),e.firedDownbeats+=1,e.lastDownbeat=n):e.lastBeat=n,e.firedBeats+=1}return e},qr=1500,q=(()=>{try{return typeof localStorage<`u`&&localStorage.getItem(`folia.dev.beatFxDebug`)===`1`}catch(e){return!1}})()?{beats:0,downbeats:0,lastT:null,heardT:null,source:`none`,note:null,trackKey:null,eventCount:0,latencyMs:0,beatImpact:0,downbeatImpact:0}:null;q&&typeof window<`u`&&(window.__foliaBeatFx=q);var J=Ur(),Jr=null,Yr=null,Xr=0,Zr=!1,Qr=null,$r={beat:1,downbeat:1},ei=.5,ti=ei,ni=e=>{if(e.length<2)return ei;let t=[];for(let n=1;n<e.length;n+=1)t.push(e[n].t-e[n-1].t);t.sort((e,t)=>e-t);let n=t[t.length>>1];return n>0?n:ei},ri={beats:0,downbeats:0},ii=(e,t)=>{$r.beat=e,$r.downbeat=t},ai=()=>$r,oi={},si=e=>{oi=e},ci=e=>{var t;return(t=oi[e])==null?0:t},li=()=>ri,ui=e=>{let t=fi();Xr=e&&t?Math.max(Xr,performance.now()+qr):0,Jr=e,J.events=[],J.cursor=0,J.lastTime=null,J.lastBeat=null,J.lastDownbeat=null,q&&(q.trackKey=e,q.source=e?`loading`:`none`,q.note=null,q.eventCount=0)},di=(e,t,n,r,i=1)=>{e===Jr&&(J.events=t,J.trackScale=i,ti=ni(t),Xr=0,J.lastTime=null,q&&(q.source=n,q.note=r==null?null:r,q.eventCount=t.length))},fi=()=>Jr!==null&&(J.events.length>0||Xr>0&&performance.now()<Xr),pi=()=>Zr,mi=()=>({key:Jr,time:Qr}),hi=()=>{ui(null),J.beatImpact=0,J.downbeatImpact=0,Te.set(0),Ee.set(0),Yr=null,Zr=!1},gi=()=>J.lastBeat,_i=()=>J.lastDownbeat,vi=()=>J.events,yi=()=>ti,bi=()=>J.trackScale,xi=()=>J.rotationSign,Si=(e,t)=>{let n=performance.now(),r=Yr===null?0:Math.min(.1,(n-Yr)/1e3);Yr=n;let i=null;if(e&&!e.paused&&!e.ended){let n=t,r=(Number(n==null?void 0:n.outputLatency)||0)+(Number(n==null?void 0:n.baseLatency)||0);i=e.currentTime-r,q&&(q.latencyMs=r*1e3)}Zr=i!==null,Qr=i,Kr(J,i,r),ri.beats=J.firedBeats,ri.downbeats=J.firedDownbeats,Te.set(J.beatImpact*$r.beat),Ee.set(J.downbeatImpact*$r.downbeat),q&&(q.beats=J.firedBeats,q.downbeats=J.firedDownbeats,q.lastT=J.lastFiredT,q.heardT=i,q.beatImpact=J.beatImpact,q.downbeatImpact=J.downbeatImpact)},Ci=new Set,wi=null,Ti=e=>{if(e!=null&&e.preview){let e=Ei();if(e&&!e.cue.preview)return}wi=e===null?null:{cue:e,startedAt:performance.now()},Ci.forEach(t=>t(e))},Ei=()=>{if(!wi)return null;let e=performance.now()-wi.startedAt;return e>=wi.cue.seconds*1e3?null:{cue:wi.cue,elapsedMs:e}},Di=(e=performance.now())=>!wi||wi.cue.preview?0:wi.cue.seconds>0?pt((e-wi.startedAt)/(wi.cue.seconds*1e3),wi.cue.crossover):1,Oi=(e,t,n)=>t&&ki(e)===null&&(!e.preview||e.preview===n),ki=e=>e.plain?`a plain fade, not a mix`:e.seconds>=5?null:`${e.seconds.toFixed(2)}s, under the 5s worth drawing`,Ai=e=>(Ci.add(e),()=>{Ci.delete(e)}),ji=921600,Mi=.12,Ni=300,Pi=e=>Math.min(1,Math.max(0,e/255)),Fi=e=>Math.min(2,Math.max(0,e)),Ii=e=>Math.min(1,Math.max(0,e)),Li=(e,t,n)=>e+(t-e)*n,Ri=(e,t,n,r,i)=>(Pi(e)*.22+Pi(t)*.18+Pi(n)*.22+Pi(r)*.28+Pi(i)*.1)**.55,zi=(e,t,n)=>Math.max(n*.84,Ii((e-t)*7)),Bi=(e,t)=>Ii(e*.42+t*.85),Vi=(e,t)=>Math.max(e,t),Hi=(e,t,n)=>e?t:n,Ui=(e,t,n)=>n?Bi(e,t):Ii(e),Wi=(e,t,n,r)=>Fi(r?e*Mi:Li(e,t,n)),Gi=(e,t,n)=>{var r,i,a,o;let s=(r=e[0])==null?t.secondaryColor:r;if(n===`cover-only`){var c,l,u,d,f;let t=(c=e[1])==null?s:c,n=(l=e[2])==null?t:l;return{ditheringBack:n,ditheringFront:s,mesh:[s,t,n,(u=e[3])==null?s:u,(d=e[4])==null?t:d,(f=e[5])==null?n:f]}}let p=(i=e[1])==null?t.primaryColor:i,m=(a=e[2])==null?s:a,h=(o=e[3])==null?p:o;return{ditheringBack:t.backgroundColor,ditheringFront:s,mesh:[s,p,m,h,t.backgroundColor,t.accentColor]}},Ki=I.memo(({theme:e,coverUrl:t,audioPower:n,audioBands:r,staticMode:i,paused:a,tuning:o,blendMs:s=0,blendProgress:c})=>{let l=(0,I.useRef)(null),u=(0,I.useRef)(null),d=(0,I.useMemo)(()=>Br(l),[]),f=(0,I.useMemo)(()=>Br(u),[]),p=(0,I.useRef)(null),m=(0,I.useRef)(null),h=(0,I.useRef)(a),g=(0,I.useRef)(+!a),_=(0,I.useRef)(null),[v,y]=(0,I.useState)([]),b=o==null?ie:o,x=b.displayMode!==`mesh`,S=b.displayMode!==`dithering`;h.current=a;let C=ct();(0,I.useEffect)(()=>{let e=!0;return t?(Lr(t,6).then(t=>{e&&(y(t),C())}),()=>{e=!1}):(y([]),C(),()=>{e=!1})},[t,C]);let w=(0,I.useMemo)(()=>Gi(v,e,b.colorSource),[v,e,b.colorSource]),T=gt([e.backgroundColor,w.ditheringBack,w.ditheringFront,...w.mesh],s,c),[D,O,k]=T,ee=(0,I.useMemo)(()=>({ditheringBack:O,ditheringFront:k,mesh:T.slice(3)}),[T,O,k]);return(0,I.useEffect)(()=>{var e,t;let a=(e=l.current)==null?void 0:e.paperShaderMount,o=(t=u.current)==null?void 0:t.paperShaderMount;if(i){a==null||a.setSpeed(0),o==null||o.setSpeed(0);return}let s=0,c=new WeakMap,d=(e,t,n)=>{let r=c.get(e);r||(r={},c.set(e,r)),r[t]!==n&&(r[t]=n,e.style[t]=n)},f=0,v=0,y=0,x=0,C=0,w=0,T=null,D=(e,t)=>Li(Wi(e,t,x,!0),Wi(e,t,x,!1),g.current),O=e=>{var t,i;s=requestAnimationFrame(O);let a=h.current,o=T===null?0:1-Math.exp((T-e)/Ni);T=e,g.current=Li(g.current,+!a,o);let c=a?0:Pi(n.get()),_=a?0:Pi(r.bass.get()),k=a?0:Ri(r.bass.get(),r.lowMid.get(),r.mid.get(),r.vocal.get(),r.treble.get()),ee=a?0:Pi(Math.max(r.mid.get(),r.vocal.get()));f=Li(f,c,.12),v=Li(v,_,.16),y=Li(y,ee,.13),w=b.enhancedBeatResponse?zi(k,C,w):0,C=k;let te=!a&&fi()&&ci(E.latentPulse)>0?Bi(k,Vi(Te.get(),Ee.get())):Ui(k,w,b.enhancedBeatResponse),ne=Hi(Ei()!==null,x,te);x=Li(x,ne,ne>x?.42:.14);let A=(t=l.current)==null?void 0:t.paperShaderMount,re=(i=u.current)==null?void 0:i.paperShaderMount;if(A){let e=D(b.ditheringSpeed,b.ditheringAudioSpeed);A.setSpeed(e),Rr(A,{u_pxSize:Math.max(.5,b.ditheringSize-v*b.ditheringSize*.34)},e!==0)}if(re){let e=D(b.meshSpeed,b.meshAudioSpeed);re.setSpeed(e),Rr(re,{u_distortion:b.meshDistortion+f*.62,u_swirl:b.meshSwirl+y*.38},e!==0)}p.current&&(d(p.current,`opacity`,S?`${Math.min(1,b.ditheringOpacity+v*.25)}`:`1`),d(p.current,`transform`,`scale(${1.015+v*.025})`)),m.current&&(d(m.current,`filter`,`saturate(${1.04+y*.34}) brightness(${.94+f*.16})`),d(m.current,`transform`,`scale(${1.025+f*.018})`)),h.current&&g.current<.01&&f<.001&&v<.001&&y<.001&&x<.001&&(cancelAnimationFrame(s),s=0)};return _.current=()=>{s||(T=null,s=requestAnimationFrame(O))},s=requestAnimationFrame(O),()=>{_.current=null,cancelAnimationFrame(s)}},[r,n,S,i,b]),(0,I.useEffect)(()=>{var e;a||(e=_.current)==null||e.call(_)},[a]),(0,L.jsxs)(`div`,{className:`absolute inset-0 z-0 overflow-hidden`,style:{backgroundColor:D,pointerEvents:`none`},children:[S&&(0,L.jsx)(`div`,{ref:m,className:`absolute inset-0`,style:{transform:`scale(1.025)`,transformOrigin:`center`},children:(0,L.jsx)(lr,{ref:f,width:`100%`,height:`100%`,colors:ee.mesh,distortion:b.meshDistortion,swirl:b.meshSwirl,grainMixer:0,grainOverlay:.01,speed:i?0:b.meshSpeed,minPixelRatio:1,maxPixelCount:ji,webGlContextAttributes:zr,style:{width:`100%`,height:`100%`}})}),x&&(0,L.jsx)(`div`,{ref:p,className:`absolute inset-0`,style:{mixBlendMode:S?`soft-light`:`normal`,opacity:S?b.ditheringOpacity:1,transform:`scale(1.015)`,transformOrigin:`center`},children:(0,L.jsx)(dr,{ref:d,width:`100%`,height:`100%`,colorBack:ee.ditheringBack,colorFront:ee.ditheringFront,shape:`warp`,type:`4x4`,size:b.ditheringSize,speed:i?0:b.ditheringSpeed,minPixelRatio:1,maxPixelCount:ji,webGlContextAttributes:zr,style:{width:`100%`,height:`100%`}})}),b.overlayEnabled&&b.overlayOpacity>0&&(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{backgroundColor:D,opacity:b.overlayOpacity}})]})}),qi={id:`bg-latent`,titleKey:`options.latentBackgroundSettings`},Ji={id:`bg-latent-dithering`,titleKey:`options.latentDitheringGroup`},Yi={id:`bg-latent-mesh`,titleKey:`options.latentMeshGroup`},Xi=e=>e.toFixed(1),Zi=e=>e.toFixed(2),Qi=({t:e,tuning:t,onTuningChange:n,onSliderPointerDown:r,onSliderCommit:a})=>{let o={onDragStart:r,onDragEnd:a};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(fe,{def:qi,children:[(0,L.jsx)(F,{label:e(`options.latentDisplayMode`),children:(0,L.jsx)(le,{value:t.displayMode,options:[{value:`dithering`,label:e(`options.latentDisplayDithering`)},{value:`mesh`,label:e(`options.latentDisplayMesh`)},{value:`both`,label:e(`options.latentDisplayBoth`)}],onChange:e=>n==null?void 0:n({displayMode:e})})}),(0,L.jsx)(F,{label:e(`options.latentColorSource`),children:(0,L.jsx)(le,{value:t.colorSource,options:[{value:`cover-theme`,label:e(`options.latentColorSourceCoverTheme`)},{value:`cover-only`,label:e(`options.latentColorSourceCoverOnly`)}],onChange:e=>n==null?void 0:n({colorSource:e})})}),(0,L.jsx)(P,{label:e(`options.latentDynamicOnlyInPlayer`),note:e(`options.latentDynamicOnlyInPlayerDesc`),checked:t.dynamicOnlyInPlayer,onChange:e=>n==null?void 0:n({dynamicOnlyInPlayer:e})}),(0,L.jsx)(P,{label:e(`options.latentEnhancedBeatResponse`),note:e(`options.latentEnhancedBeatResponseDesc`),checked:t.enhancedBeatResponse,onChange:e=>n==null?void 0:n({enhancedBeatResponse:e})}),(0,L.jsx)(P,{label:e(`options.nomandBackgroundOverlay`),note:e(`options.nomandBackgroundOverlayDesc`),checked:t.overlayEnabled,onChange:e=>n==null?void 0:n({overlayEnabled:e})}),(0,L.jsx)(Ce,{when:t.overlayEnabled,children:(0,L.jsx)(M,i(i({},o),{},{sub:!0,label:e(`options.nomandBackgroundOverlayOpacity`),value:t.overlayOpacity,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({overlayOpacity:e})}))})]}),(0,L.jsxs)(fe,{def:Ji,children:[(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentBaseSpeed`),value:t.ditheringSpeed,min:0,max:2,step:.1,format:Xi,onChange:e=>n==null?void 0:n({ditheringSpeed:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentAudioSpeed`),value:t.ditheringAudioSpeed,min:0,max:2,step:.1,format:Xi,onChange:e=>n==null?void 0:n({ditheringAudioSpeed:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentDitheringSize`),value:t.ditheringSize,min:.5,max:8,step:.25,format:Zi,onChange:e=>n==null?void 0:n({ditheringSize:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentDitheringOpacity`),value:t.ditheringOpacity,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({ditheringOpacity:e})}))]}),(0,L.jsxs)(fe,{def:Yi,children:[(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentBaseSpeed`),value:t.meshSpeed,min:0,max:2,step:.1,format:Xi,onChange:e=>n==null?void 0:n({meshSpeed:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentAudioSpeed`),value:t.meshAudioSpeed,min:0,max:2,step:.1,format:Xi,onChange:e=>n==null?void 0:n({meshAudioSpeed:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentMeshDistortion`),value:t.meshDistortion,min:0,max:2,step:.05,format:Zi,onChange:e=>n==null?void 0:n({meshDistortion:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.latentMeshSwirl`),value:t.meshSwirl,min:0,max:1,step:.05,format:Zi,onChange:e=>n==null?void 0:n({meshSwirl:e})}))]})]})},$i=t({default:()=>aa}),ea=[`config`,`actions`],ta=[`dithering`,`mesh`,`both`],na={dithering:`options.latentDisplayDithering`,mesh:`options.latentDisplayMesh`,both:`options.latentDisplayBoth`},ra=[`cover-theme`,`cover-only`],ia={"cover-theme":`options.latentColorSourceCoverTheme`,"cover-only":`options.latentColorSourceCoverOnly`},aa=Fe({mode:`latent`,order:35,labelKey:`options.visualizerBackgroundModeLatent`,labelFallback:`Latent`,glyph:(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`path`,{d:`M4.5 7.5h.01M9 7.5h.01M13.5 7.5h.01M18 7.5h.01`,strokeWidth:`2.2`,opacity:`0.55`}),(0,L.jsx)(`path`,{d:`M3 15c3-3.5 6-3.5 9 0s6 3.5 9 0`})]}),command:{title:`Background: Latent`,description:`Switch background to cover-colored audio-reactive shaders`,keywords:[`latent`,`latent background`,`shader background`,`隐现`,`隐现背景`,`音频响应背景`]},beatEffects:[{id:E.latentPulse,nameKey:`options.beatEffect_latentPulse`,descKey:`options.beatEffect_latentPulseDesc`,source:`beats`,retired:!0}],render:({config:e,theme:t,coverUrl:n,audioPower:r,audioBands:i,staticMode:a,paused:o,blendMs:s,blendProgress:c})=>{var l;return(0,L.jsx)(Ki,{theme:t,coverUrl:n,audioPower:r,audioBands:i,staticMode:a,paused:o,tuning:e==null||(l=e.latent)==null?void 0:l.tuning,blendMs:s,blendProgress:c})},renderSettingsPanel:e=>{var t,n,r;let{config:a,actions:o}=e,s=d(e,ea);return(0,L.jsx)(Qi,i(i({},s),{},{tuning:(t=a==null||(n=a.latent)==null?void 0:n.tuning)==null?ie:t,onTuningChange:o==null||(r=o.latent)==null?void 0:r.onTuningChange}))},renderQuickControls:({config:e,actions:t,t:n})=>{var r,i;let a=(r=e==null||(i=e.latent)==null?void 0:i.tuning)==null?ie:r,s=n(na[a.displayMode]),c=n(ia[a.colorSource]);return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(pe,{label:s,title:`${n(`options.latentDisplayMode`)}: ${s}`,onClick:()=>{var e,n;return t==null||(e=t.latent)==null||(n=e.onTuningChange)==null?void 0:n.call(e,{displayMode:ue(ta,a.displayMode)})}}),(0,L.jsx)(pe,{label:c,title:`${n(`options.latentColorSource`)}: ${c}`,onClick:()=>{var e,n;return t==null||(e=t.latent)==null||(n=e.onTuningChange)==null?void 0:n.call(e,{colorSource:ue(ra,a.colorSource)})}}),(0,L.jsx)(he,{active:a.overlayEnabled,label:n(`options.nomandBackgroundOverlay`),onToggle:()=>{var e,n;return t==null||(e=t.latent)==null||(n=e.onTuningChange)==null?void 0:n.call(e,{overlayEnabled:!a.overlayEnabled})},children:(0,L.jsx)(o,{size:14})})]})},resetSettings:e=>{var t,n;return e==null||(t=e.latent)==null||(n=t.onResetTuning)==null?void 0:n.call(t)}});function oa(){return(oa=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}function sa(e,t){if(e==null)return{};var n,r,i={},a=Object.keys(e);for(r=0;r<a.length;r++)t.indexOf(n=a[r])>=0||(i[n]=e[n]);return i}function ca(e){var t=(0,I.useRef)(e),n=(0,I.useRef)(function(e){t.current&&t.current(e)});return t.current=e,n.current}var la=function(e,t,n){return t===void 0&&(t=0),n===void 0&&(n=1),e>n?n:e<t?t:e},ua=function(e){return`touches`in e},da=function(e){return e&&e.ownerDocument.defaultView||self},fa=function(e,t,n){var r=e.getBoundingClientRect(),i=ua(t)?function(e,t){for(var n=0;n<e.length;n++)if(e[n].identifier===t)return e[n];return e[0]}(t.touches,n):t;return{left:la((i.pageX-(r.left+da(e).pageXOffset))/r.width),top:la((i.pageY-(r.top+da(e).pageYOffset))/r.height)}},pa=function(e){!ua(e)&&e.preventDefault()},ma=I.memo(function(e){var t=e.onMove,n=e.onKey,r=e.onEnd,i=sa(e,[`onMove`,`onKey`,`onEnd`]),a=(0,I.useRef)(null),o=ca(t),s=ca(n),c=ca(r),l=(0,I.useRef)(null),u=(0,I.useRef)(!1),d=(0,I.useMemo)(function(){var e=function(e){pa(e),(ua(e)?e.touches.length>0:e.buttons>0)&&a.current?o(fa(a.current,e,l.current)):(n(!1),c())},t=function(){n(!1),c()};function n(n){var r=u.current,i=da(a.current),o=n?i.addEventListener:i.removeEventListener;o(r?`touchmove`:`mousemove`,e),o(r?`touchend`:`mouseup`,t)}return[function(e){var t=e.nativeEvent,r=a.current;if(r&&(pa(t),!function(e,t){return t&&!ua(e)}(t,u.current)&&r)){if(ua(t)){u.current=!0;var i=t.changedTouches||[];i.length&&(l.current=i[0].identifier)}r.focus(),o(fa(r,t,l.current)),n(!0)}},function(e){var t=e.which||e.keyCode;t<37||t>40||(e.preventDefault(),s({left:t===39?.05:t===37?-.05:0,top:t===40?.05:t===38?-.05:0}))},function(e){var t=e.which||e.keyCode;t>=37&&t<=40&&c()},n]},[s,o,c]),f=d[0],p=d[1],m=d[2],h=d[3];return(0,I.useEffect)(function(){return h},[h]),I.createElement(`div`,oa({},i,{onTouchStart:f,onMouseDown:f,className:`react-colorful__interactive`,ref:a,onKeyDown:p,onKeyUp:m,tabIndex:0,role:`slider`}))}),ha=function(e){return e.filter(Boolean).join(` `)},ga=function(e){var t=e.color,n=e.left,r=e.top,i=r===void 0?.5:r,a=ha([`react-colorful__pointer`,e.className]);return I.createElement(`div`,{className:a,style:{top:100*i+`%`,left:100*n+`%`}},I.createElement(`div`,{className:`react-colorful__pointer-fill`,style:{backgroundColor:t}}))},Y=function(e,t,n){return t===void 0&&(t=0),n===void 0&&(n=10**t),Math.round(n*e)/n},_a=function(e){return Ta(va(e))},va=function(e){return e[0]===`#`&&(e=e.substring(1)),e.length<6?{r:parseInt(e[0]+e[0],16),g:parseInt(e[1]+e[1],16),b:parseInt(e[2]+e[2],16),a:e.length===4?Y(parseInt(e[3]+e[3],16)/255,2):1}:{r:parseInt(e.substring(0,2),16),g:parseInt(e.substring(2,4),16),b:parseInt(e.substring(4,6),16),a:e.length===8?Y(parseInt(e.substring(6,8),16)/255,2):1}},ya=function(e){return wa(Sa(e))},ba=function(e){var t=e.s,n=e.v,r=e.a,i=(200-t)*n/100;return{h:Y(e.h),s:Y(i>0&&i<200?t*n/100/(i<=100?i:200-i)*100:0),l:Y(i/2),a:Y(r,2)}},xa=function(e){var t=ba(e);return`hsl(`+t.h+`, `+t.s+`%, `+t.l+`%)`},Sa=function(e){var t=e.h,n=e.s,r=e.v,i=e.a;t=t/360*6,n/=100,r/=100;var a=Math.floor(t),o=r*(1-n),s=r*(1-(t-a)*n),c=r*(1-(1-t+a)*n),l=a%6;return{r:Y(255*[r,s,o,o,c,r][l]),g:Y(255*[c,r,r,s,o,o][l]),b:Y(255*[o,o,c,r,r,s][l]),a:Y(i,2)}},Ca=function(e){var t=e.toString(16);return t.length<2?`0`+t:t},wa=function(e){var t=e.r,n=e.g,r=e.b,i=e.a,a=i<1?Ca(Y(255*i)):``;return`#`+Ca(t)+Ca(n)+Ca(r)+a},Ta=function(e){var t=e.r,n=e.g,r=e.b,i=e.a,a=Math.max(t,n,r),o=a-Math.min(t,n,r),s=o?a===t?(n-r)/o:a===n?2+(r-t)/o:4+(t-n)/o:0;return{h:60*(s<0?s+6:s),s:a?o/a*100:0,v:a/255*100,a:i}},Ea=I.memo(function(e){var t=e.hue,n=e.onChange,r=e.onChangeEnd,i=ha([`react-colorful__hue`,e.className]);return I.createElement(`div`,{className:i},I.createElement(ma,{onMove:function(e){n({h:360*e.left})},onKey:function(e){n({h:la(t+360*e.left,0,360)})},onEnd:r,"aria-label":`Hue`,"aria-valuenow":Y(t),"aria-valuemax":`360`,"aria-valuemin":`0`},I.createElement(ga,{className:`react-colorful__hue-pointer`,left:t/360,color:xa({h:t,s:100,v:100,a:1})})))}),Da=I.memo(function(e){var t=e.hsva,n=e.onChange,r=e.onChangeEnd,i={backgroundColor:xa({h:t.h,s:100,v:100,a:1})};return I.createElement(`div`,{className:`react-colorful__saturation`,style:i},I.createElement(ma,{onMove:function(e){n({s:100*e.left,v:100-100*e.top})},onKey:function(e){n({s:la(t.s+100*e.left,0,100),v:la(t.v-100*e.top,0,100)})},onEnd:r,"aria-label":`Color`,"aria-valuetext":`Saturation `+Y(t.s)+`%, Brightness `+Y(t.v)+`%`},I.createElement(ga,{className:`react-colorful__saturation-pointer`,top:1-t.v/100,left:t.s/100,color:xa(t)})))}),Oa=function(e,t){if(e===t)return!0;for(var n in e)if(e[n]!==t[n])return!1;return!0},ka=function(e,t){return e.toLowerCase()===t.toLowerCase()||Oa(va(e),va(t))};function Aa(e,t,n,r){var i=ca(n),a=ca(r),o=(0,I.useState)(function(){return e.toHsva(t)}),s=o[0],c=o[1],l=(0,I.useRef)({color:t,hsva:s}),u=(0,I.useRef)(!1);return(0,I.useEffect)(function(){if(!e.equal(t,l.current.color)){var n=e.toHsva(t);l.current={hsva:n,color:t},c(n),u.current=!1}},[t,e]),(0,I.useEffect)(function(){var t;Oa(s,l.current.hsva)||e.equal(t=e.fromHsva(s),l.current.color)||(l.current={hsva:s,color:t},i(t),u.current=!0)},[s,e,i]),[s,(0,I.useCallback)(function(e){c(function(t){return Object.assign({},t,e)})},[]),(0,I.useCallback)(function(){u.current&&(u.current=!1,a(l.current.color))},[a])]}var ja=typeof window<`u`?I.useLayoutEffect:I.useEffect,Ma=function(){return typeof __webpack_nonce__<`u`?__webpack_nonce__:void 0},Na=new WeakMap,Pa=function(e){ja(function(){var t=e.current;if(typeof document<`u`&&t){var n=t.getRootNode?t.getRootNode():t.ownerDocument,r=n&&(`head`in n||`host`in n)?n:t.ownerDocument;if(!Na.has(r)){var i=`head`in r?r.head:r,a=(i.ownerDocument||document).createElement(`style`);a.innerHTML=`.react-colorful{position:relative;display:flex;flex-direction:column;width:200px;height:200px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:default}.react-colorful__saturation{position:relative;flex-grow:1;border-color:transparent;border-bottom:12px solid #000;border-radius:8px 8px 0 0;background-image:linear-gradient(0deg,#000,transparent),linear-gradient(90deg,#fff,hsla(0,0%,100%,0))}.react-colorful__alpha-gradient,.react-colorful__pointer-fill{content:"";position:absolute;left:0;top:0;right:0;bottom:0;pointer-events:none;border-radius:inherit}.react-colorful__alpha-gradient,.react-colorful__saturation{box-shadow:inset 0 0 0 1px rgba(0,0,0,.05)}.react-colorful__alpha,.react-colorful__hue{position:relative;height:24px}.react-colorful__hue{background:linear-gradient(90deg,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red)}.react-colorful__last-control{border-radius:0 0 8px 8px}.react-colorful__interactive{position:absolute;left:0;top:0;right:0;bottom:0;border-radius:inherit;outline:none;touch-action:none}.react-colorful__pointer{position:absolute;z-index:1;box-sizing:border-box;width:28px;height:28px;transform:translate(-50%,-50%);background-color:#fff;border:2px solid #fff;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.2)}.react-colorful__interactive:focus .react-colorful__pointer{transform:translate(-50%,-50%) scale(1.1)}.react-colorful__alpha,.react-colorful__alpha-pointer{background-color:#fff;background-image:url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill-opacity=".05"><path d="M8 0h8v8H8zM0 8h8v8H0z"/></svg>')}.react-colorful__saturation-pointer{z-index:3}.react-colorful__hue-pointer{z-index:2}`;var o=Ma();o&&a.setAttribute(`nonce`,o),Na.set(r,a),i.appendChild(a)}}},[])},Fa=function(e){var t=e.className,n=e.colorModel,r=e.color,i=r===void 0?n.defaultColor:r,a=e.onChange,o=e.onChangeEnd,s=sa(e,[`className`,`colorModel`,`color`,`onChange`,`onChangeEnd`]),c=(0,I.useRef)(null);Pa(c);var l=Aa(n,i,a,o),u=l[0],d=l[1],f=l[2],p=ha([`react-colorful`,t]);return I.createElement(`div`,oa({},s,{ref:c,className:p}),I.createElement(Da,{hsva:u,onChange:d,onChangeEnd:f}),I.createElement(Ea,{hue:u.h,onChange:d,onChangeEnd:f,className:`react-colorful__last-control`}))},Ia={defaultColor:`000`,toHsva:_a,fromHsva:function(e){return ya({h:e.h,s:e.s,v:e.v,a:1})},equal:ka},La=function(e){return I.createElement(Fa,oa({},e,{colorModel:Ia}))},Ra={id:`bg-monet-source`,titleKey:`options.monetGroupBackgroundSource`},za={id:`bg-monet-layout`,titleKey:`options.monetGroupLayoutPosition`},Ba={id:`bg-monet-filters`,titleKey:`options.monetGroupFiltersPostProcessing`},Va={id:`bg-monet-tint`,titleKey:`options.monetGroupColorTintWash`},Ha=(e,t,n,r)=>Number.isFinite(e)?Math.min(n,Math.max(t,e)):r,Ua=e=>{let t=e.trim().replace(/^#/,``);return/^[0-9a-fA-F]{6}$/.test(t)?`#${t.toLowerCase()}`:null},Wa=e=>(0,L.jsx)(`span`,{className:`absolute inset-0`,style:{backgroundImage:e===`full-overlay`?`linear-gradient(var(--st-t3), var(--st-t3))`:`linear-gradient(90deg, var(--st-t3) 30%, transparent 62%)`}}),Ga=({t:e,tuning:t=j,onTuningChange:n,monetBackgroundImage:r,onUploadMonetBackgroundImage:a,onClearMonetBackgroundImage:o,isLoadingMonetBackgroundImage:s=!1,onSliderPointerDown:l,onSliderCommit:u})=>{var d,f,p,h,g,_,v,y,b,x,S,C,w;let T=(0,I.useRef)(null),[E,D]=(0,I.useState)(null),O={backgroundSource:(d=t.backgroundSource)==null?j.backgroundSource:d,backgroundLayout:(f=t.backgroundLayout)==null?j.backgroundLayout:f,backgroundBlurPx:Ha((p=t.backgroundBlurPx)==null?j.backgroundBlurPx:p,0,60,j.backgroundBlurPx),backgroundOverlayOpacity:Ha((h=t.backgroundOverlayOpacity)==null?j.backgroundOverlayOpacity:h,0,1,j.backgroundOverlayOpacity),backgroundGrayscale:Ha((g=t.backgroundGrayscale)==null?j.backgroundGrayscale:g,0,1,j.backgroundGrayscale),backgroundSaturation:Ha((_=t.backgroundSaturation)==null?j.backgroundSaturation:_,0,2,j.backgroundSaturation),backgroundWash:Ha((v=t.backgroundWash)==null?j.backgroundWash:v,0,1,j.backgroundWash),backgroundHalfPaneOffsetX:Ha((y=t.backgroundHalfPaneOffsetX)==null?j.backgroundHalfPaneOffsetX:y,-40,40,j.backgroundHalfPaneOffsetX),backgroundWashColorMode:(b=t.backgroundWashColorMode)==null?j.backgroundWashColorMode:b,backgroundWashCustomColor:(x=Ua(t.backgroundWashCustomColor))==null?j.backgroundWashCustomColor:x,backgroundDriftEnabled:(S=t.backgroundDriftEnabled)==null?j.backgroundDriftEnabled:S,backgroundDriftStrength:Ha((C=t.backgroundDriftStrength)==null?j.backgroundDriftStrength:C,0,1,j.backgroundDriftStrength),backgroundStreaksEnabled:(w=t.backgroundStreaksEnabled)==null?j.backgroundStreaksEnabled:w},k={onDragStart:l,onDragEnd:u},ee=async t=>{var r;let i=Array.from((r=t.target.files)==null?[]:r);if(t.target.value=``,D(null),!i.length||!a)return;let o=await a(i);o.ok?(n==null||n({backgroundSource:`uploaded-global`}),D(i[0].name)):D(o.error||e(`options.monetUploadBackground`))};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(fe,{def:Ra,children:[(0,L.jsx)(F,{label:e(`options.monetBackgroundSource`),children:(0,L.jsx)(le,{value:O.backgroundSource,options:[{value:`cover-derived`,label:e(`options.monetBackgroundSourceCover`)},{value:`uploaded-global`,label:e(`options.monetBackgroundSourceUploaded`),disabled:!r&&!s}],onChange:e=>n==null?void 0:n({backgroundSource:e})})}),(0,L.jsxs)(F,{label:e(`options.monetUploadBackground`),hint:E||(r==null?void 0:r.name)||`-`,children:[(0,L.jsx)(me,{icon:m,onClick:()=>{var e;return(e=T.current)==null?void 0:e.click()},disabled:s||!a,children:e(`options.monetUploadBackground`)}),(0,L.jsx)(me,{icon:c,onClick:()=>void(o==null?void 0:o()),disabled:!r||!o,children:e(`options.monetClearBackground`)}),(0,L.jsx)(`input`,{ref:T,type:`file`,accept:`.png,.jpg,.jpeg,.gif,.webp,.svg,image/*`,className:`hidden`,onChange:e=>void ee(e)})]})]}),(0,L.jsxs)(fe,{def:za,children:[(0,L.jsx)(F,{label:e(`options.monetBackgroundLayout`),below:(0,L.jsx)(de,{className:`-mx-4`,columns:4,label:e(`options.monetBackgroundLayout`),value:O.backgroundLayout,options:[{value:`half-pane-gradient`,label:e(`options.monetLayoutHalfPane`)},{value:`full-overlay`,label:e(`options.monetLayoutFullOverlay`)}],picture:Wa,onChange:e=>n==null?void 0:n({backgroundLayout:e})})}),(0,L.jsx)(Ce,{when:O.backgroundLayout===`half-pane-gradient`,children:(0,L.jsx)(M,i(i({},k),{},{sub:!0,label:e(`options.monetHalfPaneOffsetX`),value:O.backgroundHalfPaneOffsetX,min:-40,max:40,step:2,format:e=>`${Math.round(e)}%`,onChange:e=>n==null?void 0:n({backgroundHalfPaneOffsetX:e})}))}),(0,L.jsx)(P,{label:e(`options.monetBackgroundDriftEnabled`),note:e(`options.monetBackgroundDriftEnabledDesc`),checked:O.backgroundDriftEnabled,onChange:e=>n==null?void 0:n({backgroundDriftEnabled:e})}),(0,L.jsx)(Ce,{when:O.backgroundDriftEnabled,children:(0,L.jsx)(M,i(i({},k),{},{sub:!0,label:e(`options.monetBackgroundDriftStrength`),value:O.backgroundDriftStrength,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({backgroundDriftStrength:e})}))})]}),(0,L.jsxs)(fe,{def:Ba,children:[(0,L.jsx)(M,i(i({},k),{},{label:e(`options.monetBackgroundBlur`),value:O.backgroundBlurPx,min:0,max:60,step:2,format:e=>`${Math.round(e)}px`,onChange:e=>n==null?void 0:n({backgroundBlurPx:e})})),(0,L.jsx)(M,i(i({},k),{},{label:e(`options.monetBackgroundSaturation`),value:O.backgroundSaturation,min:0,max:2,step:.05,format:N,onChange:e=>n==null?void 0:n({backgroundSaturation:e})})),(0,L.jsx)(M,i(i({},k),{},{label:e(`options.monetBackgroundGrayscale`),value:O.backgroundGrayscale,min:0,max:1,step:.02,format:N,onChange:e=>n==null?void 0:n({backgroundGrayscale:e})}))]}),(0,L.jsxs)(fe,{def:Va,children:[(0,L.jsx)(M,i(i({},k),{},{label:e(`options.monetBackgroundOverlayOpacity`),value:O.backgroundOverlayOpacity,min:0,max:1,step:.02,format:N,onChange:e=>n==null?void 0:n({backgroundOverlayOpacity:e})})),(0,L.jsx)(M,i(i({},k),{},{label:e(`options.monetBackgroundWash`),value:O.backgroundWash,min:0,max:1,step:.02,format:N,onChange:e=>n==null?void 0:n({backgroundWash:e})})),(0,L.jsx)(P,{label:e(`options.monetBackgroundStreaksEnabled`),note:e(`options.monetBackgroundStreaksEnabledDesc`),checked:O.backgroundStreaksEnabled,onChange:e=>n==null?void 0:n({backgroundStreaksEnabled:e})}),(0,L.jsx)(F,{label:e(`options.monetBackgroundWashColorMode`),children:(0,L.jsx)(le,{value:O.backgroundWashColorMode,options:[{value:`theme`,label:e(`options.monetBackgroundWashTheme`)},{value:`custom`,label:e(`options.monetBackgroundWashCustom`)}],onChange:e=>n==null?void 0:n({backgroundWashColorMode:e})})}),(0,L.jsx)(Ce,{when:O.backgroundWashColorMode===`custom`,children:(0,L.jsxs)(F,{sub:!0,label:e(`options.monetBackgroundWashCustomColor`),below:(0,L.jsx)(La,{color:O.backgroundWashCustomColor,onChange:e=>n==null?void 0:n({backgroundWashCustomColor:e}),style:{width:`100%`,height:180}}),children:[(0,L.jsx)(`span`,{className:`h-4 w-4 rounded-full shadow-[0_0_0_1px_var(--st-line)]`,style:{backgroundColor:O.backgroundWashCustomColor}}),(0,L.jsx)(ge,{children:O.backgroundWashCustomColor.toUpperCase()})]})})]})]})},Ka=new Map,qa=(e,t,n)=>Math.min(n,Math.max(t,e)),Ja=({coverUrl:e,monetBackgroundImage:t,tuning:n})=>{var r,i,a;return n.backgroundSource===`uploaded-global`?(r=(i=t==null?void 0:t.url)==null?e:i)==null?null:r:(a=e==null?t==null?void 0:t.url:e)==null?null:a},Ya=async e=>{let t=new Image;(e.startsWith(`http://`)||e.startsWith(`https://`))&&(t.crossOrigin=`anonymous`),t.decoding=`async`;let n=new Promise((n,r)=>{t.onload=()=>n(),t.onerror=()=>r(Error(`Failed to load image: ${e}`))});t.src=e;try{await t.decode()}catch(e){await n}return t},Xa=({coverUrl:e,monetBackgroundImage:t,theme:n,tuning:r})=>{var i;return JSON.stringify({sourceUrl:Ja({coverUrl:e,monetBackgroundImage:t,tuning:r}),uploadedId:r.backgroundSource===`uploaded-global`?(i=t==null?void 0:t.id)==null?null:i:null,theme:{backgroundColor:n.backgroundColor,primaryColor:n.primaryColor,accentColor:n.accentColor},tuning:{backgroundSource:r.backgroundSource,backgroundBlurPx:r.backgroundBlurPx,backgroundOverlayOpacity:r.backgroundOverlayOpacity,backgroundGrayscale:r.backgroundGrayscale,backgroundSaturation:r.backgroundSaturation,backgroundWash:r.backgroundWash,backgroundWashColorMode:r.backgroundWashColorMode,backgroundWashCustomColor:r.backgroundWashCustomColor,backgroundStreaksEnabled:r.backgroundStreaksEnabled}})},Za=null,Qa=()=>{if(Za!==null)return Za;if(typeof document>`u`)return!1;try{let e=document.createElement(`canvas`);e.width=2,e.height=2;let t=e.getContext(`2d`);return!t||typeof t.filter!=`string`?(Za=!1,!1):(t.fillStyle=`#000000`,t.fillRect(0,0,2,2),t.filter=`blur(1px)`,t.fillStyle=`#ffffff`,t.fillRect(0,0,1,1),Za=t.getImageData(1,1,1,1).data[0]>0,Za)}catch(e){return Za=!1,!1}},$a=null,eo=0,to=null,no=[],ro=()=>{for(;!to&&no.length>0;){let e=no.shift();if(!e.wanted()){e.request.image.close(),e.settle(void 0);continue}let t=eo+=1;to=i(i({},e),{},{id:t});try{ao().postMessage(i(i({},e.request),{},{id:t}),{transfer:[e.request.image]})}catch(t){to=null,e.request.image.close(),e.settle(null)}}},io=e=>{let t=to;to=null,t==null||t.settle(e),ro()},ao=()=>{if($a)return $a;let e=new Worker(new URL(`/assets/monetBackground.worker-CwAIqxDp.js`,``+import.meta.url),{type:`module`});return e.onmessage=e=>{e.data.id===(to==null?void 0:to.id)&&io(`picture`in e.data?e.data.picture:null)},e.onerror=()=>{e.terminate(),$a=null,io(null)},$a=e,e},oo=(e,t)=>new Promise(n=>{no.push({request:e,wanted:t,settle:n}),ro()}),so=async({coverUrl:e,monetBackgroundImage:t,theme:n,tuning:r},i)=>{let a=Ja({coverUrl:e,monetBackgroundImage:t,tuning:r});if(!a)return null;let o=await Mr(a),s;try{var c;s=await createImageBitmap(await Ya((c=o==null?void 0:o.url)==null?a:c))}catch(e){throw o==null||o.revoke(),e}o==null||o.revoke();let l=await oo({image:s,colors:{backgroundColor:n.backgroundColor,primaryColor:n.primaryColor,accentColor:n.accentColor},tuning:r,blurPx:Qa()?qa(r.backgroundBlurPx,0,60):null},i);if(!l)return l;let u=URL.createObjectURL(l),d=new Image;d.src=u;try{await d.decode()}catch(e){throw URL.revokeObjectURL(u),e}return u},co=e=>{let t=Xa(e),n=Ka.get(t);if(!n){let r={url:Promise.resolve(null),holders:0};r.url=so(e,()=>r.holders>0||(Ka.get(t)===r&&Ka.delete(t),!1)).then(e=>e==null?null:e,()=>null),Ka.set(t,r),n=r}let r=n;r.holders+=1;let i=!1;return{url:r.url,release:()=>{i||(i=!0,--r.holders)}}},lo=240,uo=76,fo=156,po=3.4,mo=.035,ho=.01,go=12.9898,_o=78.233,vo=39.425,yo=(e,t)=>(e%t+t)%t,bo=(e,t)=>{let n=Math.sin(e*127.1+t*311.7)*43758.5453;return n-Math.floor(n)},xo=e=>e*e*(3-2*e),So=(e,t,n)=>{let r=Math.floor(e),i=bo(yo(r,t),n);return i+(bo(yo(r+1,t),n)-i)*xo(e-r)},Co=(e,t)=>{let n=So(e,uo,t),r=So(e*2,152,t+17.31);return(n*.68+r*.32)*2-1},wo=e=>{let t=e.reduce((e,t)=>Math.max(e,Math.abs(t)),0);return t>0?e.map(e=>e/t):e},To=e=>{let t=Math.min(1,Math.max(0,e)),n=po*t,r=1+n/100*2+ho,i=mo*t,a=[],o=[],s=[];for(let e=0;e<=fo;e+=1){let t=uo*e/fo;a.push(Co(t,go)),o.push(Co(t,_o)),s.push(Co(t,vo))}let c=wo(a),l=wo(o),u=wo(s);return{keyframes:c.map((e,t)=>({transform:`translate3d(${(e*n).toFixed(4)}%, ${(l[t]*n).toFixed(4)}%, 0) scale(${(r+i*((u[t]+1)/2)).toFixed(5)})`})),durationMs:lo*1e3,maxTravelPercent:n,minScale:r}},Eo=180,Do=(e,t,n)=>Math.min(n,Math.max(t,e)),Oo=(e,t,n,r)=>{(0,I.useEffect)(()=>{let i=e.current;if(!i||!t||n<=0||typeof i.animate!=`function`||r)return;let a=To(n),o=i.animate(a.keyframes,{duration:a.durationMs,iterations:1/0,easing:`linear`});return()=>o.cancel()},[t,e,n,r])},ko=(e,t,n)=>{var r,i,a;return n.backgroundSource===`uploaded-global`?(r=(i=t==null?void 0:t.url)==null?e:i)==null?null:r:(a=e==null?t==null?void 0:t.url:e)==null?null:a},Ao=({coverUrl:e,monetBackgroundImage:t,theme:n,isDaylight:r=!1,tuning:a=j,transparentBackground:o=!1,staticMode:s=!1})=>{var c;let[l,u]=(0,I.useState)(null),[d,f]=(0,I.useState)(!1),p=ko(e,t,a),m=ct(),[h,g]=(0,I.useState)(null),_=(0,I.useRef)(null),v=(0,I.useMemo)(()=>`linear-gradient(135deg, ${k(n.accentColor,.22)}, ${k(n.backgroundColor,.96)} 50%, ${k(n.primaryColor,.18)})`,[n]),y=(0,I.useMemo)(()=>`linear-gradient(90deg, ${k(n.backgroundColor,.18)} 0%, ${k(n.backgroundColor,.32)} 34%, ${k(n.backgroundColor,.66)} 70%, ${k(n.backgroundColor,.82)} 100%)`,[n]),b=(0,I.useMemo)(()=>Xa({coverUrl:e,monetBackgroundImage:t,theme:n,tuning:a}),[e,t,n,a]);(0,I.useEffect)(()=>{let r=!1,i;if(!p||o)return u(null),f(!1),m(),()=>{r=!0};f(!0);let s={coverUrl:e,monetBackgroundImage:t,theme:n,tuning:a},c=p===_.current?null:co(s),l=null;return i=window.setTimeout(()=>{l=co(s),l.url.then(e=>{r||(u(t=>t===e?t:e),f(!1),_.current=p,e&&g(t=>t==null?e:t),m())})},Eo),()=>{r=!0,i!==void 0&&window.clearTimeout(i),c==null||c.release(),l==null||l.release()}},[b,p,o,m]);let C=(0,I.useRef)(null),w=Do((c=a.backgroundDriftStrength)==null?0:c,0,1),T=!!a.backgroundDriftEnabled&&!s&&w>0;Oo(C,T,w,x(`monetBackground`));let E=(0,I.useMemo)(()=>T?{willChange:`transform`}:void 0,[T]),D=(0,I.useMemo)(()=>Qa(),[])?0:a.backgroundBlurPx,O=(0,I.useMemo)(()=>D<=0?{}:{filter:`blur(${D}px)`,WebkitFilter:`blur(${D}px)`,transform:`scale(1.1) translateZ(0)`},[D]);if(o)return null;let ee=l?`url(${l})`:p?`linear-gradient(135deg, ${k(n.accentColor,.2)}, ${k(n.backgroundColor,.78)}), url(${p})`:v,ne=d?{[Ke]:``}:{},A=l||p||`fallback`,re=A!==h&&{opacity:0};if(a.backgroundLayout===`full-overlay`)return(0,L.jsxs)(`div`,i(i({className:`absolute inset-0 z-0 overflow-hidden`},ne),{},{children:[(0,L.jsx)(`div`,{ref:C,className:`absolute inset-0`,style:E,children:(0,L.jsx)(S,{initial:!1,children:(0,L.jsx)(te.div,{initial:re,animate:{opacity:1},exit:{opacity:0},transition:{duration:.8,ease:`easeInOut`},className:`absolute inset-0`,style:i({backgroundColor:n.backgroundColor,backgroundImage:ee,backgroundSize:`cover`,backgroundPosition:`center`},O)},A)})}),(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{background:y}})]}));let ie=(r?.7:.3)+Do(a.backgroundOverlayOpacity,0,1)*.16,ae=Do(50+a.backgroundHalfPaneOffsetX,10,90);return(0,L.jsxs)(`div`,i(i({className:`absolute inset-0 z-0 overflow-hidden`},ne),{},{children:[(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{backgroundColor:n.backgroundColor,backgroundImage:v}}),(0,L.jsx)(S,{initial:!1,children:l||p?(0,L.jsx)(`div`,{className:`absolute inset-y-0 left-0 w-[72%] sm:w-[68%] lg:w-[60%] overflow-hidden`,style:{WebkitMaskImage:`linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(0,0,0,0.94) 48%, rgba(0,0,0,0.46) 74%, rgba(0,0,0,0) 100%)`,maskImage:`linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(0,0,0,0.94) 48%, rgba(0,0,0,0.46) 74%, rgba(0,0,0,0) 100%)`},children:(0,L.jsx)(`div`,{ref:C,className:`absolute inset-0`,style:E,children:(0,L.jsx)(te.div,{initial:re,animate:{opacity:ie},exit:{opacity:0},transition:{duration:.8,ease:`easeInOut`},className:`absolute inset-0`,style:i({backgroundImage:ee,backgroundRepeat:`no-repeat`,backgroundSize:`cover`,backgroundPosition:`${ae}% center`},O)},A)})}):null}),(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{background:`linear-gradient(90deg, ${k(n.backgroundColor,.14)} 0%, ${k(n.backgroundColor,.28)} 28%, ${k(n.backgroundColor,.62)} 64%, ${k(n.backgroundColor,.86)} 100%)`}}),(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{backgroundImage:`radial-gradient(circle at 18% 34%, ${k(n.accentColor,.18)}, transparent 36%)`,backgroundSize:`cover`,backgroundPosition:`center`}}),(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{background:y}})]}))},jo=t({default:()=>No}),Mo={"cover-derived":`options.monetBackgroundSourceCover`,"uploaded-global":`options.monetBackgroundSourceUploaded`},No=Fe({mode:`monet`,order:20,labelKey:`options.visualizerBackgroundModeMonet`,labelFallback:`Monet`,glyph:(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`rect`,{x:`3.5`,y:`4.5`,width:`17`,height:`15`,rx:`2`}),(0,L.jsx)(`path`,{d:`M20.5 8.5L8 19.5`,opacity:`0.55`})]}),song:({config:e,coverUrl:t})=>{var n,r;return[ko(t,e==null?void 0:e.customImage,(n=e==null||(r=e.monet)==null?void 0:r.tuning)==null?j:n)]},render:({config:e,coverUrl:t,theme:n,isDaylight:r,staticMode:i})=>{var a;return(0,L.jsx)(Ao,{coverUrl:t,monetBackgroundImage:e==null?void 0:e.customImage,theme:n,isDaylight:r,tuning:e==null||(a=e.monet)==null?void 0:a.tuning,transparentBackground:e==null?void 0:e.transparent,staticMode:i})},renderSettingsPanel:({config:e,actions:t,t:n,onSliderPointerDown:r,onSliderCommit:i})=>{var a,o,s,c,l,u;return(0,L.jsx)(Ga,{t:n,tuning:(a=e==null||(o=e.monet)==null?void 0:o.tuning)==null?j:a,onTuningChange:t==null||(s=t.monet)==null?void 0:s.onTuningChange,monetBackgroundImage:e==null?void 0:e.customImage,onUploadMonetBackgroundImage:t==null||(c=t.customImage)==null?void 0:c.onUpload,onClearMonetBackgroundImage:t==null||(l=t.customImage)==null?void 0:l.onClear,isLoadingMonetBackgroundImage:t==null||(u=t.customImage)==null?void 0:u.isLoading,onSliderPointerDown:r,onSliderCommit:i})},renderQuickControls:({config:e,actions:t,t:n})=>{var r,i;let a=(r=e==null||(i=e.monet)==null?void 0:i.tuning)==null?j:r,o=a.backgroundLayout===`full-overlay`,s=n(o?`options.monetLayoutFullOverlay`:`options.monetLayoutHalfPane`),c=e=>{var n,r;return t==null||(n=t.monet)==null||(r=n.onTuningChange)==null?void 0:r.call(n,e)},l=a.backgroundSource,u=n(Mo[l]),d=!!(e!=null&&e.customImage);return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(pe,{label:s,title:`${n(`options.monetBackgroundLayout`)}: ${s}`,onClick:()=>c({backgroundLayout:o?`half-pane-gradient`:`full-overlay`})}),(0,L.jsx)(pe,{label:u,title:`${n(`options.monetBackgroundSource`)}: ${u}`,disabled:!d&&l===`cover-derived`,onClick:()=>c({backgroundSource:d&&l===`cover-derived`?`uploaded-global`:`cover-derived`})}),(0,L.jsx)(he,{active:a.backgroundStreaksEnabled,label:n(`options.monetBackgroundStreaksEnabled`),onToggle:()=>c({backgroundStreaksEnabled:!a.backgroundStreaksEnabled}),children:(0,L.jsx)(g,{size:14})}),(0,L.jsx)(he,{active:a.backgroundDriftEnabled,label:n(`options.monetBackgroundDriftEnabled`),onToggle:()=>c({backgroundDriftEnabled:!a.backgroundDriftEnabled}),children:(0,L.jsx)(p,{size:14})})]})},resetSettings:e=>{var t,n;return e==null||(t=e.monet)==null||(n=t.onResetTuning)==null?void 0:n.call(t)}}),Po=1.8,Fo=.01,Io=16/9,Lo={fiberSize:.2,crumples:.35,crumpleSize:.35,folds:.65,foldCount:5,drops:.2,seed:5.8},Ro={perspective:.4,count:20,focusCenter:.55,focusEdges:.8,swirl:.08,lensCircle:.1},zo=e=>Math.min(1,Math.max(0,e)),Bo=e=>Math.min(Po,Math.max(1,e)),Vo=e=>e<=1?1:Bo(e+Fo),Ho=e=>Vo(1/(1-2*Math.min(Math.max(e,0),.45))),Uo=(e,t,n)=>n&&!t?!e:e,Wo=(e,t,n)=>Uo(!e,t,n),Go=(e,t)=>{let{folds:n,crumples:r,drops:i}=Lo;return Ho(.02*(2*n+1.5*r+.2*i+.75*zo(e)+.1*zo(t)))},Ko=(e,t)=>{let n=.5*Math.hypot(Io,1),r=zo(t),i=.7*r**(1.3+2.7*r)*(1-Ro.focusEdges),a=Math.max(.35,1-i/n);if(e<=0)return Vo(1/a);let o=Math.min(e,1)*1.4,s=e=>{let t=2*n/e;return Math.tan(t*o)/Math.tan(o)/t},c=Math.max(1,2*n*o/1.45);if(c>=Po||s(Po)>Po*a)return Po;if(c===1&&s(1)<=a)return Vo(1/a);let l=Po;for(let e=0;e<32;e+=1){let e=(c+l)/2;s(e)>e*a?c=e:l=e}return Vo(l)},qo=(e,t)=>{let n=ct();(0,I.useEffect)(()=>{if(t===null){n();return}let r=0,i=()=>{var t;r=requestAnimationFrame((t=e.current)!=null&&t.paperShaderMount?n:i)};return i(),()=>cancelAnimationFrame(r)},[e,t,n])},Jo=(e,t,n)=>{var r;return n.imageSource===`uploaded-global`?(r=t==null?void 0:t.url)==null?e:r:e==null?t==null?void 0:t.url:e},Yo=I.memo(({coverUrl:e,monetBackgroundImage:t,tuning:n,theme:r,isDaylight:a})=>{let o=i(i({},A),n),s=Jo(e,t,o),c=(0,I.useRef)(null);return qo(c,s?`${s}:${o.effect}`:null),s?(0,L.jsxs)(`div`,{className:`absolute inset-0 z-0 overflow-hidden`,style:{backgroundColor:r.backgroundColor,pointerEvents:`none`},children:[(()=>{let e={width:`100%`,height:`100%`,ref:c,image:s,fit:`cover`,minPixelRatio:1,maxPixelCount:2073600,webGlContextAttributes:zr,style:{width:`100%`,height:`100%`}};switch(o.effect){case`fluted-glass`:return(0,L.jsx)(hr,i(i({},e),{},{colorBack:r.backgroundColor,colorShadow:r.secondaryColor,colorHighlight:r.primaryColor,shadows:.25,size:o.flutedGlassSize,distortion:o.flutedGlassDistortion,blur:o.flutedGlassBlur,shape:`lines`,distortionShape:`prism`,highlights:.1,edges:.25}),`${s}:fluted-glass`);case`paper-texture`:return(0,L.jsx)(pr,i(i(i({},e),Lo),{},{colorFront:r.accentColor,colorBack:r.backgroundColor,contrast:o.paperTextureContrast,roughness:o.paperTextureRoughness,fiber:o.paperTextureFiber,scale:Go(o.paperTextureRoughness,o.paperTextureFiber)}),`${s}:paper-texture`);case`halftone-dots`:return(0,L.jsx)(xr,i(i({},e),{},{colorBack:r.backgroundColor,colorFront:r.accentColor,size:o.halftoneDotsSize,radius:o.halftoneDotsRadius,contrast:o.halftoneDotsContrast,originalColors:o.halftoneDotsOriginalColors,inverted:Wo(o.halftoneDotsInverted,o.halftoneDotsOriginalColors,a),grid:`hex`,type:`gooey`,grainMixer:.12,grainOverlay:.06,grainSize:.5}),`${s}:halftone-dots`);case`lens-distortion`:return(0,L.jsx)(yr,i(i(i({},e),Ro),{},{spread:o.lensDistortionSpread,dispersion:o.lensDistortionDispersion,lensBulge:o.lensDistortionBulge,scale:Ko(o.lensDistortionBulge,o.lensDistortionSpread)}),`${s}:lens-distortion`);default:return(0,L.jsx)(_r,i(i({},e),{},{colorBack:r.backgroundColor,colorFront:r.accentColor,colorHighlight:r.primaryColor,originalColors:o.originalColors,inverted:Uo(o.inverted,o.originalColors,a),type:o.ditheringType,size:o.size,colorSteps:o.colorSteps}),`${s}:dithering`)}})(),o.overlayEnabled&&o.overlayOpacity>0&&(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{backgroundColor:r.backgroundColor,opacity:o.overlayOpacity}})]}):(0,L.jsx)(`div`,{className:`absolute inset-0 z-0`,style:{backgroundColor:r.backgroundColor}})}),Xo=[`2x2`,`4x4`,`8x8`],Zo=({t:e,tuning:t,onTuningChange:n,onSliderPointerDown:r,onSliderCommit:a})=>{let o={onDragStart:r,onDragEnd:a};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(F,{label:e(`options.nomandBackgroundDitheringType`),children:(0,L.jsx)(le,{value:t.ditheringType,options:Xo.map(e=>({value:e,label:e})),onChange:e=>n==null?void 0:n({ditheringType:e})})}),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundSize`),value:t.size,min:.5,max:20,step:.5,format:e=>e.toFixed(1),onChange:e=>n==null?void 0:n({size:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundColorSteps`),value:t.colorSteps,min:1,max:7,step:1,format:e=>String(Math.round(e)),onChange:e=>n==null?void 0:n({colorSteps:e})})),(0,L.jsx)(P,{label:e(`options.nomandBackgroundOriginalColors`),checked:t.originalColors,onChange:e=>n==null?void 0:n({originalColors:e})}),(0,L.jsx)(P,{label:e(`options.nomandBackgroundInverted`),checked:t.inverted,onChange:e=>n==null?void 0:n({inverted:e})})]})},Qo=e=>e.toFixed(2),$o=({t:e,tuning:t,onTuningChange:n,onSliderPointerDown:r,onSliderCommit:a})=>{let o={onDragStart:r,onDragEnd:a};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundFlutedGlassSize`),value:t.flutedGlassSize,min:.1,max:1,step:.05,format:Qo,onChange:e=>n==null?void 0:n({flutedGlassSize:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundFlutedGlassDistortion`),value:t.flutedGlassDistortion,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({flutedGlassDistortion:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundFlutedGlassBlur`),value:t.flutedGlassBlur,min:0,max:1,step:.01,format:N,onChange:e=>n==null?void 0:n({flutedGlassBlur:e})}))]})},es=({t:e,tuning:t,onTuningChange:n,onSliderPointerDown:r,onSliderCommit:a})=>{let o={onDragStart:r,onDragEnd:a};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundHalftoneDotsSize`),value:t.halftoneDotsSize,min:.1,max:1,step:.05,format:Qo,onChange:e=>n==null?void 0:n({halftoneDotsSize:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundHalftoneDotsRadius`),value:t.halftoneDotsRadius,min:.1,max:2,step:.05,format:Qo,onChange:e=>n==null?void 0:n({halftoneDotsRadius:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundHalftoneDotsContrast`),value:t.halftoneDotsContrast,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({halftoneDotsContrast:e})})),(0,L.jsx)(P,{label:e(`options.nomandBackgroundOriginalColors`),checked:t.halftoneDotsOriginalColors,onChange:e=>n==null?void 0:n({halftoneDotsOriginalColors:e})}),(0,L.jsx)(P,{label:e(`options.nomandBackgroundInverted`),checked:t.halftoneDotsInverted,onChange:e=>n==null?void 0:n({halftoneDotsInverted:e})})]})},ts=({t:e,tuning:t,onTuningChange:n,onSliderPointerDown:r,onSliderCommit:a})=>{let o={onDragStart:r,onDragEnd:a};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundLensDistortionSpread`),value:t.lensDistortionSpread,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({lensDistortionSpread:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundLensDistortionBulge`),value:t.lensDistortionBulge,min:-1,max:1,step:.05,format:Qo,onChange:e=>n==null?void 0:n({lensDistortionBulge:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundLensDistortionDispersion`),value:t.lensDistortionDispersion,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({lensDistortionDispersion:e})}))]})},ns=({t:e,tuning:t,onTuningChange:n,onSliderPointerDown:r,onSliderCommit:a})=>{let o={onDragStart:r,onDragEnd:a};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundPaperTextureContrast`),value:t.paperTextureContrast,min:0,max:1,step:.01,format:N,onChange:e=>n==null?void 0:n({paperTextureContrast:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundPaperTextureRoughness`),value:t.paperTextureRoughness,min:0,max:1,step:.01,format:N,onChange:e=>n==null?void 0:n({paperTextureRoughness:e})})),(0,L.jsx)(M,i(i({},o),{},{label:e(`options.nomandBackgroundPaperTextureFiber`),value:t.paperTextureFiber,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({paperTextureFiber:e})}))]})},rs={id:`bg-nomand-effect`,titleKey:`options.nomandBackgroundEffect`},is=[`dithering`,`fluted-glass`,`paper-texture`,`halftone-dots`,`lens-distortion`],as={dithering:`options.nomandBackgroundEffectDithering`,"fluted-glass":`options.nomandBackgroundEffectFlutedGlass`,"paper-texture":`options.nomandBackgroundEffectPaperTexture`,"halftone-dots":`options.nomandBackgroundEffectHalftoneDots`,"lens-distortion":`options.nomandBackgroundEffectLensDistortion`},os={dithering:{backgroundImage:`conic-gradient(var(--st-t2) 25%, transparent 0 50%, var(--st-t2) 0 75%, transparent 0)`,backgroundSize:`8px 8px`},"fluted-glass":{backgroundImage:`repeating-linear-gradient(90deg, transparent 0 2px, var(--st-t2) 5px, transparent 8px)`},"paper-texture":{backgroundImage:`repeating-linear-gradient(37deg, transparent 0 3px, var(--st-t3) 3px 4px), repeating-linear-gradient(-58deg, transparent 0 5px, var(--st-t3) 5px 6px)`},"halftone-dots":{backgroundImage:`radial-gradient(var(--st-t2) 32%, transparent 36%)`,backgroundSize:`8px 8px`},"lens-distortion":{backgroundImage:`radial-gradient(circle at 50% 50%, transparent 0 22%, var(--st-t2) 24% 28%, transparent 30% 46%, var(--st-t3) 48% 52%, transparent 54%)`}},ss=e=>(0,L.jsx)(`span`,{className:`absolute inset-0`,style:os[e]}),cs=e=>{let{t,tuning:n}=e;return(0,L.jsxs)(fe,{def:rs,children:[(0,L.jsx)(F,{below:(0,L.jsx)(de,{className:`-mx-4`,columns:3,label:t(`options.nomandBackgroundEffect`),value:n.effect,options:is.map(e=>({value:e,label:t(as[e])})),picture:ss,onChange:t=>{var n;return(n=e.onTuningChange)==null?void 0:n.call(e,{effect:t})}})}),n.effect===`dithering`&&(0,L.jsx)(Zo,i({},e)),n.effect===`fluted-glass`&&(0,L.jsx)($o,i({},e)),n.effect===`paper-texture`&&(0,L.jsx)(ns,i({},e)),n.effect===`halftone-dots`&&(0,L.jsx)(es,i({},e)),n.effect===`lens-distortion`&&(0,L.jsx)(ts,i({},e))]})},ls={id:`bg-nomand`,titleKey:`options.nomandBackgroundSettings`},us=({t:e,tuning:t,onTuningChange:n,monetBackgroundImage:r,onUploadMonetBackgroundImage:a,onClearMonetBackgroundImage:o,isLoadingMonetBackgroundImage:l=!1,onSliderPointerDown:u,onSliderCommit:d})=>{let f=i(i({},A),t),p=(0,I.useRef)(null),[m,h]=(0,I.useState)(``),g=e=>{n==null||n({imageSource:e})},_=async t=>{var n;if(!t.length||!a)return;let r=await a(t);h(r.ok?e(`options.nomandBackgroundUploadSuccess`):(n=r.error)==null?e(`options.nomandBackgroundUploadFailed`):n),r.ok&&g(`uploaded-global`)};return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(fe,{def:ls,children:[(0,L.jsx)(F,{label:e(`options.nomandBackgroundSource`),children:(0,L.jsx)(le,{value:f.imageSource,options:[{value:`cover-derived`,label:e(`options.monetBackgroundSourceCover`)},{value:`uploaded-global`,label:e(`options.monetBackgroundSourceUploaded`),disabled:!r&&!l}],onChange:g})}),(0,L.jsxs)(F,{label:e(`options.monetUploadBackground`),hint:m||(r==null?void 0:r.name)||`-`,children:[(0,L.jsx)(me,{icon:s,disabled:l||!a,onClick:()=>{var e;return(e=p.current)==null?void 0:e.click()},children:e(`options.monetUploadBackground`)}),(0,L.jsx)(me,{icon:c,disabled:!r||!o,onClick:()=>void(o==null?void 0:o()),children:e(`options.monetClearBackground`)}),(0,L.jsx)(`input`,{ref:p,type:`file`,accept:`image/png,image/jpeg,image/webp,image/gif`,className:`hidden`,onChange:e=>{var t;_(Array.from((t=e.target.files)==null?[]:t)),e.target.value=``}})]}),(0,L.jsx)(P,{label:e(`options.nomandBackgroundOverlay`),note:e(`options.nomandBackgroundOverlayDesc`),checked:f.overlayEnabled,onChange:e=>n==null?void 0:n({overlayEnabled:e})}),(0,L.jsx)(Ce,{when:f.overlayEnabled,children:(0,L.jsx)(M,{sub:!0,label:e(`options.nomandBackgroundOverlayOpacity`),value:f.overlayOpacity,min:0,max:1,step:.05,format:N,onChange:e=>n==null?void 0:n({overlayOpacity:e}),onDragStart:u,onDragEnd:d})})]}),(0,L.jsx)(cs,{t:e,tuning:f,onTuningChange:n,onSliderPointerDown:u,onSliderCommit:d})]})},ds=t({default:()=>ms}),fs=[`config`,`actions`],ps={"cover-derived":`options.monetBackgroundSourceCover`,"uploaded-global":`options.monetBackgroundSourceUploaded`},ms=Fe({mode:`nomand`,order:30,labelKey:`options.visualizerBackgroundModeNomand`,labelFallback:`Nomand`,glyph:(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`rect`,{x:`4`,y:`4`,width:`6.5`,height:`6.5`,rx:`0.8`}),(0,L.jsx)(`rect`,{x:`13.5`,y:`4`,width:`6.5`,height:`6.5`,rx:`0.8`,opacity:`0.45`}),(0,L.jsx)(`rect`,{x:`4`,y:`13.5`,width:`6.5`,height:`6.5`,rx:`0.8`,opacity:`0.45`}),(0,L.jsx)(`rect`,{x:`13.5`,y:`13.5`,width:`6.5`,height:`6.5`,rx:`0.8`})]}),command:{title:`Background: Nomand`,description:`Switch background to theme-colored image dithering`,keywords:[`nomand`,`dithering`,`dither`,`shader background`,`漫游`,`像素画`,`像素画背景`,`抖动背景`,`网点背景`,`主题色背景`]},song:({config:e,coverUrl:t})=>{var n,r;return[(n=Jo(t,e==null?void 0:e.customImage,i(i({},A),e==null||(r=e.nomand)==null?void 0:r.tuning)))==null?null:n]},render:({config:e,coverUrl:t,theme:n,isDaylight:r})=>{var i;return(0,L.jsx)(Yo,{coverUrl:t,monetBackgroundImage:e==null?void 0:e.customImage,tuning:e==null||(i=e.nomand)==null?void 0:i.tuning,theme:n,isDaylight:r})},renderSettingsPanel:e=>{var t,n,r,a,o,s;let{config:c,actions:l}=e,u=d(e,fs);return(0,L.jsx)(us,i(i({},u),{},{tuning:(t=c==null||(n=c.nomand)==null?void 0:n.tuning)==null?A:t,onTuningChange:l==null||(r=l.nomand)==null?void 0:r.onTuningChange,monetBackgroundImage:c==null?void 0:c.customImage,onUploadMonetBackgroundImage:l==null||(a=l.customImage)==null?void 0:a.onUpload,onClearMonetBackgroundImage:l==null||(o=l.customImage)==null?void 0:o.onClear,isLoadingMonetBackgroundImage:l==null||(s=l.customImage)==null?void 0:s.isLoading}))},renderQuickControls:({config:e,actions:t,t:n})=>{var r,i;let a=(r=e==null||(i=e.nomand)==null?void 0:i.tuning)==null?A:r,s=e=>{var n,r;return t==null||(n=t.nomand)==null||(r=n.onTuningChange)==null?void 0:r.call(n,e)},c=a.imageSource,l=n(ps[c]),u=!!(e!=null&&e.customImage),d=n(as[a.effect]);return(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(pe,{label:l,title:`${n(`options.nomandBackgroundSource`)}: ${l}`,disabled:!u&&c===`cover-derived`,onClick:()=>s({imageSource:u&&c===`cover-derived`?`uploaded-global`:`cover-derived`})}),(0,L.jsx)(pe,{label:d,title:`${n(`options.nomandBackgroundEffect`)}: ${d}`,onClick:()=>s({effect:ue(is,a.effect)})}),(0,L.jsx)(he,{active:a.overlayEnabled,label:n(`options.nomandBackgroundOverlay`),onToggle:()=>s({overlayEnabled:!a.overlayEnabled}),children:(0,L.jsx)(o,{size:14})})]})},resetSettings:e=>{var t,n;return e==null||(t=e.nomand)==null||(n=t.onResetTuning)==null?void 0:n.call(t)}}),hs=5120,gs=5121,_s=5122,vs=5123,ys=5124,bs=5125,xs=5126,Ss=32819,Cs=32820,ws=33635,Ts=5131,Es=33640,Ds=35899,Os=35902,ks=36269,As=34042,js={};{let e=js;e[hs]=Int8Array,e[gs]=Uint8Array,e[_s]=Int16Array,e[vs]=Uint16Array,e[ys]=Int32Array,e[bs]=Uint32Array,e[xs]=Float32Array,e[Ss]=Uint16Array,e[Cs]=Uint16Array,e[ws]=Uint16Array,e[Ts]=Uint16Array,e[Es]=Uint32Array,e[Ds]=Uint32Array,e[Os]=Uint32Array,e[ks]=Uint32Array,e[As]=Uint32Array}function Ms(e){if(e instanceof Int8Array)return hs;if(e instanceof Uint8Array||e instanceof Uint8ClampedArray)return gs;if(e instanceof Int16Array)return _s;if(e instanceof Uint16Array)return vs;if(e instanceof Int32Array)return ys;if(e instanceof Uint32Array)return bs;if(e instanceof Float32Array)return xs;throw Error(`unsupported typed array type`)}function Ns(e){if(e===Int8Array)return hs;if(e===Uint8Array||e===Uint8ClampedArray)return gs;if(e===Int16Array)return _s;if(e===Uint16Array)return vs;if(e===Int32Array)return ys;if(e===Uint32Array)return bs;if(e===Float32Array)return xs;throw Error(`unsupported typed array type`)}function Ps(e){let t=js[e];if(!t)throw Error(`unknown gl type`);return t}var Fs=typeof SharedArrayBuffer<`u`?function(e){return e&&e.buffer&&(e.buffer instanceof ArrayBuffer||e.buffer instanceof SharedArrayBuffer)}:function(e){return e&&e.buffer&&e.buffer instanceof ArrayBuffer};function Is(...e){console.error(...e)}function Ls(...e){console.warn(...e)}var Rs=new Map;function zs(e,t){if(!e||typeof e!=`object`)return!1;let n=Rs.get(t);n||(n=new WeakMap,Rs.set(t,n));let r=n.get(e);if(r===void 0){let i=Object.prototype.toString.call(e);r=i.substring(8,i.length-1)===t,n.set(e,r)}return r}function Bs(e,t){return typeof WebGLBuffer<`u`&&zs(t,`WebGLBuffer`)}function Vs(e,t){return typeof WebGLTexture<`u`&&zs(t,`WebGLTexture`)}var Hs=35044,Us=34962,Ws=34963,Gs=34660,Ks=5120,qs=5121,Js=5122,Ys=5123,Xs=5124,Zs=5125,Qs=5126,$s={attribPrefix:``};function ec(e,t,n,r,i){e.bindBuffer(t,n),e.bufferData(t,r,i||Hs)}function tc(e,t,n,r){if(Bs(e,t))return t;n=n||Us;let i=e.createBuffer();return ec(e,n,i,t,r),i}function nc(e){return e===`indices`}function rc(e){return e===Int8Array||e===Uint8Array}function ic(e){return e.length?e:e.data}var ac=/coord|texture/i,oc=/color|colour/i;function sc(e,t){let n;if(n=ac.test(e)?2:oc.test(e)?4:3,t%n>0)throw Error(`Can not guess numComponents for attribute '${e}'. Tried ${n} but ${t} values is not evenly divisible by ${n}. You should specify it.`);return n}function cc(e,t,n){return e.numComponents||e.size||sc(t,n||ic(e).length)}function lc(e,t){if(Fs(e))return e;if(Fs(e.data))return e.data;Array.isArray(e)&&(e={data:e});let n=e.type?dc(e.type):void 0;return n||(n=nc(t)?Uint16Array:Float32Array),new n(e.data)}function uc(e){return typeof e==`number`?e:e?Ns(e):Qs}function dc(e){return typeof e==`number`?Ps(e):e||Float32Array}function fc(e,t){return{buffer:t.buffer,numValues:24,type:uc(t.type),arrayType:dc(t.type)}}function pc(e,t){let n=t.data||t,r=dc(t.type),i=n*r.BYTES_PER_ELEMENT,a=e.createBuffer();return e.bindBuffer(Us,a),e.bufferData(Us,i,t.drawType||Hs),{buffer:a,numValues:n,type:Ns(r),arrayType:r}}function mc(e,t,n){let r=lc(t,n);return{arrayType:r.constructor,buffer:tc(e,r,void 0,t.drawType),type:Ms(r),numValues:0}}function hc(e,t){let n={};return Object.keys(t).forEach(function(r){if(!nc(r)){let i=t[r],a=i.attrib||i.name||i.attribName||$s.attribPrefix+r;if(i.value){if(!Array.isArray(i.value)&&!Fs(i.value))throw Error(`array.value is not array or typedarray`);n[a]={value:i.value}}else{let t;t=i.buffer&&i.buffer instanceof WebGLBuffer?fc:typeof i==`number`||typeof i.data==`number`?pc:mc;let{buffer:o,type:s,numValues:c,arrayType:l}=t(e,i,r),u=i.normalize===void 0?rc(l):i.normalize,d=cc(i,r,c);n[a]={buffer:o,numComponents:d,type:s,normalize:u,stride:i.stride||0,offset:i.offset||0,divisor:i.divisor===void 0?void 0:i.divisor,drawType:i.drawType}}}}),e.bindBuffer(Us,null),n}function gc(e,t){return t===Ks||t===qs?1:t===Js||t===Ys?2:t===Xs||t===Zs||t===Qs?4:0}var _c=[`position`,`positions`,`a_position`];function vc(e,t){let n,r=0;for(;r<_c.length&&(n=_c[r],!(n in t||(n=$s.attribPrefix+n,n in t)));++r);r===_c.length&&(n=Object.keys(t)[0]);let i=t[n];if(!i.buffer)return 1;e.bindBuffer(Us,i.buffer);let a=e.getBufferParameter(Us,Gs);e.bindBuffer(Us,null);let o=a/gc(e,i.type),s=i.numComponents||i.size,c=o/s;if(c%1!=0)throw Error(`numComponents ${s} not correct for length ${length}`);return c}function yc(e,t,n){let r=hc(e,t),i=Object.assign({},n||{});i.attribs=Object.assign({},n?n.attribs:{},r);let a=t.indices;if(a){let t=lc(a,`indices`);i.indices=tc(e,t,Ws),i.numElements=t.length,i.elementType=Ms(t)}else i.numElements||(i.numElements=vc(e,i.attribs));return i}function bc(e){return!!e.texStorage2D}var xc=function(){let e={},t={};function n(n){let r=n.constructor.name;if(!e[r]){for(let e in n)if(typeof n[e]==`number`){let r=t[n[e]];t[n[e]]=r?`${r} | ${e}`:e}e[r]=!0}}return function(e,r){return n(e),t[r]||(typeof r==`number`?`0x${r.toString(16)}`:r)}}();new Uint8Array([128,192,255,255]);var Sc=6406,Cc=6407,wc=6408,Tc=6409,Ec=6410,Dc=6402,Oc=34041,kc=33319,Ac=33320,jc=6403,Mc=36244,Nc=36248,Pc=36249,Fc={};{let e=Fc;e[Sc]={numColorComponents:1},e[Tc]={numColorComponents:1},e[Ec]={numColorComponents:2},e[Cc]={numColorComponents:3},e[wc]={numColorComponents:4},e[jc]={numColorComponents:1},e[Mc]={numColorComponents:1},e[kc]={numColorComponents:2},e[Ac]={numColorComponents:2},e[Cc]={numColorComponents:3},e[Nc]={numColorComponents:3},e[wc]={numColorComponents:4},e[Pc]={numColorComponents:4},e[Dc]={numColorComponents:1},e[Oc]={numColorComponents:2}}var Ic=Is;function Lc(e){return typeof document<`u`&&document.getElementById?document.getElementById(e):null}var Rc=33984,zc=34962,Bc=34963,Vc=35713,Hc=35714,Uc=35632,Wc=35633,Gc=35981,Kc=35718,qc=35721,Jc=35971,Yc=35382,Xc=35396,Zc=35398,Qc=35392,$c=35395,el=5126,tl=35664,nl=35665,rl=35666,il=5124,al=35667,ol=35668,sl=35669,cl=35670,ll=35671,ul=35672,dl=35673,fl=35674,pl=35675,ml=35676,hl=35678,gl=35680,_l=35679,vl=35682,yl=35685,bl=35686,xl=35687,Sl=35688,Cl=35689,wl=35690,Tl=36289,El=36292,Dl=36293,Ol=5125,kl=36294,Al=36295,jl=36296,Ml=36298,Nl=36299,Pl=36300,Fl=36303,Il=36306,Ll=36307,Rl=36308,zl=36311,Bl=3553,Vl=34067,Hl=32879,Ul=35866,X={};function Wl(e,t){return X[t].bindPoint}function Gl(e,t){return function(n){e.uniform1f(t,n)}}function Kl(e,t){return function(n){e.uniform1fv(t,n)}}function ql(e,t){return function(n){e.uniform2fv(t,n)}}function Jl(e,t){return function(n){e.uniform3fv(t,n)}}function Yl(e,t){return function(n){e.uniform4fv(t,n)}}function Xl(e,t){return function(n){e.uniform1i(t,n)}}function Zl(e,t){return function(n){e.uniform1iv(t,n)}}function Ql(e,t){return function(n){e.uniform2iv(t,n)}}function $l(e,t){return function(n){e.uniform3iv(t,n)}}function eu(e,t){return function(n){e.uniform4iv(t,n)}}function tu(e,t){return function(n){e.uniform1ui(t,n)}}function nu(e,t){return function(n){e.uniform1uiv(t,n)}}function ru(e,t){return function(n){e.uniform2uiv(t,n)}}function iu(e,t){return function(n){e.uniform3uiv(t,n)}}function au(e,t){return function(n){e.uniform4uiv(t,n)}}function ou(e,t){return function(n){e.uniformMatrix2fv(t,!1,n)}}function su(e,t){return function(n){e.uniformMatrix3fv(t,!1,n)}}function cu(e,t){return function(n){e.uniformMatrix4fv(t,!1,n)}}function lu(e,t){return function(n){e.uniformMatrix2x3fv(t,!1,n)}}function uu(e,t){return function(n){e.uniformMatrix3x2fv(t,!1,n)}}function du(e,t){return function(n){e.uniformMatrix2x4fv(t,!1,n)}}function fu(e,t){return function(n){e.uniformMatrix4x2fv(t,!1,n)}}function pu(e,t){return function(n){e.uniformMatrix3x4fv(t,!1,n)}}function mu(e,t){return function(n){e.uniformMatrix4x3fv(t,!1,n)}}function Z(e,t,n,r){let i=Wl(e,t);return bc(e)?function(t){let a,o;!t||Vs(e,t)?(a=t,o=null):(a=t.texture,o=t.sampler),e.uniform1i(r,n),e.activeTexture(Rc+n),e.bindTexture(i,a),e.bindSampler(n,o)}:function(t){e.uniform1i(r,n),e.activeTexture(Rc+n),e.bindTexture(i,t)}}function Q(e,t,n,r,i){let a=Wl(e,t),o=new Int32Array(i);for(let e=0;e<i;++e)o[e]=n+e;return bc(e)?function(t){e.uniform1iv(r,o),t.forEach(function(t,r){e.activeTexture(Rc+o[r]);let i,s;!t||Vs(e,t)?(i=t,s=null):(i=t.texture,s=t.sampler),e.bindSampler(n,s),e.bindTexture(a,i)})}:function(t){e.uniform1iv(r,o),t.forEach(function(t,n){e.activeTexture(Rc+o[n]),e.bindTexture(a,t)})}}X[el]={Type:Float32Array,size:4,setter:Gl,arraySetter:Kl},X[tl]={Type:Float32Array,size:8,setter:ql,cols:2},X[nl]={Type:Float32Array,size:12,setter:Jl,cols:3},X[rl]={Type:Float32Array,size:16,setter:Yl,cols:4},X[il]={Type:Int32Array,size:4,setter:Xl,arraySetter:Zl},X[al]={Type:Int32Array,size:8,setter:Ql,cols:2},X[ol]={Type:Int32Array,size:12,setter:$l,cols:3},X[sl]={Type:Int32Array,size:16,setter:eu,cols:4},X[Ol]={Type:Uint32Array,size:4,setter:tu,arraySetter:nu},X[kl]={Type:Uint32Array,size:8,setter:ru,cols:2},X[Al]={Type:Uint32Array,size:12,setter:iu,cols:3},X[jl]={Type:Uint32Array,size:16,setter:au,cols:4},X[cl]={Type:Uint32Array,size:4,setter:Xl,arraySetter:Zl},X[ll]={Type:Uint32Array,size:8,setter:Ql,cols:2},X[ul]={Type:Uint32Array,size:12,setter:$l,cols:3},X[dl]={Type:Uint32Array,size:16,setter:eu,cols:4},X[fl]={Type:Float32Array,size:32,setter:ou,rows:2,cols:2},X[pl]={Type:Float32Array,size:48,setter:su,rows:3,cols:3},X[ml]={Type:Float32Array,size:64,setter:cu,rows:4,cols:4},X[yl]={Type:Float32Array,size:32,setter:lu,rows:2,cols:3},X[bl]={Type:Float32Array,size:32,setter:du,rows:2,cols:4},X[xl]={Type:Float32Array,size:48,setter:uu,rows:3,cols:2},X[Sl]={Type:Float32Array,size:48,setter:pu,rows:3,cols:4},X[Cl]={Type:Float32Array,size:64,setter:fu,rows:4,cols:2},X[wl]={Type:Float32Array,size:64,setter:mu,rows:4,cols:3},X[hl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Bl},X[gl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Vl},X[_l]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Hl},X[vl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Bl},X[Tl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Ul},X[El]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Ul},X[Dl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Vl},X[Ml]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Bl},X[Nl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Hl},X[Pl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Vl},X[Fl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Ul},X[Il]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Bl},X[Ll]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Hl},X[Rl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Vl},X[zl]={Type:null,size:0,setter:Z,arraySetter:Q,bindPoint:Ul};function hu(e,t){return function(n){if(n.value)switch(e.disableVertexAttribArray(t),n.value.length){case 4:e.vertexAttrib4fv(t,n.value);break;case 3:e.vertexAttrib3fv(t,n.value);break;case 2:e.vertexAttrib2fv(t,n.value);break;case 1:e.vertexAttrib1fv(t,n.value);break;default:throw Error(`the length of a float constant value must be between 1 and 4!`)}else e.bindBuffer(zc,n.buffer),e.enableVertexAttribArray(t),e.vertexAttribPointer(t,n.numComponents||n.size,n.type||el,n.normalize||!1,n.stride||0,n.offset||0),e.vertexAttribDivisor&&e.vertexAttribDivisor(t,n.divisor||0)}}function gu(e,t){return function(n){if(n.value){if(e.disableVertexAttribArray(t),n.value.length===4)e.vertexAttrib4iv(t,n.value);else throw Error(`The length of an integer constant value must be 4!`)}else e.bindBuffer(zc,n.buffer),e.enableVertexAttribArray(t),e.vertexAttribIPointer(t,n.numComponents||n.size,n.type||il,n.stride||0,n.offset||0),e.vertexAttribDivisor&&e.vertexAttribDivisor(t,n.divisor||0)}}function _u(e,t){return function(n){if(n.value){if(e.disableVertexAttribArray(t),n.value.length===4)e.vertexAttrib4uiv(t,n.value);else throw Error(`The length of an unsigned integer constant value must be 4!`)}else e.bindBuffer(zc,n.buffer),e.enableVertexAttribArray(t),e.vertexAttribIPointer(t,n.numComponents||n.size,n.type||Ol,n.stride||0,n.offset||0),e.vertexAttribDivisor&&e.vertexAttribDivisor(t,n.divisor||0)}}function vu(e,t,n){let r=n.size,i=n.count;return function(n){e.bindBuffer(zc,n.buffer);let a=n.size||n.numComponents||r,o=a/i,s=n.type||el,c=X[s].size*a,l=n.normalize||!1,u=n.offset||0,d=c/i;for(let r=0;r<i;++r)e.enableVertexAttribArray(t+r),e.vertexAttribPointer(t+r,o,s,l,c,u+d*r),e.vertexAttribDivisor&&e.vertexAttribDivisor(t+r,n.divisor||0)}}var $={};$[el]={size:4,setter:hu},$[tl]={size:8,setter:hu},$[nl]={size:12,setter:hu},$[rl]={size:16,setter:hu},$[il]={size:4,setter:gu},$[al]={size:8,setter:gu},$[ol]={size:12,setter:gu},$[sl]={size:16,setter:gu},$[Ol]={size:4,setter:_u},$[kl]={size:8,setter:_u},$[Al]={size:12,setter:_u},$[jl]={size:16,setter:_u},$[cl]={size:4,setter:gu},$[ll]={size:8,setter:gu},$[ul]={size:12,setter:gu},$[dl]={size:16,setter:gu},$[fl]={size:4,setter:vu,count:2},$[pl]={size:9,setter:vu,count:3},$[ml]={size:16,setter:vu,count:4};var yu=/ERROR:\s*\d+:(\d+)/gi;function bu(e,t=``,n=0){let r=[...t.matchAll(yu)],i=new Map(r.map((e,n)=>{let i=parseInt(e[1]),a=r[n+1],o=a?a.index:t.length,s=t.substring(e.index,o);return[i-1,s]}));return e.split(`
`).map((e,t)=>{let r=i.get(t);return`${t+1+n}: ${e}${r?`\n\n^^^ ${r}`:``}`}).join(`
`)}var xu=/^[ \t]*\n/;function Su(e){let t=0;return xu.test(e)&&(t=1,e=e.replace(xu,``)),{lineOffset:t,shaderSource:e}}function Cu(e,t){return e.errorCallback(t),e.callback&&setTimeout(()=>{e.callback(`${t}\n${e.errors.join(`
`)}`)}),null}function wu(e,t,n,r){if(r=r||Ic,!e.getShaderParameter(n,Vc)){let i=e.getShaderInfoLog(n),{lineOffset:a,shaderSource:o}=Su(e.getShaderSource(n)),s=`${bu(o,i,a)}\nError compiling ${xc(e,t)}: ${i}`;return r(s),s}return``}function Tu(e,t,n){let r,i,a;if(typeof t==`function`&&(n=t,t=void 0),typeof e==`function`)n=e,e=void 0;else if(e&&!Array.isArray(e)){let t=e;n=t.errorCallback,e=t.attribLocations,r=t.transformFeedbackVaryings,i=t.transformFeedbackMode,a=t.callback}let o=n||Ic,s=[],c={errorCallback(e,...t){s.push(e),o(e,...t)},transformFeedbackVaryings:r,transformFeedbackMode:i,callback:a,errors:s};{let n={};Array.isArray(e)?e.forEach(function(e,r){n[e]=t?t[r]:r}):n=e||{},c.attribLocations=n}return c}var Eu=[`VERTEX_SHADER`,`FRAGMENT_SHADER`];function Du(e,t){if(t.indexOf(`frag`)>=0)return Uc;if(t.indexOf(`vert`)>=0)return Wc}function Ou(e,t,n){let r=e.getAttachedShaders(t);for(let t of r)n.has(t)||e.deleteShader(t);e.deleteProgram(t)}var ku=(e=0)=>new Promise(t=>setTimeout(t,e));function Au(e,t,n){let r=e.createProgram(),{attribLocations:i,transformFeedbackVaryings:a,transformFeedbackMode:o}=Tu(n);for(let n=0;n<t.length;++n){let i=t[n];if(typeof i==`string`){let t=Lc(i),r=t?t.text:i,a=e[Eu[n]];t&&t.type&&(a=Du(e,t.type)||a),i=e.createShader(a),e.shaderSource(i,Su(r).shaderSource),e.compileShader(i)}e.attachShader(r,i)}Object.entries(i).forEach(([t,n])=>e.bindAttribLocation(r,n,t));{let t=a;t&&(t.attribs&&(t=t.attribs),Array.isArray(t)||(t=Object.keys(t)),e.transformFeedbackVaryings(r,t,o||Gc))}return e.linkProgram(r),r}function ju(e,t,n,r,i){let a=Tu(n,r,i),o=new Set(t),s=Au(e,t,a);function c(e,t){let n=Nu(e,t,a.errorCallback);return n&&Ou(e,t,o),n}if(a.callback)Mu(e,s).then(()=>{let t=c(e,s);a.callback(t,t?void 0:s)});else return c(e,s)?void 0:s}async function Mu(e,t){let n=e.getExtension(`KHR_parallel_shader_compile`),r=n?(e,t)=>e.getProgramParameter(t,n.COMPLETION_STATUS_KHR):()=>!0,i=0;do await ku(i),i=1e3/60;while(!r(e,t))}function Nu(e,t,n){if(n=n||Ic,!e.getProgramParameter(t,Hc)){let r=e.getProgramInfoLog(t);return n(`Error in program linking: ${r}`),`${r}\n${e.getAttachedShaders(t).map(t=>wu(e,e.getShaderParameter(t,e.SHADER_TYPE),t,n)).filter(e=>e).join(`
`)}`}}function Pu(e,t,n,r,i){return ju(e,t,n,r,i)}function Fu(e){let t=e.name;return t.startsWith(`gl_`)||t.startsWith(`webgl_`)}var Iu=/(\.|\[|]|\w+)/g,Lu=e=>e>=`0`&&e<=`9`;function Ru(e,t,n,r){let i=e.split(Iu).filter(e=>e!==``),a=0,o=``;for(;;){let e=i[a++];o+=e;let s=Lu(e[0]),c=s?parseInt(e):e;if(s&&(o+=i[a++]),a===i.length){n[c]=t;break}{let e=i[a++],t=e===`[`,s=n[c]||(t?[]:{});n[c]=s,n=s,r[o]=r[o]||function(e){return function(t){Hu(e,t)}}(s),o+=e}}}function zu(e,t){let n=0;function r(t,r,i){let a=r.name.endsWith(`[0]`),o=r.type,s=X[o];if(!s)throw Error(`unknown type: 0x${o.toString(16)}`);let c;if(s.bindPoint){let t=n;n+=r.size,c=a?s.arraySetter(e,o,t,i,r.size):s.setter(e,o,t,i,r.size)}else c=s.arraySetter&&a?s.arraySetter(e,i):s.setter(e,i);return c.location=i,c}let i={},a={},o=e.getProgramParameter(t,Kc);for(let n=0;n<o;++n){let o=e.getActiveUniform(t,n);if(Fu(o))continue;let s=o.name;s.endsWith(`[0]`)&&(s=s.substr(0,s.length-3));let c=e.getUniformLocation(t,o.name);if(c){let e=r(t,o,c);i[s]=e,Ru(s,e,a,i)}}return i}function Bu(e,t){let n={},r=e.getProgramParameter(t,Jc);for(let i=0;i<r;++i){let r=e.getTransformFeedbackVarying(t,i);n[r.name]={index:i,type:r.type,size:r.size}}return n}function Vu(e,t){let n=e.getProgramParameter(t,Kc),r=[],i=[];for(let a=0;a<n;++a){i.push(a),r.push({});let n=e.getActiveUniform(t,a);r[a].name=n.name}[[`UNIFORM_TYPE`,`type`],[`UNIFORM_SIZE`,`size`],[`UNIFORM_BLOCK_INDEX`,`blockNdx`],[`UNIFORM_OFFSET`,`offset`]].forEach(function(n){let a=n[0],o=n[1];e.getActiveUniforms(t,i,e[a]).forEach(function(e,t){r[t][o]=e})});let a={},o=e.getProgramParameter(t,Yc);for(let n=0;n<o;++n){let r=e.getActiveUniformBlockName(t,n),i={index:e.getUniformBlockIndex(t,r),usedByVertexShader:e.getActiveUniformBlockParameter(t,n,Xc),usedByFragmentShader:e.getActiveUniformBlockParameter(t,n,Zc),size:e.getActiveUniformBlockParameter(t,n,Qc),uniformIndices:e.getActiveUniformBlockParameter(t,n,$c)};i.used=i.usedByVertexShader||i.usedByFragmentShader,a[r]=i}return{blockSpecs:a,uniformData:r}}function Hu(e,t){for(let n in t){let r=e[n];typeof r==`function`?r(t[n]):Hu(e[n],t[n])}}function Uu(e,...t){let n=e.uniformSetters||e,r=t.length;for(let e=0;e<r;++e){let r=t[e];if(Array.isArray(r)){let e=r.length;for(let t=0;t<e;++t)Uu(n,r[t])}else for(let e in r){let t=n[e];t&&t(r[e])}}}function Wu(e,t){let n={},r=e.getProgramParameter(t,qc);for(let i=0;i<r;++i){let r=e.getActiveAttrib(t,i);if(Fu(r))continue;let a=e.getAttribLocation(t,r.name),o=$[r.type],s=o.setter(e,a,o);s.location=a,n[r.name]=s}return n}function Gu(e,t){for(let n in t){let r=e[n];r&&r(t[n])}}function Ku(e,t,n){n.vertexArrayObject?e.bindVertexArray(n.vertexArrayObject):(Gu(t.attribSetters||t,n.attribs),n.indices&&e.bindBuffer(Bc,n.indices))}function qu(e,t){let n=zu(e,t),r=Wu(e,t),i={program:t,uniformSetters:n,attribSetters:r,uniformLocations:Object.fromEntries(Object.entries(n).map(([e,t])=>[e,t.location])),attribLocations:Object.fromEntries(Object.entries(r).map(([e,t])=>[e,t.location]))};return bc(e)&&(i.uniformBlockSpec=Vu(e,t),i.transformFeedbackInfo=Bu(e,t)),i}var Ju=/\s|{|}|;/;function Yu(e,t,n,r,i){let a=Tu(n,r,i),o=[];if(t=t.map(function(e){if(!Ju.test(e)){let t=Lc(e);if(t)e=t.text;else{let t=`no element with id: ${e}`;a.errorCallback(t),o.push(t)}}return e}),o.length)return Cu(a,``);let s=a.callback;s&&(a.callback=(t,n)=>{s(t,t?void 0:qu(e,n))});let c=Pu(e,t,a);return c?qu(e,c):null}var Xu=4,Zu=5123;function Qu(e,t,n,r,i,a){n=n===void 0?Xu:n;let o=t.indices,s=t.elementType,c=r===void 0?t.numElements:r;i=i===void 0?0:i,s||o?a===void 0?e.drawElements(n,c,s===void 0?Zu:t.elementType,i):e.drawElementsInstanced(n,c,s===void 0?Zu:t.elementType,i,a):a===void 0?e.drawArrays(n,i,c):e.drawArraysInstanced(n,i,c,a)}var $u=6402,ed=33190,td=36012,nd=35056,rd=36013,id=32854,ad=32855,od=36194,sd=33189,cd=6401,ld=36168,ud=34041,dd=36096,fd=36128,pd=33306,md={};md[ud]=pd,md[cd]=fd,md[ld]=fd,md[$u]=dd,md[sd]=dd,md[ed]=dd,md[td]=dd,md[nd]=pd,md[rd]=pd;var hd={};hd[id]=!0,hd[ad]=!0,hd[od]=!0,hd[ud]=!0,hd[sd]=!0,hd[cd]=!0,hd[ld]=!0;var gd={addExtensionsToContext:!0},_d=/^(.*?)_/;function vd(e,t){xc(e,0);let n=e.getExtension(t);if(n){let r={},i=_d.exec(t)[1],a=`_`+i;for(let t in n){let o=n[t],s=typeof o==`function`,c=s?i:a,l=t;t.endsWith(c)&&(l=t.substring(0,t.length-c.length)),e[l]===void 0?s?e[l]=function(e){return function(){return e.apply(n,arguments)}}(o):(e[l]=o,r[l]=o):!s&&e[l]!==o&&Ls(l,e[l],o,t)}r.constructor={name:n.constructor.name},xc(r,0)}return n}var yd=`ANGLE_instanced_arrays.EXT_blend_minmax.EXT_color_buffer_float.EXT_color_buffer_half_float.EXT_disjoint_timer_query.EXT_disjoint_timer_query_webgl2.EXT_frag_depth.EXT_sRGB.EXT_shader_texture_lod.EXT_texture_compression_bptc.EXT_texture_compression_rgtc.EXT_texture_filter_anisotropic.OES_element_index_uint.OES_standard_derivatives.OES_texture_float.OES_texture_float_linear.OES_texture_half_float.OES_texture_half_float_linear.OES_vertex_array_object.WEBGL_color_buffer_float.WEBGL_compressed_texture_atc.WEBGL_compressed_texture_etc1.WEBGL_compressed_texture_etc.WEBGL_compressed_texture_pvrtc.WEBGL_compressed_texture_s3tc.WEBGL_compressed_texture_s3tc_srgb.WEBGL_depth_texture.WEBGL_draw_buffers`.split(`.`);function bd(e){for(let t=0;t<yd.length;++t)vd(e,yd[t])}function xd(e,t){let n=[`webgl2`,`webgl`,`experimental-webgl`],r=null;for(let i=0;i<n.length;++i)if(r=e.getContext(n[i],t),r){gd.addExtensionsToContext&&bd(r);break}return r}function Sd(e,t){return xd(e,t)}function Cd(e,t){t=t||1,t=Math.max(0,t);let n=e.clientWidth*t|0,r=e.clientHeight*t|0;return e.width!==n||e.height!==r?(e.width=n,e.height=r,!0):!1}var wd=150,Td=`
attribute float a_index;
uniform vec2 u_resolution;
uniform float u_time;
varying float v_color_type;
varying float v_intensity_base;

float hash2(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

void main() {
  float seed = a_index * 123.456;
  
  float speed_rand = hash2(vec2(seed, 1.1));
  float size_rand = hash2(vec2(seed, 2.2));
  float y_rand = hash2(vec2(seed, 3.3));
  float x_rand = hash2(vec2(seed, 4.4));
  float blink_rand = hash2(vec2(seed, 5.5));
  float color_type_rand = hash2(vec2(seed, 6.6));

  float aspect = u_resolution.x / u_resolution.y;
  float speed = 0.008 + speed_rand * 0.024;
  float size = 0.0006 + 0.0032 * pow(size_rand, 3.8);
  
  float y = -0.45 + y_rand * 0.9;
  
  float margin = 0.05;
  float width = aspect + margin * 2.0;
  float x = fract(x_rand + u_time * speed);
  x = x * width - (aspect * 0.5 + margin);
  
  float wave = sin(u_time * 0.3 + y_rand * 6.283) * 0.005;
  
  float ndc_x = x / (aspect * 0.5);
  float ndc_y = (y + wave) / 0.5;
  
  gl_Position = vec4(ndc_x, ndc_y, 0.0, 1.0);
  
  // Point size in pixels. 
  float pointSize = size * u_resolution.y * 3.5;
  gl_PointSize = max(2.0, pointSize);
  
  float blink = 0.3 + 0.7 * sin(u_time * (1.0 + blink_rand * 2.5) + x_rand * 6.283);
  v_intensity_base = blink;
  v_color_type = color_type_rand;
}
`,Ed=`
precision mediump float;
uniform vec3 u_particle_color;
uniform vec3 u_particle_accent_color;

varying float v_color_type;
varying float v_intensity_base;

void main() {
  vec2 pc = gl_PointCoord - 0.5;
  float dist = length(pc);
  
  float alpha = smoothstep(0.5, 0.1, dist) * v_intensity_base;
  if (alpha < 0.01) discard;
  
  vec3 baseColor = v_color_type > 0.90 ? u_particle_accent_color : u_particle_color;
  
  // Pre-multiplied alpha blending
  gl_FragColor = vec4(baseColor * alpha, alpha);
}
`,Dd=({theme:e,isDaylight:t,paused:n=!1,blendMs:r=0,blendProgress:i})=>{let a=(0,I.useRef)(null),o=(0,I.useRef)(null),s=(0,I.useRef)(0),c=(0,I.useRef)(null),[l,u]=gt([e.primaryColor,e.accentColor],r,i),d=T(l)||(t?{r:0,g:0,b:0}:{r:255,g:255,b:255}),f=[d.r/255,d.g/255,d.b/255],p=T(u)||d,m=[p.r/255,p.g/255,p.b/255],h=t?[1,1,1]:[0,0,0],g=(0,I.useRef)(n),_=(0,I.useRef)(f),v=(0,I.useRef)(m),y=(0,I.useRef)(h);return g.current=n,_.current=f,v.current=m,y.current=h,(0,I.useEffect)(()=>{let e=a.current;if(!e)return;let t=Sd(e,{alpha:!1,depth:!1,antialias:!1});if(!t)return;let n=Yu(t,[Td,Ed],e=>{console.error(`SoraBackground twgl program error:`,e)});if(!n)return;let r=new Float32Array(wd);for(let e=0;e<wd;e++)r[e]=e;let i=yc(t,{a_index:{numComponents:1,data:r}}),l=null,u=()=>{o.current===null&&(o.current=requestAnimationFrame(d))},d=r=>{if(o.current=null,!g.current&&l!==null){let e=(r-l)/1e3;s.current+=e}l=g.current?null:r,Cd(e),t.viewport(0,0,t.canvas.width,t.canvas.height);let a=y.current;t.clearColor(a[0],a[1],a[2],1),t.clear(t.COLOR_BUFFER_BIT),t.enable(t.BLEND),t.blendFunc(t.ONE,t.ONE_MINUS_SRC_ALPHA);let c={u_resolution:[t.canvas.width,t.canvas.height],u_time:s.current,u_particle_color:_.current,u_particle_accent_color:v.current};t.useProgram(n.program),Ku(t,n,i),Uu(n,c),Qu(t,i,t.POINTS),g.current||u()},f=new ResizeObserver(u);return f.observe(e),c.current=u,u(),()=>{c.current=null,f.disconnect(),o.current!==null&&(cancelAnimationFrame(o.current),o.current=null),t.deleteProgram(n.program),i.attribs&&i.attribs.a_index&&i.attribs.a_index.buffer&&t.deleteBuffer(i.attribs.a_index.buffer)}},[]),(0,I.useEffect)(()=>{var e;(e=c.current)==null||e.call(c)},[n,t,l,u]),(0,L.jsx)(`canvas`,{ref:a,className:`absolute inset-0 w-full h-full block pointer-events-none`,style:{width:`100%`,height:`100%`,willChange:`transform`,transform:`translateZ(0)`}})},Od={id:`bg-sora`,titleKey:`options.soraBackgroundSettings`},kd=({t:e,tuning:t,onTuningChange:n})=>(0,L.jsx)(fe,{def:Od,children:(0,L.jsx)(P,{label:e(`options.soraBlank`),note:e(`options.soraBlankDesc`),checked:t.blank,onChange:e=>n==null?void 0:n({blank:e})})}),Ad=t({default:()=>jd}),jd=Fe({mode:`sora`,order:50,labelKey:`options.visualizerBackgroundModeSora`,labelFallback:`Sora`,glyph:(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`path`,{d:`M12 5.5l1.2 2.9 2.9 1.2-2.9 1.2L12 13.7l-1.2-2.9-2.9-1.2 2.9-1.2z`}),(0,L.jsx)(`path`,{d:`M5.5 16.5h.01M18 15.5h.01M7 7h.01`,strokeWidth:`2.2`,opacity:`0.5`})]}),command:{title:`Background: Sora`,description:`Switch background to Sora (starry sky) layout`,keywords:[`sora`,`starry sky`,`star`,`星空`,`空`,`背景切换到 空`,`背景切换到空`,`背景切换到Sora`,`背景切换到星空`]},render:({config:e,theme:t,isDaylight:n,paused:r,staticMode:i,blendMs:a,blendProgress:o})=>{var s;return(0,L.jsx)(`div`,{className:`absolute inset-0 z-0`,style:{backgroundColor:n?`#ffffff`:`#000000`},children:!(e!=null&&(s=e.sora)!=null&&(s=s.tuning)!=null&&s.blank)&&(0,L.jsx)(Dd,{theme:t,isDaylight:n,paused:r||i,blendMs:a,blendProgress:o})})},renderSettingsPanel:({config:e,actions:t,t:n})=>{var r,i,a;return(0,L.jsx)(kd,{t:n,tuning:(r=e==null||(i=e.sora)==null?void 0:i.tuning)==null?oe:r,onTuningChange:t==null||(a=t.sora)==null?void 0:a.onTuningChange})},renderQuickControls:({config:e,actions:t,t:n})=>{var r,i;let o=(r=e==null||(i=e.sora)==null?void 0:i.tuning)==null?oe:r;return(0,L.jsx)(he,{active:o.blank,label:n(`options.soraBlank`),onToggle:()=>{var e,n;return t==null||(e=t.sora)==null||(n=e.onTuningChange)==null?void 0:n.call(e,{blank:!o.blank})},children:(0,L.jsx)(a,{size:14})})},resetSettings:e=>{var t,n;return e==null||(t=e.sora)==null||(n=t.onResetTuning)==null?void 0:n.call(t)}}),Md=({urlBackgroundList:e=[],urlBackgroundSelectedId:t=null})=>{let n=(0,I.useMemo)(()=>xe(e.find(e=>e.id===t)),[e,t]),r=(0,I.useRef)(null),[i,a]=(0,I.useState)(!1);return(0,I.useEffect)(()=>{a(!1);let e=r.current;if(!e)return;let t=e.getBoundingClientRect();if(t.width>0&&t.height>0){a(!0);return}let n=new ResizeObserver(e=>{for(let t of e){let{width:e,height:r}=t.contentRect;e>0&&r>0&&(a(!0),n.disconnect())}});return n.observe(e),()=>{n.disconnect()}},[n]),n!=null&&n.url?(0,L.jsxs)(`div`,{ref:r,className:`absolute inset-0 z-0 overflow-hidden`,children:[i&&(0,L.jsx)(`iframe`,{src:n.url,title:n.note||n.url,className:`w-full h-full border-0`,style:{pointerEvents:`none`},sandbox:`allow-scripts`,allowFullScreen:!0},n.url),(0,L.jsx)(`div`,{className:`absolute inset-0`,style:{background:`linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.35))`,pointerEvents:`none`}})]}):null},Nd={id:`bg-url`,titleKey:`options.urlBackgroundSettings`},Pd=()=>`url-bg-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,Fd=({t:e,urlBackgroundList:t=[],urlBackgroundSelectedId:n=null,onAddUrlBackgroundItem:r,onUpdateUrlBackgroundItem:i,onDeleteUrlBackgroundItem:a,onSetUrlBackgroundSelectedId:o})=>{let[s,l]=(0,I.useState)(!1),[d,f]=(0,I.useState)(null),[p,m]=(0,I.useState)(``),[h,g]=(0,I.useState)(``),v=(0,I.useCallback)(()=>{m(``),g(``),l(!1),f(null)},[]),y=(0,I.useCallback)(()=>{let e=be(p);if(!e)return;let t={id:Pd(),url:e,note:h.trim()||e};r==null||r(t),o==null||o(t.id),v()},[p,h,r,o,v]),b=(0,I.useCallback)(e=>{l(!1),f(e.id),m(e.url),g(e.note)},[]),x=(0,I.useCallback)(()=>{if(!d)return;let e=be(p);e&&(i==null||i(d,{url:e,note:h.trim()||e}),v())},[d,p,h,i,v]),S=t=>(0,L.jsx)(F,{below:(0,L.jsxs)(`div`,{className:`flex flex-col gap-2 [&>input]:w-full`,children:[(0,L.jsx)(we,{type:`url`,value:p,onChange:m,placeholder:`https://example.com`}),(0,L.jsx)(we,{value:h,onChange:g,placeholder:e(`options.urlBackgroundNotePlaceholder`)}),(0,L.jsxs)(`div`,{className:`flex justify-end gap-2`,children:[(0,L.jsx)(me,{onClick:v,children:e(`ui.cancel`)}),(0,L.jsx)(me,{variant:`primary`,onClick:t,disabled:!p.trim(),children:e(`options.save`)})]})]})});return(0,L.jsxs)(fe,{def:Nd,foot:e(`options.urlBackgroundSettingsDesc`),children:[t.map(t=>d===t.id?(0,L.jsx)(I.Fragment,{children:S(x)},t.id):(0,L.jsxs)(F,{label:(0,L.jsxs)(`button`,{type:`button`,role:`radio`,"aria-checked":t.id===n,onClick:()=>o==null?void 0:o(t.id),className:`flex w-full min-w-0 items-center gap-2.5 rounded text-left`,children:[(0,L.jsx)(`span`,{"aria-hidden":!0,className:`st-t-fast h-4 w-4 shrink-0 rounded-full transition-shadow ${t.id===n?`shadow-[inset_0_0_0_5px_var(--st-accent)]`:`shadow-[inset_0_0_0_1.5px_var(--st-t3)]`}`}),(0,L.jsxs)(`span`,{className:`min-w-0`,children:[(0,L.jsx)(`span`,{className:`block truncate`,children:t.note}),(0,L.jsx)(`span`,{className:`block truncate text-xs leading-[18px] text-[color:var(--st-t2)]`,children:t.url})]})]}),children:[(0,L.jsx)(me,{icon:u,tip:e(`options.urlBackgroundEdit`),onClick:()=>b(t)}),(0,L.jsx)(me,{icon:c,tip:e(`options.urlBackgroundDelete`),onClick:()=>a==null?void 0:a(t.id)})]},t.id)),s?S(y):(0,L.jsx)(F,{label:t.length===0?(0,L.jsx)(ve,{children:e(`options.urlBackgroundEmpty`)}):void 0,children:(0,L.jsx)(me,{icon:_,onClick:()=>{f(null),m(``),g(``),l(!0)},children:e(`options.urlBackgroundAdd`)})})]})},Id=t({default:()=>Rd}),Ld=[`config`,`actions`],Rd=Fe({mode:`url`,order:40,labelKey:`options.visualizerBackgroundModeUrl`,labelFallback:`Embed`,glyph:(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(`rect`,{x:`3.5`,y:`5`,width:`17`,height:`14`,rx:`2`}),(0,L.jsx)(`path`,{d:`M3.5 9.5h17`,opacity:`0.55`})]}),command:{title:`Background: Embedded Background`,description:`Switch background to embedded webpage mode`,keywords:[`embedded background`,`embed background`,`background embed`,`background url`,`url background`,`url`,`webpage`,`嵌入背景`,`网页背景`,`背景切换到 嵌入背景`,`背景切换到嵌入背景`]},render:({config:e})=>{var t,n;return(0,L.jsx)(Md,{urlBackgroundList:e==null||(t=e.url)==null?void 0:t.items,urlBackgroundSelectedId:e==null||(n=e.url)==null?void 0:n.selectedId})},renderSettingsPanel:e=>{var t,n,r,a,o,s;let{config:c,actions:l}=e,u=d(e,Ld);return(0,L.jsx)(Fd,i(i({},u),{},{urlBackgroundList:c==null||(t=c.url)==null?void 0:t.items,urlBackgroundSelectedId:c==null||(n=c.url)==null?void 0:n.selectedId,onAddUrlBackgroundItem:l==null||(r=l.url)==null?void 0:r.onAdd,onUpdateUrlBackgroundItem:l==null||(a=l.url)==null?void 0:a.onUpdate,onDeleteUrlBackgroundItem:l==null||(o=l.url)==null?void 0:o.onDelete,onSetUrlBackgroundSelectedId:l==null||(s=l.url)==null?void 0:s.onSelect}))}}),{entries:zd,byMode:Bd}=(e=>{let t=Object.entries(e).map(([e,t])=>{if(!t.default)throw Error(`[VisualizerBackgroundRegistry] Missing default export in ${e}`);return t.default}),n={};return t.forEach(e=>{if(n[e.mode])throw Error(`[VisualizerBackgroundRegistry] Duplicate background mode "${e.mode}"`);n[e.mode]=e}),{entries:[...t].sort((e,t)=>e.order-t.order),byMode:n}})(Object.assign({"./common/entry.tsx":pn,"./latent/entry.tsx":$i,"./monet/entry.tsx":jo,"./nomand/entry.tsx":ds,"./sora/entry.tsx":Ad,"./url/entry.tsx":Id}));ye(`VisualizerBackgroundRegistry`,zd.map(e=>e.mode),_e);var Vd=e=>typeof e==`string`&&!!Bd[e],Hd=e=>{var t;return(t=Bd[e])==null?Bd[Se]:t},Ud=(e,t)=>{let n=Hd(e),r=t(n.labelKey);return!r||r===n.labelKey?n.labelFallback:r},Wd=e=>!Bd[e.mode]&&(Bd[e.mode]=e,zd.push(e),zd.sort((e,t)=>e.order-t.order),!0),Gd=e=>{if(!Bd[e])return!1;delete Bd[e];let t=zd.findIndex(t=>t.mode===e);return t>=0&&zd.splice(t,1),!0},Kd=e=>typeof e!=`number`||!Number.isFinite(e)?null:Math.round(Math.min(900,Math.max(100,e))/10)*10,qd=(e,t)=>{var n;return(n=Kd(e==null?void 0:e.fontWeight))==null?t:n},Jd=`"獅尾四季春加糖SC"`,Yd={sans:`"Inter", "Noto Sans CJK SC", "Noto Sans JP", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif`,serif:`${Jd}, "Iowan Old Style", "Noto Serif CJK SC", "Noto Serif JP", "Source Han Serif SC", "Songti SC", "STSong", "Georgia", serif`,mono:`"IBM Plex Mono", "Sarasa Mono SC", "Noto Sans Mono CJK SC", "Noto Sans Mono", "SFMono-Regular", Consolas, monospace`},Xd={sans:`system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", "Inter", "Helvetica Neue", Arial, "Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans JP", "Source Han Sans JP", "Hiragino Sans", "Yu Gothic", Meiryo, sans-serif`,serif:`${Jd}, "Folia Noto Serif SC", "Iowan Old Style", Georgia, "Times New Roman", "Noto Serif CJK SC", "Source Han Serif SC", "Songti SC", "STSong", "SimSun", "Noto Serif JP", "Source Han Serif JP", "Yu Mincho", "MS PMincho", serif`,mono:`Consolas, "IBM Plex Mono", "SFMono-Regular", Menlo, Monaco, "Sarasa Mono SC", "Noto Sans Mono CJK SC", "SimHei", "DengXian", "Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans Mono CJK JP", "MS Gothic", monospace`},Zd=new Set([`serif`,`sans-serif`,`monospace`,`cursive`,`fantasy`,`system-ui`,`ui-serif`,`ui-sans-serif`,`ui-monospace`,`ui-rounded`,`emoji`,`math`,`fangsong`]),Qd=e=>`"${e.replace(/["\\]/g,`\\$&`)}"`,$d=e=>e.trim().replace(/^['"]|['"]$/g,``).trim(),ef=e=>{let t=$d(e);return t?Zd.has(t.toLowerCase())?t:Qd(t):null},tf=e=>{let t=new Set,n=[];return e==null||e.forEach(e=>{let r=$d(e==null?``:e);if(!r)return;let i=r.toLocaleLowerCase();t.has(i)||(t.add(i),n.push(r))}),n},nf=e=>{var t;let n=[...e.fontFamily?[e.fontFamily]:[],...(t=e.fontFamilyStack)==null?[]:t];return n.length===0?[]:tf(n).map(ef).filter(e=>!!e)},rf=e=>{var t;return(t=Yd[e])==null?Yd.sans:t},af=e=>{let t=rf(e.fontStyle),n=nf(e);return n.length===0?t:`${n.join(`, `)}, ${t}`},of=e=>{var t;let n=(t=Xd[e.fontStyle])==null?Xd.sans:t,r=nf(e);return r.length===0?n:`${r.join(`, `)}, ${n}`},sf=typeof window>`u`?new URLSearchParams:new URLSearchParams(window.location.search),cf=typeof window<`u`&&(sf.get(`obs`)===`1`||window.location.pathname===`/obs`),lf=sf.get(`obsSource`),uf=!cf&&sf.get(`remote`)===`1`,df=typeof window<`u`&&!cf&&!uf,ff=e=>{let t=new Set;return{subscribe:e=>(t.add(e),()=>t.delete(e)),notify:()=>{t.forEach(t=>{try{t()}catch(t){console.warn(`[Folium] ${e} failed`,t)}})}}},pf=e=>{let t=(0,I.useRef)(null);return t.current!=null||(t.current=ff(e)),t.current},mf=(e,t)=>{let n=(0,I.useRef)(!1);(0,I.useEffect)(()=>{n.current?e.notify():n.current=!0},t)},hf=/^[a-z0-9][a-z0-9-]*$/,gf=(e,t)=>`${e}:${t}`,_f=(e,t={})=>{let n=new Map,r=ff(`${e} listener`),i=Object.freeze([]),a=()=>{i=Object.freeze(Array.from(n.values())),r.notify()},o=r=>{let i=n.get(r);if(i){n.delete(r);try{var o;(o=t.onRemove)==null||o.call(t,i)}catch(t){console.warn(`[Folium] ${e}: removing ${r} failed`,t)}a()}};return{name:e,register:(r,i)=>{if(!i||typeof i!=`object`||typeof i.id!=`string`||!hf.test(i.id))throw Error(`[Folium] ${e}.register: id must match /^[a-z0-9][a-z0-9-]*$/`);let s=gf(r,i.id);if(n.has(s))throw Error(`[Folium] ${e}.register: duplicate id "${s}"`);let c=t.validate?t.validate(i,{modId:r,id:s}):i,l={id:s,modId:r,name:i.id,def:c};n.set(s,l);try{var u;(u=t.onAdd)==null||u.call(t,l)}catch(e){throw n.delete(s),e}return a(),Object.freeze({id:s,unregister:()=>{n.get(s)===l&&o(s)}})},unregister:o,unregisterAll:e=>{Array.from(n.values()).filter(t=>t.modId===e).forEach(e=>o(e.id))},get:e=>{var t;return(t=n.get(e))==null?null:t},list:()=>i,subscribe:r.subscribe}},vf=e=>(0,I.useSyncExternalStore)(e.subscribe,e.list,e.list),yf=[`player.stage.back`,`player.stage.front`,`app.overlay`],bf=_f(`stageLayers`,{validate:e=>{if(!yf.includes(e.slot))throw Error(`stageLayers.register: slot must be one of ${yf.join(`, `)}`);if(typeof e.mount!=`function`)throw Error(`stageLayers.register: mount must be a function`);return e}}),xf=I.lazy(()=>n(()=>import(`./stageLayerView-CEy1-pqa.js`),__vite__mapDeps([2,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]))),Sf=e=>vf(bf).some(t=>t.def.slot===e.slot)?(0,L.jsx)(I.Suspense,{fallback:null,children:(0,L.jsx)(xf,i({},e))}):null,Cf=Object.freeze({top:0,right:0,bottom:0,left:0}),wf=(e,t)=>{if(![e.left,e.top,e.width,e.height].every(Number.isFinite))return null;let n=Math.max(t.left,e.left),r=Math.max(t.top,e.top),i=Math.min(t.left+t.width,e.left+e.width),a=Math.min(t.top+t.height,e.top+e.height);return i<=n||a<=r?null:Object.freeze({left:n,top:r,width:i-n,height:a-r})},Tf=(e,t,n=Cf)=>{let r=new Map;for(let n of t){let t=wf(n.rect,e);if(!t)continue;let i=r.get(n.key),a=i?{left:Math.min(i.rect.left,t.left),top:Math.min(i.rect.top,t.top),width:Math.max(i.rect.left+i.rect.width,t.left+t.width)-Math.min(i.rect.left,t.left),height:Math.max(i.rect.top+i.rect.height,t.top+t.height)-Math.min(i.rect.top,t.top)}:t;r.set(n.key,Object.freeze({role:n.role,kind:n.kind,rect:Object.freeze(a)}))}let i=(e,t)=>Number.isFinite(e)?Math.min(Math.max(0,e),t):0,a=i(n.top,e.height),o=i(n.left,e.width);return Object.freeze({bounds:Object.freeze({left:e.left,top:e.top,width:e.width,height:e.height}),insets:Object.freeze({top:a,left:o,right:i(n.right,e.width-o),bottom:i(n.bottom,e.height-a)}),obstacles:Object.freeze([...r.entries()].sort(([e],[t])=>e.localeCompare(t)).map(([,e])=>e))})},Ef=(e,t)=>{if(e===t)return!0;if(!e||!t||e.obstacles.length!==t.obstacles.length)return!1;let n=(e,t)=>e.left===t.left&&e.top===t.top&&e.width===t.width&&e.height===t.height;return n(e.bounds,t.bounds)&&[`top`,`right`,`bottom`,`left`].every(n=>e.insets[n]===t.insets[n])&&e.obstacles.every((e,r)=>{let i=t.obstacles[r];return e.role===i.role&&e.kind===i.kind&&n(e.rect,i.rect)})},Df=(()=>{let e=null,t=null,n=null,r=Cf,a,o,s=new Map,c=new Set,l=()=>{let i=e!=null&&e.isConnected?e.getBoundingClientRect():null,a=i&&i.width>0&&i.height>0?Tf(i,[...s.values()].flatMap(({read:e})=>{let t=e(i);return t?[t]:[]}),r):null;return t===e&&Ef(n,a)?!1:(t=e,n=a,!0)},u=()=>{if(l())for(let e of[...c])try{e()}catch(e){console.warn(`[Folium] layout subscriber failed`,e)}},d=()=>{c.size&&a===void 0&&(e||n!==null)&&(a=setTimeout(()=>{a=void 0,u()},80))},f=()=>{if(o==null||o.disconnect(),window.removeEventListener(`resize`,d),window.removeEventListener(`scroll`,d,!0),!e||!c.size)o=void 0;else{!o&&typeof ResizeObserver<`u`&&(o=new ResizeObserver(d)),o==null||o.observe(e);for(let e of s.values())e.element&&(o==null||o.observe(e.element));window.addEventListener(`resize`,d),window.addEventListener(`scroll`,d,!0)}};return{source:{get:()=>!(e!=null&&e.isConnected)||!c.size?null:t===e?n:null,subscribe:e=>{c.add(e),c.size===1&&f(),d();let r=!1;return()=>{r||(r=!0,c.delete(e),c.size||(clearTimeout(a),a=void 0,f(),n=null,t=null))}}},invalidate:d,registerRoot:(t,n=Cf)=>(e=t,r=i({},n),f(),d(),()=>{e===t&&(e=null),f(),d()}),register:(e,t)=>{let n=Symbol();return s.set(n,{element:e,read:t}),f(),d(),()=>{s.delete(n),f(),d()}}}})();export{Rr as $,Ai as A,_i as B,Vd as C,Ge as Ct,Ei as D,tt as Dt,Ti as E,it as Et,vi as F,di as G,bi as H,li as I,hi as J,ii as K,mi as L,ui as M,ci as N,Di as O,Pe as Ot,yi as P,Hr as Q,ai as R,Hd as S,Ke as St,La as T,at as Tt,pi as U,xi as V,fi as W,Vr as X,Si as Y,Gr as Z,qd as _,pt as _t,_f as a,z as at,Wd as b,lt as bt,pf as c,An as ct,cf as d,Qt as dt,Ir as et,uf as f,Yt as ft,af as g,Zt as gt,Kd as h,$t as ht,bf as i,er as it,ki as j,Oi as k,mf as l,wn as lt,tf as m,Xt as mt,Cf as n,Pr as nt,gf as o,jn as ot,lf as p,Jt as pt,si as q,Sf as r,or as rt,vf as s,Tn as st,Df as t,Lr as tt,df as u,nn as ut,of as v,ft as vt,Gd as w,ot as wt,Ud as x,ct as xt,zd as y,st as yt,gi as z};